﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class frmPreview
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim strTBLab As String
    Dim strTBLabData As String

#Region "PreviewRpt"
    Function CheckStatusYear(ByVal strYear As String) As String
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlYear As String
            Dim strStatus As String
            sqlYear = "Select Status From Production_Year Where PValue='" & strYear & "'"
            strStatus = clsScriptData.ExecuteSchalar(sqlConn, sqlYear)
            If strStatus = "1" Then
                Return ""
            Else
                Return "_" & strYear
            End If
            sqlConn.Close()
        Catch ex As Exception
            Return Nothing
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Private Sub QueryLogo()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            strTBLab = "Lab" & CheckStatusYear(Session("PYears"))
            strTBLabData = "Lab_Data" & CheckStatusYear(Session("PYears"))

            'Dim cmQueryHead As New SqlCommand("spLot_Data1", sqlConn)
            Dim cmQueryHead As New SqlCommand("rptLot_Data1", sqlConn)
            With cmQueryHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@TBLab", strTBLab)
                .Parameters.AddWithValue("@TBLabData", strTBLabData)
                .Parameters.AddWithValue("@mill", Session("Mill"))
                .Parameters.AddWithValue("@Lot_no", Session("Lot"))
                .Parameters.AddWithValue("@Sugar_Type", Session("Sugar"))
                .Parameters.AddWithValue("@PYears", Session("Years"))
                .ExecuteNonQuery()
            End With

            Dim dtQueryHead As New DataTable
            dtQueryHead = clsScriptData.ExecuteDT(sqlConn, cmQueryHead)
            dvLogo.DataSource = dtQueryHead
            dvLogo.DataBind()

            cmQueryHead.Dispose()
            dtQueryHead.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryMillRpt()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            strTBLab = "Lab" & CheckStatusYear(Session("PYears"))
            strTBLabData = "Lab_Data" & CheckStatusYear(Session("PYears"))

            'Dim cmQueryMill As New SqlCommand("spLot_Data1", sqlConn)
            Dim cmQueryMill As New SqlCommand("rptLot_Data1", sqlConn)
            With cmQueryMill
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@TBLab", strTBLab)
                .Parameters.AddWithValue("@TBLabData", strTBLabData)
                .Parameters.AddWithValue("@mill", Session("Mill"))
                .Parameters.AddWithValue("@Lot_no", Session("Lot"))
                .Parameters.AddWithValue("@Sugar_Type", Session("Sugar"))
                .Parameters.AddWithValue("@PYears", Session("Years"))
                .ExecuteNonQuery()
            End With

            Dim dtQueryMill As New DataTable
            dtQueryMill = clsScriptData.ExecuteDT(sqlConn, cmQueryMill)
            dvFac.DataSource = dtQueryMill
            dvFac.DataBind()

            cmQueryMill.Dispose()
            dtQueryMill.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryOriginal()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            strTBLab = "Lab" & CheckStatusYear(Session("PYears"))
            strTBLabData = "Lab_Data" & CheckStatusYear(Session("PYears"))

            Dim sqlOriginal As String
            sqlOriginal = "Select Mill.*, Lab.Lot_no, Sugar_Type.[Type_Name] as Sugar_Type, "
            sqlOriginal &= "Lab.Production_Date,Lab.Analyst_Date,  Lab.Remarks,Lab.Sample_Size, "
            sqlOriginal &= "Lab.Referance_no,'blank.jpg' As LabAnalyst_Logo,Lab.Analyst_name as LabAnalyst_name, "
            sqlOriginal &= "'blank.jpg'as LabAuthorize_Logo,Lab.Authorize_name as LabAuthorize_name,Lab.Exp_Date "
            sqlOriginal &= "From " & strTBLab & " Lab inner join Mill on Lab.Mill = Mill.Mill "
            sqlOriginal &= "Left join Sugar_Type on Lab.Sugar_Type=Sugar_Type.[Type_ID] "
            sqlOriginal &= "Where Lab.Lot_no = '" & Session("Lot") & "' and Sugar_Type = '" & Session("Sugar") & "' and " & Session("Mill") & " = Lab.Mill "
            sqlOriginal &= "and Lab.Production_Year='" & Session("Years") & "'"
            Dim dtHead As New DataTable
            dtHead = clsScriptData.ExecuteDataTable(sqlConn, sqlOriginal)
            dvHeadRpt.DataSource = dtHead
            dvHeadRpt.DataBind()

            dvRemarks.DataSource = dtHead
            dvRemarks.DataBind()

            DvAnalyst.DataSource = dtHead
            DvAnalyst.DataBind()

            DvAuthorize.DataSource = dtHead
            DvAuthorize.DataBind()

            dtHead.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryHeader()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            strTBLab = "Lab" & CheckStatusYear(Session("PYears"))
            strTBLabData = "Lab_Data" & CheckStatusYear(Session("PYears"))
            'Dim cmRptHead As New SqlCommand("spLot_Data1", sqlConn)
            Dim cmRptHead As New SqlCommand("rptLot_Data1", sqlConn)
            With cmRptHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@TBLab", strTBLab)
                .Parameters.AddWithValue("@TBLabData", strTBLabData)
                .Parameters.AddWithValue("@mill", Session("Mill"))
                .Parameters.AddWithValue("@Lot_no", Session("Lot"))
                .Parameters.AddWithValue("@Sugar_Type", Session("Sugar"))
                .Parameters.AddWithValue("@PYears", Session("Years"))
                .ExecuteNonQuery()
            End With

            Dim dtHead As New DataTable
            dtHead = clsScriptData.ExecuteDT(sqlConn, cmRptHead)
            dvHeadRpt.DataSource = dtHead
            dvHeadRpt.DataBind()

            dvRemarks.DataSource = dtHead
            dvRemarks.DataBind()

            DvAnalyst.DataSource = dtHead
            DvAnalyst.DataBind()

            DvAuthorize.DataSource = dtHead
            DvAuthorize.DataBind()

            cmRptHead.Dispose()
            dtHead.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryDetail()
        Try
            QueryLogo()
            QueryMillRpt()
            If Session("Cust") = 340 Then
                QueryOriginal()
            Else
                QueryHeader()
            End If

            Dim sqlGetHeadOff As String
            Dim sqlGetTelHead As String
            Dim strAddr As String
            Dim strTel As String
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            sqlGetHeadOff = "SELECT TValue FROM DataConfig WHERE NAME='lbAddressLeft'"
            strAddr = clsScriptData.ExecuteSchalar(sqlConn, sqlGetHeadOff)
            sqlGetTelHead = "SELECT TValue FROM DataConfig WHERE Name = 'lbTelLeft'"
            strTel = clsScriptData.ExecuteSchalar(sqlConn, sqlGetTelHead)
            lblAddressL.Text = strAddr & "<br>" & strTel
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ShowRpt()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()

            Dim strCustName As String
            strCustName = clsScriptData.ExecuteSchalar(sqlConn, "SELECT Customer_Name FROM Customer WHERE Customer_ID='" & Session("Cust") & "'")
            lblCust.Text = strCustName

            Dim strCustAdd As String
            strCustAdd = clsScriptData.ExecuteSchalar(sqlConn, "SELECT Customer_Address FROM Customer WHERE Customer_ID='" & Session("Cust") & "'")
            lblAdd.Text = strCustAdd

            Dim sqlTran As String
            Dim dsTrans As New DataSet
            If Session("Cust") = 321 Then
                sqlTran = "Select Car_License,Province,Remark,Recieve_Sugar,CopyPage,ReviseNo from Transport_Lot Where Customer_ID=" & Session("Cust") & " "
                sqlTran &= "and Fac_ID=" & Session("Mill") & " and Lot_No='" & Session("Lot") & "' And Trans_ID=" & CInt(Session("intTrans")) & " "
            Else
                sqlTran = "Select Car_License,Province,Remark,Recieve_Sugar,CopyPage,ReviseNo from Transport_Lot Where Customer_ID=" & Session("Cust") & " "
                sqlTran &= "and Fac_ID=" & Session("Mill") & " and Lot_No='" & Session("Lot") & "' "
                'If Session("intTrans") <> "" And Session("intTrans") IsNot Nothing Then
                sqlTran &= "And Trans_ID=" & CInt(Session("intTrans")) & ""
                'Else
                '    sqlTran &= "and Trans_ID=" & CInt(Session("strTruck")) & ""
                ' End If
            End If
            dsTrans = clsScriptData.ExecuteData(sqlConn, sqlTran, "dtTrans")
            If dsTrans.Tables("dtTrans").Rows.Count > 0 Then
                lblLicense.Text = dsTrans.Tables("dtTrans").Rows(0)("Car_License")
                lblRecieve.Text = IIf(True, Format(dsTrans.Tables("dtTrans").Rows(0)("Recieve_Sugar"), "dd/MM/yyyy"), "")
                lblProv.Text = dsTrans.Tables("dtTrans").Rows(0)("Province")
                lblRemarkH.Text = dsTrans.Tables("dtTrans").Rows(0)("Remark")
                lblCopy.Text = clsScriptData.DbnullToString(dsTrans.Tables("dtTrans").Rows(0)("CopyPage"))
                lblReverse.Text = clsScriptData.DbnullToString(dsTrans.Tables("dtTrans").Rows(0)("ReviseNo"))
                dsTrans = Nothing
                sqlConn.Close()
            Else
                sqlConn.Close()
            End If
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            strTBLab = "Lab" & CheckStatusYear(Session("PYears"))
            strTBLabData = "Lab_Data" & CheckStatusYear(Session("PYears"))
            'Dim cmQeryRpt As New SqlCommand("spLot_Data_Table1", sqlConn)
            Dim cmQeryRpt As New SqlCommand("rptLot_Data_Table1", sqlConn)
            With cmQeryRpt
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@TBLab", strTBLab)
                .Parameters.AddWithValue("@TBLabData", strTBLabData)
                .Parameters.AddWithValue("@mill", Session("Mill"))
                .Parameters.AddWithValue("@Lot_no", Session("Lot"))
                If Session("Cust") > 0 Then
                    .Parameters.AddWithValue("@Customer_ID", Session("Cust"))
                Else
                    .Parameters.AddWithValue("@Customer_ID", 0)
                End If
                If Session("Name") = 1 Or Session("Name") = 2 Then
                    .Parameters.AddWithValue("@Sugar_Type", "E")
                ElseIf Session("Name") = 3 Or Session("Name") = 4 Then
                    .Parameters.AddWithValue("@Sugar_Type", "D")
                Else
                    .Parameters.AddWithValue("@Sugar_Type", Session("Name"))
                End If
                If Session("Name") = 1 Or Session("Name") = 3 Then
                    .Parameters.AddWithValue("@SugarName", "White")
                ElseIf Session("Name") = 2 Or Session("Name") = 4 Then
                    .Parameters.AddWithValue("@SugarName", "Refine")
                Else
                    .Parameters.AddWithValue("@SugarName", Session("strName"))
                End If
                .Parameters.AddWithValue("@CustUp", Session("CustUpdate"))
                .Parameters.AddWithValue("@PYears", Session("Years"))
                .ExecuteNonQuery()
            End With

            Dim dsQuret As New DataSet
            dsQuret = clsScriptData.ExecuteDS(sqlConn, cmQeryRpt, "dtRpt")
            'Dim dtQuert As New DataTable
            'dtQuert = clsScriptData.ExecuteDT(sqlConn, cmQeryRpt)
            If Session("Cust") = 70 Or Session("Cust") = 71 Or Session("Cust") = 341 Then
                For i As Integer = 0 To dsQuret.Tables("dtRpt").Rows.Count - 1
                    If dsQuret.Tables("dtRpt").Rows(i)("TestItem") = "Appearance" Then
                        dsQuret.Tables("dtRpt").Rows(i)("Value") = "ปกติ"
                        Exit For
                    End If
                Next
            End If
            If Session("Name") = 16 And Session("Mill") = 2 And Session("Years") = "55/56" Then
                For k As Integer = 0 To dsQuret.Tables("dtRpt").Rows.Count - 1
                    If dsQuret.Tables("dtRpt").Rows(k)("TestItem") = "Color" Then
                        dsQuret.Tables("dtRpt").Rows(k)("TestMethod") = "ICUMSA 1/3-7(2002)"
                        Exit For
                    End If
                Next
            End If
            gvShowRpt.DataSource = dsQuret.Tables("dtRpt")
            gvShowRpt.DataBind()
          
            If Session("Mill") = 1 Then
                lblSampling.Visible = True
            Else
                lblSampling.Visible = False
            End If
            If Session("Mill") = 2 And Session("Years") >= "55/56" Then
                If Session("Name") = 5 Or Session("Name") = 16 Then
                    lblSampling.Visible = False
                Else
                    lblSampling.Visible = True
                End If
            ElseIf Session("Mill") <> 1 Then
                lblSampling.Visible = False
            End If
            If Session("Cust") = 70 Or Session("Cust") = 71 Or Session("Cust") = 341 Then
                lblCoke.Visible = True
            Else
                lblCoke.Visible = False
            End If
            If Session("Mill") = 2 And Session("Years") >= "55/56" Then
                If Session("Name") = 5 Or Session("Name") = 16 Then
                    lblRem.Visible = False
                Else
                    lblRem.Visible = True
                End If
            ElseIf Session("Mill") <> 1 Then
                lblRem.Visible = False
            End If
            cmQeryRpt.Dispose()
            dsQuret = Nothing
            'dtQuert.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetImage()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlGetImg1 As String
            Dim dtLogo1 As New DataTable
            sqlGetImg1 = "Select Logo1,Logo1_No From Mill Where Mill=" & Session("Mill") & ""

            If Session("Mill") = "2" Then
                If Session("Years") >= "55/56" Then
                    If Session("Name") = 5 Or Session("Name") = 16 Then
                        'dtLogo1 = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg1)
                        'DvLogo1.DataSource = dtLogo1
                        'DvLogo1.DataBind()
                    Else
                        dtLogo1 = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg1)
                        DvLogo1.DataSource = dtLogo1
                        DvLogo1.DataBind()
                    End If
                End If
            Else
                dtLogo1 = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg1)
                DvLogo1.DataSource = dtLogo1
                DvLogo1.DataBind()
            End If

            dtLogo1 = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetRefNo()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strRefNo As String
            strTBLab = "Lab" & CheckStatusYear(Session("PYears"))
            strRefNo = clsScriptData.ExecuteSchalar(sqlConn, "select Referance_no from " & strTBLab & " where Mill=" & Session("Mill") & " and Lot_No='" & Session("Lot") & "' and sugar_type='" & Session("Sugar") & "' and production_year='" & Session("Years") & "'")
            lblRef.Text = ""
            lblRef.Text = strRefNo
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function MillName(ByVal Mill As Integer) As String
        Dim Name As String = ""
        Select Case Mill
            Case 1
                Name = "SS"
            Case 2
                Name = "PS"
            Case 3
                Name = "TRR"
            Case 4
                Name = "TMI"
            Case 5
                Name = "TSI"
            Case 6
                Name = "BSI"
            Case Else
                Name = Nothing
        End Select
        Return Name
    End Function
    Private Sub GetISOdata()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlISOdata As String
            Dim dsISO As New DataSet
            Dim strDate As String
            Dim strISONo As String
            Dim strName As String
            strTBLab = "Lab" & CheckStatusYear(Session("PYears"))

            strName = MillName(Session("Mill"))
            sqlISOdata = "select FM_No from " & strTBLab & " where Mill=" & Session("Mill") & " And Lot_No='" & Session("Lot") & "' "
            sqlISOdata &= "And Production_Year='" & Session("Years") & "' And Sugar_Type='" & Session("Name") & "' "

            dsISO = clsScriptData.ExecuteData(sqlConn, sqlISOdata, "dtISO")
            If clsScriptData.DbnullToString(dsISO.Tables("dtISO").Rows(0)("FM_No")) <> "" Then
                strDate = CStr(dsISO.Tables("dtISO").Rows(0)("FM_No"))
            Else
                strDate = CStr(Date.Today)
            End If
            lblIsoNo.Text = clsScriptData.DbnullToString(dsISO.Tables("dtISO").Rows(0)("FM_No"))
            dsISO = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try

    End Sub

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pnRpt.Visible = True
        QueryDetail()
        ShowRpt()
        GetImage()
        GetRefNo()
        GetISOdata()
        Response.Write("<script>window.print();</script>")
        Session.Remove("Mill")
        Session.Remove("Lot")
        Session.Remove("Sugar")
        Session.Remove("Cust")
        Session.Remove("Name")
        Session.Remove("strName")
        Session.Remove("intTrans")
        Session.Remove("Years")
        Session.Remove("PYears")
        Session.Remove("CustUpdate")
        'Session.Remove("strTruck")
        Session.Remove("Truck")
        Session.Remove("Recieve")
        Session.Remove("Province")
        Session.Remove("RemarkH")
        Session.Remove("Copy")
        Session.Remove("Reverse")
        Session.Remove("Address")
    End Sub
End Class
