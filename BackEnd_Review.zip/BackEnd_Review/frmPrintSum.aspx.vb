﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class frmPreview
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim strFac As String

#Region "PreviewRpt"
    Private Sub LoadSumLot()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strClientIP As String
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))

            Dim ddExp As String
            Dim MMExp As String
            Dim yyExp As String
            Dim strExp As String
            Dim strDate As Date
            ddExp = Session("Recieve").ToString.Substring(0, 2)
            MMExp = Session("Recieve").ToString.Substring(3, 2)
            yyExp = Session("Recieve").ToString.Substring(6, 4)
            If yyExp > 2500 Then
                yyExp = yyExp - 543
            End If
            strExp = yyExp + "-" + MMExp + "-" + ddExp + " 00:00:00"
            'strDate = CDate(strExp)

            Dim sqlSum As String
            Dim dsSum As New DataSet
            If Session("Cust") = 321 Then
                sqlSum = "Select Lot_no from Transport_Lot Where Customer_ID=" & Session("Cust") & " "
                sqlSum &= "and Fac_ID=" & Session("Mill") & " And Remark='" & Session("RemarkH") & "' And Recieve_Sugar='" & strExp & "' "
                sqlSum &= "Order By Lot_No "
                'And Recieve_Sugar='" & Format(CDate(Session("Recieve")), "dd/MM/yyyy") & "' "
            Else
                sqlSum = "Select Lot_no from Transport_Lot Where Customer_ID=" & Session("Cust") & " "
                sqlSum &= "and Fac_ID=" & Session("Mill") & " And Recieve_Sugar='" & strExp & "' "
                If Session("Truck") <> "" And Session("Truck") IsNot Nothing Then
                    sqlSum &= "and Car_License='" & Session("Truck") & "' "
                Else
                    sqlSum &= "and Car_License='" & Session("strTruck") & "' "
                End If
                sqlSum &= "Order By Lot_No "
            End If
            dsSum = clsScriptData.ExecuteData(sqlConn, sqlSum, "dtSumLot")
            dtlSumLot.DataSource = dsSum.Tables("dtSumLot")
            dtlSumLot.DataBind()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub HeadSum()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlTran As String
            Dim dsShowTrans As New DataSet

            Dim ddExp As String
            Dim MMExp As String
            Dim yyExp As String
            Dim strExp As String
            ddExp = Session("Recieve").ToString.Substring(0, 2)
            MMExp = Session("Recieve").ToString.Substring(3, 2)
            yyExp = Session("Recieve").ToString.Substring(6, 4)
            If yyExp > 2500 Then
                yyExp = yyExp - 543
            End If
            strExp = yyExp + "-" + MMExp + "-" + ddExp + " 00:00:00"

            If Session("Cust") = 321 Then
                sqlTran = "Select Customer_ID,Car_License,Province,Remark,Recieve_Sugar from Transport_Lot Where Customer_ID=" & Session("Cust") & " "
                sqlTran &= "and Fac_ID=" & Session("Mill") & " And Remark='" & Session("RemarkH") & "' And Recieve_Sugar='" & strExp & "' "
            Else
                sqlTran = "Select Customer_ID, Car_License,Province,Remark,Recieve_Sugar from Transport_Lot Where Customer_ID=" & Session("Cust") & " "
                sqlTran &= "and Fac_ID=" & Session("Mill") & " And Recieve_Sugar='" & strExp & "' "
                If Session("Truck") <> "" And Session("Truck") IsNot Nothing Then
                    sqlTran &= "and Car_License='" & Session("Truck") & "'"
                Else
                    sqlTran &= "and Car_License='" & Session("strTruck") & "'"
                End If
            End If
            dsShowTrans = clsScriptData.ExecuteData(sqlConn, sqlTran, "dtTrans")
            If dsShowTrans.Tables("dtTrans").Rows.Count > 0 Then
                lblCust.Text = FuncCustName(dsShowTrans.Tables("dtTrans").Rows(0)("Customer_ID"))
                lblLicense.Text = clsScriptData.DbnullToString(dsShowTrans.Tables("dtTrans").Rows(0)("Car_License"))
                lblRecieve.Text = clsScriptData.DbnullToString(Format(dsShowTrans.Tables("dtTrans").Rows(0)("Recieve_Sugar"), "dd/MM/yyyy"))
                lblProv.Text = clsScriptData.DbnullToString(dsShowTrans.Tables("dtTrans").Rows(0)("Province"))
                lblRemarkH.Text = clsScriptData.DbnullToString(dsShowTrans.Tables("dtTrans").Rows(0)("Remark"))
                dsShowTrans = Nothing
                sqlConn.Close()
            End If
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub

    Function FuncCustName(ByVal CustID As Integer) As String
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strName As String
            strName = clsScriptData.ExecuteSchalar(sqlConn, "Select Customer_Name From Customer Where Customer_ID=" & CustID & "")
            sqlConn.Close()
            Return strName
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
        Return Nothing
    End Function
    Private Sub QueryDetail()
        Try
            Dim sqlGetHeadOff As String
            Dim sqlGetTelHead As String
            Dim strAddr As String
            Dim strTel As String
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            sqlGetHeadOff = "SELECT TValue FROM DataConfig WHERE NAME='lbAddressLeft'"
            strAddr = clsScriptData.ExecuteSchalar(sqlConn, sqlGetHeadOff)
            sqlGetTelHead = "SELECT TValue FROM DataConfig WHERE Name = 'lbTelLeft'"
            strTel = clsScriptData.ExecuteSchalar(sqlConn, sqlGetTelHead)
            lblAddressL.Text = strAddr & "<BR>" & strTel
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetImage()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strClientIP As String
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))

            Dim sqlGetImg As String
            Dim dtLogo As New DataTable
            sqlGetImg = "Select Mill_Logo,Mill_Name_Eng From Mill Where Mill_Name='" & strFac & "'"
            dtLogo = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg)
            dvLogo.DataSource = dtLogo
            dvLogo.DataBind()
            dtLogo = Nothing

            Dim sqlFac As String
            Dim dsFac As New DataSet
            sqlFac = "Select  Mill_Address,'Tel. ' + ':' + convert(varchar,Mill_Tel,100) As Mill_Tel From Mill Where Mill_Name='" & strFac & "'"
            dsFac = clsScriptData.ExecuteData(sqlConn, sqlFac, "dtFac")
            lblAddrFac.Text = dsFac.Tables("dtFac").Rows(0)("Mill_Address") & " " & dsFac.Tables("dtFac").Rows(0)("Mill_Tel")
            dsFac = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function MillName(ByVal Mill As Integer) As String
        Dim Name As String = ""
        Select Case Mill
            Case 1
                Name = "SS"
            Case 2
                Name = "PS"
            Case 3
                Name = "TRR"
            Case 4
                Name = "TMI"
            Case 5
                Name = "TSI"
            Case 6
                Name = "BSI"
            Case Else
                Name = Nothing
        End Select
        Return Name
    End Function

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pnRpt.Visible = True
        QueryDetail()
        GetImage()
        HeadSum()
        LoadSumLot()
        Response.Write("<script>window.print();</script>")
        Session.Remove("Mill")
        Session.Remove("Cust")
        Session.Remove("Name")
        Session.Remove("strName")
        Session.Remove("intTrans")
        Session.Remove("strTruck")
        Session.Remove("Truck")
        Session.Remove("Recieve")
        Session.Remove("Province")
        Session.Remove("RemarkH")
    End Sub
End Class
