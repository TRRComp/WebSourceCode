﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class frmConfig
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim strFac As String '= clsScriptData.GetIPFac
    Dim Mode As String
    Dim strType As String
    Dim strLMill As String
    Dim strLAna As String
    Dim strLAuth As String
#Region "Sub And Function(Mill)"
    Private Sub LoadMill()
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Try
            Dim sqlMill As String
            Dim dsMill As New DataSet
            sqlMill = "SELECT Mill_Name,Mill_Name_Eng,Mill_Tel,Mill_Address FROM Mill "
            If Me.txtMillCode.Text <> "" Then
                sqlMill &= "Where Mill_Name LIKE '%" & Trim(txtMillCode.Text) & "%' "
            End If
            dsMill = clsScriptData.ExecuteData(sqlConn, sqlMill, "dtMill")
            If dsMill.Tables("dtMill").Rows.Count > 0 Then
                gvMill.DataSource = dsMill.Tables("dtMill")
                gvMill.DataBind()
            Else
                lblErr.Visible = True
                lblErr.Text = "Data not found"
            End If
            dsMill = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryMill(ByVal strMillCode As String)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Try
            Dim sqlMillDetail As String
            Dim dsMillDetail As New DataSet
            sqlMillDetail = "SELECT MILL,MILL_NAME,ANALYST_NAME,AUTHORIZE_NAME,MILL_LOGO,ANALYST_LOGO,AUTHORIZE_LOGO, "
            sqlMillDetail &= "logo1, logo2, logo3, logo4, ISO_No, ISO_Date,Logo1_No,Logo2_No,Logo3_No,Logo4_No "
            sqlMillDetail &= "FROM MILL WHERE MILL_NAME= '" & strMillCode & "' "
            dsMillDetail = clsScriptData.ExecuteData(sqlConn, sqlMillDetail, "dtMillDetail")
            If dsMillDetail.Tables("dtMillDetail").Rows.Count > 0 Then
                ViewState("strID") = dsMillDetail.Tables("dtMillDetail").Rows(0)("MILL")
                Me.txtAnalyst.Text = dsMillDetail.Tables("dtMillDetail").Rows(0)("ANALYST_NAME")
                Me.txtAuthorize.Text = dsMillDetail.Tables("dtMillDetail").Rows(0)("AUTHORIZE_NAME")
                If dsMillDetail.Tables("dtMillDetail").Rows(0)("ISO_Date") IsNot DBNull.Value Then
                    Me.txtIsoDate.Text = Format(dsMillDetail.Tables("dtMillDetail").Rows(0)("ISO_Date"), "dd/MM/yyyy")
                Else
                    Me.txtIsoDate.Text = "-"
                End If
                Me.txtIsoNo.Text = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("ISO_No"))
                ViewState("strLMill") = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("MILL_LOGO"))
                ViewState("strLAna") = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("ANALYST_LOGO"))
                ViewState("strLAuth") = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("AUTHORIZE_LOGO"))
                ViewState("strL1") = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("LOGO1"))
                ViewState("strL2") = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("LOGO2"))
                ViewState("strL3") = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("LOGO3"))
                ViewState("strL4") = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("LOGO4"))
                Me.txtDocLogo1.Text = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("Logo1_No"))
                Me.txtDocLogo2.Text = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("Logo2_No"))
                Me.txtDocLogo3.Text = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("Logo3_No"))
                Me.txtDocLogo4.Text = clsScriptData.DbnullToString(dsMillDetail.Tables("dtMillDetail").Rows(0)("Logo4_No"))
            Else
                lblErr.Visible = True
                lblErr.Text = "Data not found"
            End If
            dsMillDetail = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub SaveDataMill()
        Dim splitFileMill() As String
        Dim strFileMill As String
        If FileUpload.HasFile Then
            splitFileMill = FileUpload.PostedFile.FileName.Split("\")
            strFileMill = splitFileMill(splitFileMill.Length - 1)

            FileUpload.PostedFile.SaveAs(Server.MapPath("imgLogo\" & strFileMill))

        Else
            strFileMill = ViewState("strLMill")
            'Response.Write("<script>alert('No file to upload')</script>")
        End If
        Dim splitFileAnalyst() As String
        Dim strFileAnalyst As String
        If FileUpAnaly.HasFile Then
            splitFileAnalyst = FileUpAnaly.PostedFile.FileName.Split("\")
            strFileAnalyst = splitFileAnalyst(splitFileAnalyst.Length - 1)

            'FileUpAnaly.PostedFile.SaveAs(Server.MapPath("imgLogo\" & strFileAnalyst))
            'FileUpAnaly.PostedFile.SaveAs("\\intranet\programs$\sugar_review\imgLogo\" & strFileAnalyst)
            'FileUpAnaly.PostedFile.SaveAs("\\intranet\coa\backend_review\imgLogo\" & strFileAnalyst)
        Else
            strFileAnalyst = ViewState("strLAna")
        End If
        Dim splitFileAuth() As String
        Dim strFileAuth As String
        If FileUpAuth.HasFile Then
            splitFileAuth = FileUpAuth.PostedFile.FileName.Split("\")
            strFileAuth = splitFileAuth(splitFileAuth.Length - 1)
        Else
            strFileAuth = ViewState("strLAuth")
        End If
        Dim splitFile1() As String
        Dim strFile1 As String
        If FileUpload1.HasFile Then
            splitFile1 = FileUpload1.PostedFile.FileName.Split("\")
            strFile1 = splitFile1(splitFile1.Length - 1)
        Else
            strFile1 = ViewState("strL1")
        End If
        Dim splitFile2() As String
        Dim strFile2 As String
        If FileUpload2.HasFile Then
            splitFile2 = FileUpload2.PostedFile.FileName.Split("\")
            strFile2 = splitFile2(splitFile2.Length - 1)
        Else
            strFile2 = ViewState("strL2")
        End If
        Dim splitFile3() As String
        Dim strFile3 As String
        If FileUpload3.HasFile Then
            splitFile3 = FileUpload3.PostedFile.FileName.Split("\")
            strFile3 = splitFile3(splitFile3.Length - 1)
        Else
            strFile3 = ViewState("strL3")
        End If
        Dim splitFile4() As String
        Dim strFile4 As String
        If FileUpload4.HasFile Then
            splitFile4 = FileUpload4.PostedFile.FileName.Split("\")
            strFile4 = splitFile4(splitFile4.Length - 1)
        Else
            strFile4 = ViewState("strL4")
        End If

        Dim ddISO As String
        Dim MMISO As String
        Dim yyISO As String
        Dim strISO As String
        Dim strISODate As Date
        If txtIsoDate.Text = "" Or txtIsoDate.Text Is DBNull.Value Then
            strISODate = Date.Now
        Else
            ddISO = txtIsoDate.Text.Substring(0, 2)
            MMISO = txtIsoDate.Text.Substring(3, 2)
            yyISO = txtIsoDate.Text.Substring(6, 4)
            strISO = yyISO + "-" + MMISO + "-" + ddISO + " 00:00:00"
            strISODate = Convert.ToDateTime(strISO)
        End If

        If txtIsoNo.Text = "" Or txtIsoNo.Text Is DBNull.Value Then
            txtIsoNo.Text = "-"
        End If

        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Try
            Dim cmdUpdate As New SqlCommand("spUpdate_Mill", sqlConn)
            With cmdUpdate
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@Mill", ViewState("strID"))
                .Parameters.AddWithValue("@Mill_Name", Trim(Me.txtMillCode.Text))
                .Parameters.AddWithValue("@Mill_Name_Eng", Trim(Me.txtMillName.Text))
                .Parameters.AddWithValue("@Mill_Address", Trim(Me.txtAdd.Text))
                .Parameters.AddWithValue("@Mill_tel", Me.txtTel.Text)
                .Parameters.AddWithValue("@Mill_Logo", CStr(strFileMill))
                .Parameters.AddWithValue("@Analyst_name", Trim(Me.txtAnalyst.Text))
                .Parameters.AddWithValue("@Analyst_Logo", CStr(strFileAnalyst))
                .Parameters.AddWithValue("@Authorize_name", Trim(Me.txtAuthorize.Text))
                .Parameters.AddWithValue("@Authorize_Logo", CStr(strFileAuth))
                .Parameters.AddWithValue("@username", Me.Request.LogonUserIdentity.Name)
                .Parameters.AddWithValue("@Logo1", CStr(strFile1))
                .Parameters.AddWithValue("@Logo2", CStr(strFile2))
                .Parameters.AddWithValue("@Logo3", CStr(strFile3))
                .Parameters.AddWithValue("@Logo4", CStr(strFile4))
                .Parameters.AddWithValue("@ISO_Date", Format(CDate(strISODate), "yyyy-MM-dd"))
                .Parameters.AddWithValue("@ISO_No", Me.txtIsoNo.Text)
                .Parameters.AddWithValue("@Logo1_No", Me.txtDocLogo1.Text)
                .Parameters.AddWithValue("@Logo2_No", Me.txtDocLogo2.Text)
                .Parameters.AddWithValue("@Logo3_No", Me.txtDocLogo3.Text)
                .Parameters.AddWithValue("@Logo4_No", Me.txtDocLogo4.Text)
                .ExecuteNonQuery()
            End With
            ViewState.Remove("strID")
            ViewState.Remove("strLMill")
            ViewState.Remove("strLAna")
            ViewState.Remove("strLAuth")
            ViewState.Remove("strL1")
            ViewState.Remove("strL2")
            ViewState.Remove("strL3")
            ViewState.Remove("strL4")
            cmdUpdate = Nothing
            sqlConn.Close()
        Catch ex As Exception
            'Response.Write(ex.Message)
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ClearDataMill()
        Me.txtAdd.Text = ""
        Me.txtAnalyst.Text = ""
        Me.txtMillCode.Text = ""
        Me.txtMillName.Text = ""
        Me.txtTel.Text = ""
        Me.txtAnalyst.Text = ""
        Me.txtAuthorize.Text = ""
    End Sub
#End Region
#Region "Sub and Function(Item)"
    Private Sub QueryData(ByVal strMill As String)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlQuery As String
            Dim dsQuery As New DataSet
            Dim intMill As Integer
            intMill = MillCode(strMill)
            If rdbtnDRefine.Checked Then
                sqlQuery = "Select TestItem_ID,TestItem,Mill,SortItem,Domestic_Min_Refine As Min_Result,Domestic_Max_Refine As Max_Result from TestItem "
            ElseIf rdbtnDWhite.Checked Then
                sqlQuery = "Select TestItem_ID,TestItem,Mill,SortItem,Domestic_Min_White As Min_Result,Domestic_Max_White As Max_Result from TestItem "
            ElseIf rdbtnERefine.Checked Then
                sqlQuery = "Select TestItem_ID,TestItem,Mill,SortItem,Export_Min_Refine As Min_Result,Export_Max_Refine As Max_Result from TestItem "
            ElseIf rdbtnEWhite.Checked Then
                sqlQuery = "Select TestItem_ID,TestItem,Mill,SortItem,Export_Min_White As Min_Result,Export_Max_White As Max_Result from TestItem "
            Else
                sqlQuery = "Select TestItem_ID,TestItem,Mill,SortItem,Domestic_Min_White As Min_Result,Domestic_Max_White As Max_Result from TestItem "
            End If
            sqlQuery &= "Where Mill=" & intMill & " Order by SortItem"
            dsQuery = clsScriptData.ExecuteData(sqlConn, sqlQuery, "dtQuery")
            If dsQuery.Tables("dtQuery").Rows.Count <> 0 Then
                gvFillData.DataSource = dsQuery.Tables("dtQuery")
                gvFillData.DataBind()
            End If
            dsQuery = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function MillName(ByVal Mill As Integer) As String
        Dim Name As String = ""
        Select Case Mill
            Case 0
                Name = "Head Office"
            Case 1
                Name = "SS"
            Case 2
                Name = "PS"
            Case 3
                Name = "TRR"
            Case 4
                Name = "TMI"
            Case 5
                Name = "TSI"
            Case 6
                Name = "BSI"
            Case Else
                Name = Nothing
        End Select
        Return Name
    End Function
    Function MillCode(ByVal strName As String) As Integer
        Dim Code As Integer
        Select Case strName
            Case "Head Office"
                Code = 0
            Case "SS"
                Code = 1
            Case "PS"
                Code = 2
            Case "TRR"
                Code = 3
            Case "TMI"
                Code = 4
            Case "TSI"
                Code = 5
            Case "BSI"
                Code = 6
            Case Else
                Code = Nothing
        End Select
        Return Code
    End Function
    Private Sub LoadFac(ByVal Mill As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlFac As String
            Dim dsFac As New DataSet
            Dim strName As String
            strName = MillName(Mill)
            sqlFac = "Select '' AS Mill_Name,'' AS Mill_Name_Eng Union ALL "
            sqlFac &= "Select Mill_Name,Mill_Name_Eng from Mill "
            If strName <> "Head Office" Then
                sqlFac &= "WHERE Mill_Name='" & strName & "' "
            End If
            dsFac = clsScriptData.ExecuteData(sqlConn, sqlFac, "dtFac")
            If dsFac.Tables("dtFac").Rows.Count <> 0 Then
                ddlFactory.DataSource = dsFac.Tables("dtFac")
                ddlFactory.DataTextField = "Mill_Name_Eng"
                ddlFactory.DataValueField = "Mill_Name"
                ddlFactory.DataBind()
            End If
            dsFac = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub SaveDataItem(ByVal Mode As String)
        Try
            If txtItem.Text = "" Then
                Response.Write("'<script>alert('Empty Item Name.')</script>'")
                Exit Sub
            End If
            Dim strClientIP() As String
            Dim intFac As Integer
            strClientIP = Split(Request.UserHostAddress, ".")
            Dim strIPGet As String = ""
            Dim strIp As String = ""
            strIPGet = strClientIP(2)
            strFac = clsScriptData.GetIPFac(CInt(strIPGet))
            strIp = clsScriptData.RetIPFac(CInt(strIPGet))
            intFac = CInt(strIp)

            Dim intMill As Integer
            intMill = MillCode(Me.ddlFactory.SelectedValue)
            'intMill = intFac
            Dim intSort As Integer
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            intSort = clsScriptData.ExecuteSchalar(sqlConn, "Select Max(SortItem)+1 From TestItem Where Mill=" & intMill & "")

            If Mode = "Save" Then
                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdSave As New SqlCommand("spAdd_TestItem", sqlConn)
                With cmdSave
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@TestItem", Trim(Me.txtItem.Text))
                    .Parameters.AddWithValue("@Mill", intMill)
                    .Parameters.AddWithValue("@Sort", intSort)
                    If rdbtnDRefine.Checked Then
                        .Parameters.AddWithValue("@Domestic_Min_Refine", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Domestic_Max_Refine", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Domestic_Min_White", "")
                        .Parameters.AddWithValue("@Domestic_Max_White", "")
                        .Parameters.AddWithValue("@Export_Min_White", "")
                        .Parameters.AddWithValue("@Export_Max_White", "")
                        .Parameters.AddWithValue("@Export_Min_Refine", "")
                        .Parameters.AddWithValue("@Export_Max_Refine", "")
                    ElseIf rdbtnDWhite.Checked Then
                        .Parameters.AddWithValue("@Domestic_Min_White", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Domestic_Max_White", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Domestic_Min_Refine", "")
                        .Parameters.AddWithValue("@Domestic_Max_Refine", "")
                        .Parameters.AddWithValue("@Export_Min_White", "")
                        .Parameters.AddWithValue("@Export_Max_White", "")
                        .Parameters.AddWithValue("@Export_Min_Refine", "")
                        .Parameters.AddWithValue("@Export_Max_Refine", "")
                    ElseIf rdbtnERefine.Checked Then
                        .Parameters.AddWithValue("@Export_Min_Refine", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Export_Max_Refine", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Export_Min_White", "")
                        .Parameters.AddWithValue("@Export_Max_White", "")
                        .Parameters.AddWithValue("@Domestic_Min_White", "")
                        .Parameters.AddWithValue("@Domestic_Max_White", "")
                        .Parameters.AddWithValue("@Domestic_Min_Refine", "")
                        .Parameters.AddWithValue("@Domestic_Max_Refine", "")
                    ElseIf rdbtnEWhite.Checked Then
                        .Parameters.AddWithValue("@Export_Min_White", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Export_Max_White", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Export_Min_Refine", "")
                        .Parameters.AddWithValue("@Export_Max_Refine", "")
                        .Parameters.AddWithValue("@Domestic_Min_White", "")
                        .Parameters.AddWithValue("@Domestic_Max_White", "")
                        .Parameters.AddWithValue("@Domestic_Min_Refine", "")
                        .Parameters.AddWithValue("@Domestic_Max_Refine", "")
                    End If
                    .ExecuteNonQuery()
                End With
                cmdSave = Nothing
                sqlConn.Close()
            ElseIf Mode = "Update" Then
                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdUpdate As New SqlCommand("spUpdate_TestItem", sqlConn)
                With cmdUpdate
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@TestItem_ID", ViewState("TestItem_ID"))
                    .Parameters.AddWithValue("@TestItem", Trim(Me.txtItem.Text))
                    .Parameters.AddWithValue("@Mill", intMill)
                    If rdbtnDRefine.Checked Then
                        .Parameters.AddWithValue("@Domestic_Min_Refine", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Domestic_Max_Refine", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Domestic_Min_White", ViewState("DWhiteMin"))
                        .Parameters.AddWithValue("@Domestic_Max_White", ViewState("DWhiteMax"))
                        .Parameters.AddWithValue("@Export_Min_White", ViewState("EWhiteMin"))
                        .Parameters.AddWithValue("@Export_Max_White", ViewState("EWhiteMax"))
                        .Parameters.AddWithValue("@Export_Min_Refine", ViewState("ERefineMin"))
                        .Parameters.AddWithValue("@Export_Max_Refine", ViewState("ERefineMax"))
                    ElseIf rdbtnDWhite.Checked Then
                        .Parameters.AddWithValue("@Domestic_Min_White", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Domestic_Max_White", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Domestic_Min_Refine", ViewState("DRefineMin"))
                        .Parameters.AddWithValue("@Domestic_Max_Refine", ViewState("DRefineMax"))
                        .Parameters.AddWithValue("@Export_Min_White", ViewState("EWhiteMin"))
                        .Parameters.AddWithValue("@Export_Max_White", ViewState("EWhiteMax"))
                        .Parameters.AddWithValue("@Export_Min_Refine", ViewState("ERefineMin"))
                        .Parameters.AddWithValue("@Export_Max_Refine", ViewState("ERefineMax"))
                    ElseIf rdbtnERefine.Checked Then
                        .Parameters.AddWithValue("@Export_Min_Refine", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Export_Max_Refine", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Export_Min_White", ViewState("EWhiteMin"))
                        .Parameters.AddWithValue("@Export_Max_White", ViewState("EWhiteMax"))
                        .Parameters.AddWithValue("@Domestic_Min_White", ViewState("DWhiteMin"))
                        .Parameters.AddWithValue("@Domestic_Max_White", ViewState("DWhiteMax"))
                        .Parameters.AddWithValue("@Domestic_Min_Refine", ViewState("DRefineMin"))
                        .Parameters.AddWithValue("@Domestic_Max_Refine", ViewState("DRefineMax"))
                    ElseIf rdbtnEWhite.Checked Then
                        .Parameters.AddWithValue("@Export_Min_White", Trim(Me.txtMin.Text))
                        .Parameters.AddWithValue("@Export_Max_White", Trim(Me.txtMax.Text))
                        .Parameters.AddWithValue("@Export_Min_Refine", ViewState("ERefineMin"))
                        .Parameters.AddWithValue("@Export_Max_Refine", ViewState("ERefineMax"))
                        .Parameters.AddWithValue("@Domestic_Min_White", ViewState("DWhiteMin"))
                        .Parameters.AddWithValue("@Domestic_Max_White", ViewState("DWhiteMax"))
                        .Parameters.AddWithValue("@Domestic_Min_Refine", ViewState("DRefineMin"))
                        .Parameters.AddWithValue("@Domestic_Max_Refine", ViewState("DRefineMax"))
                    End If
                    .ExecuteNonQuery()
                End With
                ViewState.Remove("TestItem_ID")
                cmdUpdate = Nothing
                sqlConn.Close()
            End If
            ViewState.Remove("DWhiteMin")
            ViewState.Remove("DWhiteMax")
            ViewState.Remove("DRefineMin")
            ViewState.Remove("DRefineMax")
            ViewState.Remove("EWhiteMin")
            ViewState.Remove("EWhiteMax")
            ViewState.Remove("ERefineMin")
            ViewState.Remove("ERefineMax")
            Me.txtItem.Text = ""
            Me.txtMax.Text = ""
            Me.txtMin.Text = ""
            QueryData(Me.ddlFactory.SelectedValue)
        Catch ex As Exception
            Response.Write(ex.Message)
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub KeepMinMax(ByVal strMill As String, ByVal Item As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlKeepMinMax As String
            Dim dsKeep As New DataSet
            Dim DWhiteMin As String
            Dim DRefineMin As String
            Dim EWhiteMin As String
            Dim ERefineMin As String

            Dim DWhiteMax As String
            Dim DRefineMax As String
            Dim EWhiteMax As String
            Dim ERefineMax As String

            Dim intMill As Integer
            intMill = MillCode(strMill)

            sqlKeepMinMax = "Select TestItem_ID,TestItem,Mill,SortItem,Domestic_Min_Refine,Domestic_Max_Refine, "
            sqlKeepMinMax &= "Domestic_Min_White,Domestic_Max_White,Export_Min_Refine,Export_Max_Refine, "
            sqlKeepMinMax &= "Export_Min_White,Export_Max_White from TestItem "
            sqlKeepMinMax &= "Where Mill=" & intMill & " And TestItem_ID=" & Item & " Order by SortItem"
            dsKeep = clsScriptData.ExecuteData(sqlConn, sqlKeepMinMax, "dtKeep")
            DWhiteMin = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Domestic_Min_White"))
            DWhiteMax = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Domestic_Max_White"))
            DRefineMin = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Domestic_Min_Refine"))
            DRefineMax = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Domestic_Max_Refine"))
            EWhiteMin = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Export_Min_White"))
            EWhiteMax = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Export_Max_White"))
            ERefineMin = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Export_Min_Refine"))
            ERefineMax = clsScriptData.DbnullToString(dsKeep.Tables("dtKeep").Rows(0)("Export_Max_Refine"))

            ViewState("DWhiteMin") = DWhiteMin
            ViewState("DWhiteMax") = DWhiteMax
            ViewState("DRefineMin") = DRefineMin
            ViewState("DRefineMax") = DRefineMax
            ViewState("EWhiteMin") = EWhiteMin
            ViewState("EWhiteMax") = EWhiteMax
            ViewState("ERefineMin") = ERefineMin
            ViewState("ERefineMax") = ERefineMax
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub DeleteData(ByVal ItemID As Integer)
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdDel As New SqlCommand("spDelete_TestItem", sqlConn)
            With cmdDel
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@TestItem_ID", ItemID)
                .ExecuteNonQuery()
            End With
            Me.txtItem.Text = ""
            QueryData(ViewState("Fac"))
            cmdDel.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ClearDataItem()
        Me.txtItem.Text = ""
        Me.txtMax.Text = ""
        Me.txtMin.Text = ""
        ViewState.Remove("Fac")
        ViewState.Remove("TestItem_ID")
    End Sub
#End Region
#Region "Sub and Function(SugarType)"
    Private Sub QueryDataType()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlQuery As String
            Dim dsQuery As New DataSet
            sqlQuery = "Select * from Sugar_Type "
            dsQuery = clsScriptData.ExecuteData(sqlConn, sqlQuery, "dtQueryType")
            If dsQuery.Tables("dtQueryType").Rows.Count <> 0 Then
                gvSugarName.DataSource = dsQuery.Tables("dtQueryType")
                gvSugarName.DataBind()
            End If
            dsQuery = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub SaveDataSugar(ByVal Mode As String)
        Try
            If txtSugarName.Text = "" Then
                Response.Write("'<script>alert('Empty Item Name.')</script>'")
                Exit Sub
            End If
            Dim strClientIP() As String
            Dim intFac As Integer
            strClientIP = Split(Request.UserHostAddress, ".")
            Dim strIPGet As String = ""
            Dim strIp As String = ""
            strIPGet = strClientIP(2)
            strFac = clsScriptData.GetIPFac(CInt(strIPGet))
            strIp = clsScriptData.RetIPFac(CInt(strIPGet))
            intFac = CInt(strIp)

            If Mode = "Save" Then
                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdSave As New SqlCommand("spAdd_SugarType", sqlConn)
                With cmdSave
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@SugarName", Trim(Me.txtSugarName.Text))
                    .Parameters.AddWithValue("@UserName", Me.Request.LogonUserIdentity.Name)
                    .Parameters.AddWithValue("@Detail", "")
                    .ExecuteNonQuery()
                End With
                cmdSave = Nothing
                sqlConn.Close()
            ElseIf Mode = "Update" Then
                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdUpdate As New SqlCommand("spUpdate_SugarType", sqlConn)
                With cmdUpdate
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@Type_ID", ViewState("Type_ID"))
                    .Parameters.AddWithValue("@SugarName", Trim(Me.txtSugarName.Text))
                    .Parameters.AddWithValue("@UserName", Me.Request.LogonUserIdentity.Name)
                    .ExecuteNonQuery()
                End With
                ViewState.Remove("Type_ID")
                cmdUpdate = Nothing
                sqlConn.Close()
            End If
            Me.txtSugarName.Text = ""
            QueryDataType()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ClearDataType()
        Me.txtSugarName.Text = ""
        ViewState.Remove("Type_ID")
    End Sub
#End Region
#Region "Sub and Function(Transport_Lot)"
    Private Sub QueryTransType()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlSugar As String
            Dim dsSugar As New DataSet
            sqlSugar = "Select 0 as Type_ID, '' as Type_Name union all Select Type_ID,Type_Name From Sugar_Type order by type_id"
            dsSugar = clsScriptData.ExecuteData(sqlConn, sqlSugar, "dtSugar")
            If dsSugar.Tables("dtSugar").Rows.Count > 0 Then
                ddlSugar.DataValueField = "Type_ID"
                ddlSugar.DataTextField = "Type_Name"
                ddlSugar.DataSource = dsSugar.Tables("dtSugar")
                ddlSugar.DataBind()
            End If
            dsSugar = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryTypeLab(ByVal mill As Integer, ByVal Lot As String)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmdSelect As New SqlCommand("spSelect_SugarType", sqlConn)
            With cmdSelect
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@Mill", CInt(mill))
                .Parameters.AddWithValue("@Lot_no", Me.ddlLot.SelectedValue)
                .ExecuteNonQuery()
            End With

            Dim dsType As New DataSet
            dsType = clsScriptData.ExecuteDS(sqlConn, cmdSelect, "dtTypeLab")
            ddlSugar.DataTextField = "Sugar_Type"
            ddlSugar.DataValueField = "Type"
            ddlSugar.DataSource = dsType.Tables("dtTypeLab")
            ddlSugar.DataBind()

            dsType = Nothing
            cmdSelect.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadCustomer(ByVal Mill As Integer, ByVal PYears As String)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlCust As String
            Dim dsCust As New DataSet
            sqlCust = "Select 0 as Customer_ID,'' as Customer_Name union all "
            sqlCust &= "SELECT distinct CUSTOMER.CUSTOMER_ID,CUSTOMER.CUSTOMER_NAME From CUSTOMER "
            sqlCust &= "Right Join Transport_Lot TL ON Customer.CUSTOMER_ID=TL.Customer_ID "
            If Mill <> 0 Then
                sqlCust &= "Where TL.Fac_ID=" & Mill & " "
            End If
            sqlCust &= "And TL.Years='" & PYears & "' "
            dsCust = clsScriptData.ExecuteData(sqlConn, sqlCust, "tbCust")
            If dsCust.Tables("tbCust").Rows.Count > 0 Then
                ddlCustomer.DataTextField = "CUSTOMER_NAME"
                ddlCustomer.DataValueField = "CUSTOMER_ID"
                ddlCustomer.DataSource = dsCust.Tables("tbCust")
                ddlCustomer.DataBind()
            End If
            dsCust = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadRecieve()
        Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlRec As String
            sqlRec = "Select '' as recieve_Sugar,'' as recieve_Sugar1 union all "
            sqlRec &= "Select Distinct convert(varchar, Recieve_Sugar, 103) As Recieve_Sugar, "
            sqlRec &= "convert(varchar, Recieve_Sugar, 107) As Recieve_Sugar1 From Transport_Lot "
            sqlRec &= "where Fac_ID = " & ViewState("Fac") & " and Customer_ID=" & ddlCustomer.SelectedValue & " "
            sqlRec &= "And Years='" & ddlProdY.SelectedValue & "' "
            sqlRec &= "Order by Recieve_Sugar1"
            Dim dtRec As New DataTable
            dtRec = clsScriptData.ExecuteDataTable(sqlConn, sqlRec)
            ddlDateRec.DataTextField = "Recieve_Sugar1"
            ddlDateRec.DataValueField = "Recieve_Sugar"
            ddlDateRec.DataSource = dtRec
            ddlDateRec.DataBind()
            dtRec = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadLot(ByVal Mill As Integer, ByVal CustID As Integer, ByVal RecDate As String, ByVal strTruck As String)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlLot As String
            Dim dsLot As New DataSet
            Dim DateRec As Date
            Dim strRecDD As String
            Dim strRecMM As String
            Dim strRecYY As String
            Dim strRecDate As String
            strRecDate = RecDate
            strRecDD = RecDate.ToString.Substring(0, 2)
            strRecMM = RecDate.ToString.Substring(3, 2)
            strRecYY = RecDate.ToString.Substring(6, 4)
            strRecDate = strRecYY + "-" + strRecMM + "-" + strRecDD + " 00:00:00"
            DateRec = CDate(strRecDate)

            sqlLot = "SELECT '' as Lot_no union all "
            sqlLot &= "Select Lot_no FROM Transport_Lot "
            sqlLot &= "WHERE Fac_ID = " & Mill & " " 'And Car_License='" & strTruck & "' "
            If strTruck <> "" Then
                sqlLot &= "And Car_License='" & strTruck & "' "
            End If
            If CustID > 0 Then
                sqlLot &= "And Customer_ID = " & CustID & " "
            End If
            If strRecDate <> "" Then
                sqlLot &= "And Recieve_Sugar ='" & strRecDate & "' "
            End If

            sqlLot &= "Group by Lot_no ORDER BY Lot_no "
            dsLot = clsScriptData.ExecuteData(sqlConn, sqlLot, "dtLot")
            If dsLot.Tables("dtLot").Rows.Count > 0 Then
                ddlLot.DataTextField = "Lot_no"
                ddlLot.DataValueField = "Lot_no"
                ddlLot.DataSource = dsLot.Tables("dtLot")
                ddlLot.DataBind()
            End If
            dsLot = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadTruck(ByVal FacID As Integer, ByVal CustID As Integer, ByVal RecDate As String)
        Try
            Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlTruck As String
            Dim dsTruck As New DataSet
            Dim ddRec As String
            Dim MMRec As String
            Dim yyRec As String
            Dim strRec As String
            ddRec = ddlDateRec.SelectedValue.Substring(0, 2)
            MMRec = ddlDateRec.SelectedValue.Substring(3, 2)
            yyRec = ddlDateRec.SelectedValue.Substring(6, 4)
            If yyRec > 2500 Then
                yyRec = yyRec - 543
            End If
            strRec = yyRec + "-" + MMRec + "-" + ddRec + " 00:00:00"

            sqlTruck = "Select '' as Car_License,'' as Recieve_Sugar Union all "
            sqlTruck &= "Select Distinct Car_License, Recieve_Sugar From Transport_Lot "
            sqlTruck &= "Where Fac_Id=" & FacID & " And Customer_ID=" & CustID & " And Recieve_Sugar='" & strRec & "' "
            dsTruck = clsScriptData.ExecuteData(sqlConn, sqlTruck, "dtTruck")
            If dsTruck.Tables("dtTruck").Rows.Count <> 0 Then
                ddlTruck.DataTextField = "Car_License"
                ddlTruck.DataValueField = "Car_License"
                ddlTruck.DataSource = dsTruck.Tables("dtTruck")
                ddlTruck.DataBind()
            End If
            'End If
            sqlConn.Close()
            dsTruck = Nothing
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryTrans(ByVal Mill As Integer, ByVal CustID As Integer, ByVal LotNo As String, ByVal SugarType As Integer, ByVal CarLicense As String, ByVal RecDate As String)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strRec As String
            If clsScriptData.DbnullToString(RecDate) = "" Then
                lblErr.Visible = True
                lblErr.Text = "กรุณาเลือกวันที่ก่อน"
                Exit Sub
            Else
                lblErr.Visible = False
                Dim strRecSugar As Date
                Dim ddRec As String
                Dim MMRec As String
                Dim yyRec As String
                ddRec = RecDate.ToString.Substring(0, 2)
                MMRec = RecDate.ToString.Substring(3, 2)
                yyRec = RecDate.ToString.Substring(6, 4)
                strRec = yyRec + "-" + MMRec + "-" + ddRec + " 00:00:00"
                strRecSugar = CDate(strRec)
            End If


            Dim sqlQueryT As String
            Dim dsQueryT As New DataSet
            sqlQueryT = "Select TL.Trans_ID,TL.Lot_No,ST.[Type_Name],TL.Car_License,CM.Customer_Name,CM.Contact_Name "
            sqlQueryT &= "From Transport_Lot TL Left Join Sugar_Type ST "
            sqlQueryT &= "ON TL.Sugar_Type=ST.[Type_ID] Left Join Customer CM ON TL.Customer_ID=CM.Customer_ID "
            sqlQueryT &= "Left Join Mill ON TL.Fac_ID=Mill.Mill "
            If Mill <> 0 Then
                sqlQueryT &= "Where TL.Fac_ID = " & Mill & " "
            End If
            If CustID <> 0 Then
                sqlQueryT &= "And TL.Customer_ID = " & CustID & " "
            End If
            If LotNo <> "" Then
                sqlQueryT &= "And TL.Lot_No='" & LotNo & "' "
            End If
            If SugarType <> 0 Then
                sqlQueryT &= "And TL.Sugar_Type = " & SugarType & " "
            End If
            If CarLicense <> "" Then
                sqlQueryT &= "And TL.Car_License='" & CarLicense & "' "
            End If
            If RecDate <> "" Then
                sqlQueryT &= "And TL.Recieve_Sugar='" & strRec & "'"
            End If
            If ddlProdY.SelectedIndex > 0 Then
                sqlQueryT &= " And TL.Years='" & ddlProdY.SelectedItem.Text.Trim & "'"
            End If

            sqlQueryT &= "Order by TL.Trans_ID"
            dsQueryT = clsScriptData.ExecuteData(sqlConn, sqlQueryT, "dtQueryT")
            If dsQueryT.Tables("dtQueryT").Rows.Count > 0 Then
                gvTrans.DataSource = dsQueryT.Tables("dtQueryT")
                gvTrans.DataBind()
                LoadLot(Mill, CustID, RecDate, CarLicense)
                lblErrT.Visible = False
            Else
                lblErrT.Visible = True
                lblErrT.Text = "ไม่มีข้อมูลที่ระบุค่ะ"
            End If
            dsQueryT = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub EditDataTrans()
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()

            Dim strRecSugar As Date
            Dim ddRec As String
            Dim MMRec As String
            Dim yyRec As String
            Dim strRec As String
            If clsScriptData.DbnullToString(Me.txtEditRec.Text) <> "" Then
                ddRec = txtEditRec.Text.Substring(0, 2)
                MMRec = txtEditRec.Text.Substring(3, 2)
                yyRec = txtEditRec.Text.Substring(6, 4)
                strRec = yyRec + "-" + MMRec + "-" + ddRec + " 00:00:00"
                strRecSugar = CDate(strRec)
            End If

            Dim cmdUpdate As New SqlCommand("spUpdate_TransLot", sqlConn)
            With cmdUpdate
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@FacID", CInt(ViewState("Fac")))
                .Parameters.AddWithValue("@CustID", CInt(Me.ddlCustomer.SelectedValue))
                .Parameters.AddWithValue("@LotNO", Me.ddlLot.SelectedValue)
                If chkEditTruck.Checked = True Then
                    If clsScriptData.DbnullToString(Me.txtTruck.Text) <> "" Then
                        .Parameters.AddWithValue("@CarLicense", Me.txtTruck.Text.Trim)
                    Else
                        .Parameters.AddWithValue("@CarLicense", Me.ddlTruck.SelectedValue)
                    End If
                Else
                    .Parameters.AddWithValue("@CarLicense", Me.ddlTruck.SelectedValue)
                End If
                .Parameters.AddWithValue("@SugarType", CInt(Me.ddlSugar.SelectedValue))
                .Parameters.AddWithValue("@Trans_ID", CInt(ViewState("Trans_ID")))
                If clsScriptData.DbnullToString(Me.txtEditRec.Text) <> "" Then
                    .Parameters.AddWithValue("@RecDate", strRecSugar)
                Else
                    .Parameters.AddWithValue("@RecDate", CDate(Me.ddlDateRec.SelectedValue).ToString("yyyy-MM-dd"))
                End If
                .Parameters.AddWithValue("@UserName", Me.Request.LogonUserIdentity.Name)
                .ExecuteNonQuery()
            End With
            'ViewState.Remove("Trans_ID")

            cmdUpdate = Nothing
            sqlConn.Close()
            Dim strTruck As String
            Dim strDate As String
            If chkEditTruck.Checked = True Then
                strTruck = Trim(Me.txtTruck.Text)
                strDate = strRecSugar
            Else
                strTruck = Trim(Me.ddlTruck.SelectedValue)
                strDate = Trim(Me.ddlDateRec.SelectedValue)
            End If
            QueryTrans(CInt(ViewState("Fac")), CInt(Me.ddlCustomer.SelectedValue), Me.ddlLot.SelectedValue, Me.ddlSugar.SelectedValue, clsScriptData.DbnullToString(strTruck), clsScriptData.DbnullToString(strDate))
            LoadRecieve()
            ddlDateRec.SelectedIndex = 0
            ddlTruck.SelectedIndex = 0
            ddlLot.SelectedIndex = 0
            ddlSugar.SelectedIndex = 0
            Response.Write("<script>alert('แก้ไขข้อมูลเรียบร้อยแล้วค่ะ')</script>")
        Catch ex As Exception
            Response.Write(ex.Message)
            Response.Write(CInt(ViewState("Fac")) & ":" & CInt(Me.ddlCustomer.SelectedValue) & ":" & CStr(Me.ddlLot.SelectedValue) & ":" & Trim(Me.txtTruck.Text) & ":" & CInt(Me.ddlSugar.SelectedValue) & ":" & CInt(ViewState("Trans_ID")))
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub DelTransLot(ByVal Trans_ID As Integer)
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdDel As New SqlCommand("spDelete_TransLot", sqlConn)
            With cmdDel
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@ID", Trans_ID)
                .ExecuteNonQuery()
            End With
            cmdDel.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadProdYear(ByVal mill As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlYears As String
            Dim dsYears As New DataSet
            sqlYears = "Select '' as Years Union all Select Years from Transport_Lot "
            sqlYears &= "where Fac_ID=" & mill & " group by Years"
            dsYears = clsScriptData.ExecuteData(sqlConn, sqlYears, "dtYears")
            ddlProdY.DataTextField = "Years"
            ddlProdY.DataValueField = "Years"
            ddlProdY.DataSource = dsYears.Tables("dtYears")
            ddlProdY.DataBind()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function GetCustID(ByVal LotNo As String, ByVal TransID As Integer) As Integer
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlGetCustID As String
            Dim intCust As Integer
            sqlGetCustID = "Select Customer_ID From Transport_Lot Where Trans_ID=" & TransID & " And Lot_No='" & LotNo & "'"
            intCust = clsScriptData.ExecuteSchalar(sqlConn, sqlGetCustID)
            sqlConn.Close()
            Return intCust
        Catch ex As Exception
            Return 0
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Function GetTypeID(ByVal TypeName As String) As Integer
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlGetTypeID As String
            Dim intTypeS As Integer
            sqlGetTypeID = "select [Type_ID] from Sugar_Type where [Type_Name]='" & TypeName & "'"
            intTypeS = clsScriptData.ExecuteSchalar(sqlConn, sqlGetTypeID)
            sqlConn.Close()
            Return intTypeS
        Catch ex As Exception
            Return 0
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
#End Region

    Protected Sub imgbtnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnFilter.Click
        LoadMill()
    End Sub

    Protected Sub imgbtnClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClear.Click
        ClearDataMill()
    End Sub

    Protected Sub gvMill_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvMill.RowCommand
        If e.CommandName = "Select" Then
            Dim gvCurrent As GridViewRow = e.CommandSource.Parent.Parent
            'ViewState("strID") = CType(gvCurrent.Cells(0).FindControl("lnkID"), LinkButton).Text
            Me.txtMillCode.Text = CType(gvCurrent.Cells(0).FindControl("lnkID"), LinkButton).Text
            Me.txtMillName.Text = gvCurrent.Cells(1).Text.Replace("&nbsp;", "")
            Me.txtAdd.Text = gvCurrent.Cells(2).Text.Replace("&nbsp;", "")
            Me.txtTel.Text = gvCurrent.Cells(3).Text '.Replace("&nbsp;", "")
            QueryMill(Me.txtMillCode.Text.Trim)
        End If
    End Sub

    Protected Sub imgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSave.Click
        SaveDataMill()
    End Sub

    Protected Sub imgbtnItemAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnItemAdd.Click
        SaveDataItem("Save")
    End Sub

    Protected Sub imgbtnItemClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnItemClear.Click
        ClearDataItem()
    End Sub

    Protected Sub imgbtnItemEdit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnItemEdit.Click
        SaveDataItem("Update")
    End Sub

    Protected Sub imgbtnMill_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnMill.Click
        pnMill.Visible = True
        pnItem.Visible = False
        pnSugarType.Visible = False
        pnTrans.Visible = False
    End Sub

    Protected Sub imgbtnAddItem_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAddItem.Click
        pnMill.Visible = False
        pnItem.Visible = True
        pnSugarType.Visible = False
        pnTrans.Visible = False

        Dim strClientIP() As String
        Dim intFac As Integer
        strClientIP = Split(Request.UserHostAddress, ".")
        Dim strIPGet As String = ""
        Dim strIp As String = ""
        strIPGet = strClientIP(2)
        strFac = clsScriptData.GetIPFac(CInt(strIPGet))
        strIp = clsScriptData.RetIPFac(CInt(strIPGet))
        intFac = CInt(strIp)
        ViewState("Fac") = intFac

        LoadFac(ViewState("Fac"))
        If ViewState("Fac") <> 0 Then
            QueryData(MillName(ViewState("Fac")))
        End If
    End Sub

    Protected Sub imgbtnAddSugar_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAddSugar.Click
        pnMill.Visible = False
        pnItem.Visible = False
        pnSugarType.Visible = True
        pnTrans.Visible = False
        QueryDataType()
        'LoadFacType(ViewState("Fac"))
    End Sub

    Protected Sub imgbtnTransLot_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnTransLot.Click
        pnMill.Visible = False
        pnItem.Visible = False
        pnSugarType.Visible = False
        pnTrans.Visible = True

        Dim strClientIP() As String
        Dim intFac As Integer
        strClientIP = Split(Request.UserHostAddress, ".")
        Dim strIPGet As String = ""
        Dim strIp As String = ""
        strIPGet = strClientIP(2)
        strFac = clsScriptData.GetIPFac(CInt(strIPGet))
        strIp = clsScriptData.RetIPFac(CInt(strIPGet))
        intFac = CInt(strIp)

        If intFac = 0 Then intFac = 1
        ViewState("Fac") = intFac

        LoadProdYear(intFac)
        QueryTransType()
    End Sub

    Protected Sub gvFillData_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvFillData.RowCommand
        If e.CommandName = "Select" Then
            Dim gvCurrent As GridViewRow = e.CommandSource.Parent.Parent
            ViewState("TestItem_ID") = CType(gvCurrent.Cells(0).FindControl("lnkID"), LinkButton).Text
            Me.txtItem.Text = gvCurrent.Cells(1).Text.Replace("&amp;", "&")
            Me.txtMin.Text = gvCurrent.Cells(2).Text.Replace("&nbsp;", "")
            Me.txtMax.Text = gvCurrent.Cells(3).Text.Replace("&nbsp;", "")
            KeepMinMax(ddlFactory.SelectedValue, ViewState("TestItem_ID"))
        End If
        Mode = "Update"
    End Sub

    Protected Sub gvSugarName_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvSugarName.RowCommand
        If e.CommandName = "Select" Then
            Dim gvSugarName As GridViewRow = e.CommandSource.Parent.Parent
            ViewState("Type_ID") = CType(gvSugarName.Cells(0).FindControl("lnkID"), LinkButton).Text
            Me.txtSugarName.Text = gvSugarName.Cells(1).Text.Replace("&amp;", "&")
        End If
        Mode = "Update"
    End Sub

    Protected Sub imgbtnSugarAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSugarAdd.Click
        SaveDataSugar("Save")
    End Sub

    Protected Sub imgbtnSugarClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSugarClear.Click
        ClearDataType()
    End Sub

    Protected Sub imgbtnSugarEdit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSugarEdit.Click
        SaveDataSugar("Update")
    End Sub

    Protected Sub gvTrans_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvTrans.PageIndexChanging
        gvTrans.PageIndex = e.NewPageIndex
       QueryTrans(CInt(ViewState("Fac")), CInt(Me.ddlCustomer.SelectedValue), clsScriptData.DbnullToString(Me.ddlLot.SelectedValue), Me.ddlSugar.SelectedValue, clsScriptData.DbnullToString(Me.ddlTruck.SelectedValue), clsScriptData.DbnullToString(ddlDateRec.SelectedValue))
    End Sub

    Protected Sub gvTrans_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvTrans.RowCommand
        If e.CommandName = "Select" Then
            Dim gvTrans As GridViewRow = e.CommandSource.Parent.Parent
            ViewState("Trans_ID") = CType(gvTrans.Cells(0).FindControl("lnkID"), LinkButton).Text
            If ddlCustomer.SelectedValue = 0 Then Exit Sub
            If ddlLot.SelectedValue Is DBNull.Value Then Exit Sub
            'Me.ddlCustomer.SelectedValue = gvTrans.Cells(1).Text
            Me.ddlLot.SelectedValue = gvTrans.Cells(2).Text
            'Me.ddlSugar.SelectedValue = gvTrans.Cells(3).Text
            Me.ddlTruck.SelectedValue = clsScriptData.DbnullToString(gvTrans.Cells(4).Text)
            Me.ddlCustomer.SelectedValue = GetCustID(gvTrans.Cells(2).Text, CInt(ViewState("Trans_ID")))
            Me.ddlSugar.SelectedValue = GetTypeID(gvTrans.Cells(3).Text)
        End If
    End Sub

    Protected Sub imgbtnClearT_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClearT.Click
        Me.ddlDateRec.SelectedIndex = 0
        Me.ddlCustomer.SelectedIndex = 0
        Me.ddlLot.SelectedIndex = 0
        Me.ddlSugar.SelectedIndex = 0
    End Sub

    Protected Sub imgbtnEditT_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnEditT.Click
        EditDataTrans()
    End Sub

    Protected Sub imgbtnDelT_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelT.Click
        Dim Count As Integer
        For Count = 0 To Me.gvTrans.Rows.Count - 1
            If CType(Me.gvTrans.Rows(Count).FindControl("chkConfirmT"), CheckBox).Checked = True Then
                DelTransLot(CType(gvTrans.Rows(Count).Cells(0).FindControl("lnkID"), LinkButton).Text)
            End If
        Next
        QueryTrans(CInt(ViewState("Fac")), 0, "", 0, clsScriptData.DbnullToString(Me.ddlDateRec.SelectedValue), "")
    End Sub

    Protected Sub imgbtnFillT_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnFillT.Click
      QueryTrans(CInt(ViewState("Fac")), CInt(Me.ddlCustomer.SelectedValue), clsScriptData.DbnullToString(Me.ddlLot.SelectedValue), Me.ddlSugar.SelectedValue, clsScriptData.DbnullToString(Me.ddlTruck.SelectedValue), clsScriptData.DbnullToString(ddlDateRec.SelectedValue))
    End Sub

    Protected Sub ddlCustomer_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustomer.SelectedIndexChanged
        LoadRecieve()
    End Sub

    Protected Sub ddlLot_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlLot.SelectedIndexChanged
        QueryTypeLab(ViewState("Fac"), Me.ddlLot.SelectedValue)
    End Sub

    Protected Sub ddlFactory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFactory.SelectedIndexChanged
        QueryData(Me.ddlFactory.SelectedValue)
    End Sub

    Protected Sub rdbtnDRefine_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbtnDRefine.CheckedChanged
        rdbtnDRefine.Checked = True
        rdbtnDWhite.Checked = False
        rdbtnERefine.Checked = False
        rdbtnEWhite.Checked = False
    End Sub

    Protected Sub rdbtnDWhite_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbtnDWhite.CheckedChanged
        rdbtnDRefine.Checked = False
        rdbtnDWhite.Checked = True
        rdbtnERefine.Checked = False
        rdbtnEWhite.Checked = False
    End Sub

    Protected Sub rdbtnERefine_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbtnERefine.CheckedChanged
        rdbtnDRefine.Checked = False
        rdbtnDWhite.Checked = False
        rdbtnERefine.Checked = True
        rdbtnEWhite.Checked = False
    End Sub

    Protected Sub rdbtnEWhite_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbtnEWhite.CheckedChanged
        rdbtnDRefine.Checked = False
        rdbtnDWhite.Checked = False
        rdbtnERefine.Checked = False
        rdbtnEWhite.Checked = True
    End Sub

    Protected Sub ddlDateRec_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlDateRec.SelectedIndexChanged
        LoadTruck(ViewState("Fac"), CInt(Me.ddlCustomer.SelectedValue), ddlDateRec.SelectedValue)
    End Sub

    Protected Sub ddlTruck_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTruck.SelectedIndexChanged
        LoadLot(ViewState("Fac"), CInt(Me.ddlCustomer.SelectedValue), ddlDateRec.SelectedValue, ddlTruck.SelectedValue)
    End Sub

    Protected Sub chkEditTruck_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkEditTruck.CheckedChanged
        If chkEditTruck.Checked = True Then
            pnEditTrans.Visible = True
        Else
            pnEditTrans.Visible = False
        End If
    End Sub

    Protected Sub ddlProdY_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlProdY.SelectedIndexChanged
        LoadCustomer(ViewState("Fac"), Me.ddlProdY.SelectedValue)
    End Sub
End Class
