﻿Imports System.Web.UI.WebControls.Calendar

Partial Class Calendar
    Inherits System.Web.UI.Page
    Public strFormName As String
    Public strCtrlName As String
    Public strSelectedDate As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            myCalendar.SelectedDate = System.DateTime.Now()
        End If
        strSelectedDate = myCalendar.SelectedDate.ToString("dd/MM/yyyy")
        strCtrlName = "ctl00_ContentPlaceHolder1_" & Request.QueryString("CtrlName")
    End Sub
    Protected Sub Change_Date(ByVal sender As System.Object, ByVal e As System.EventArgs)
        strSelectedDate = "<script>window.opener.document.getElementById('" + strCtrlName + "').value= '"
        strSelectedDate += myCalendar.SelectedDate.ToString("dd/MM/yyyy")
        strSelectedDate += "'; window.close();"
        strSelectedDate += "</" + "script>"
        ClientScript.RegisterClientScriptBlock(Me.GetType, "Change_Date", strSelectedDate, False)
    End Sub
End Class
