﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.Web.Mail

Partial Class frmCustomer
    Inherits System.Web.UI.Page

    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim Mode As String
    Dim strID As Integer
    Dim strDate As Date
    Dim strFac As String
    Dim intIP As Integer
    Dim intFac As Integer
#Region "Sub and Function"
    Function GetintFac() As Integer
        Dim strclientIP() As String
        strclientIP = Split(Request.UserHostAddress, ".")
        Dim strIPGet As String = ""
        Dim strIp As String = ""
        strIPGet = strclientIP(2)
        strFac = clsScriptData.GetIPFac(CInt(strIPGet))
        strIp = clsScriptData.RetIPFac(CInt(strIPGet))
        intFac = CInt(strIp)
        'If intFac = 0 Then intFac = 1
        Return intFac
    End Function
    Private Sub LoadGrid()
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim sqLoad As String
        Dim dsLoad As New DataSet
        sqLoad = "SELECT Customer_ID,Customer_Name,Customer_Mail,Customer_Password,Contact_Name,Date_End "
        sqLoad &= "FROM Customer ORDER BY Customer_ID "
        dsLoad = clsScriptData.ExecuteData(sqlConn, sqLoad, "dtLoad")
        If dsLoad.Tables("dtLoad").Rows.Count > 0 Then
            gvCustomer.DataSource = dsLoad.Tables("dtLoad")
            gvCustomer.DataBind()
        Else
            lblErr.Visible = True
            lblErr.Text = "Data not found"
        End If
        dsLoad = Nothing
        sqlConn.Close()
    End Sub
    Private Sub SearchData()
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim sqlFilter As String
        Dim dsFilter As New DataSet
        sqlFilter = "SELECT Customer_ID,Customer_Name,Customer_Mail,Customer_Password,Contact_Name,Date_End "
        sqlFilter &= "FROM Customer "
        If txtCustName.Text <> "" Then
            sqlFilter &= "WHERE Customer_Name LIKE '%" & Trim(txtCustName.Text) & "%' "
        ElseIf txtCustMail.Text <> "" Then
            sqlFilter &= "WHERE Customer_Mail LIKE '%" & Trim(txtCustMail.Text) & "%' "
        ElseIf txtCustName.Text <> "" Then
            sqlFilter &= "WHERE Contact_Name LIKE '%" & Trim(txtContact.Text) & "%' "
        End If
        sqlFilter &= "ORDER BY Customer_ID"
        dsFilter = clsScriptData.ExecuteData(sqlConn, sqlFilter, "dtFilter")
        If dsFilter.Tables("dtFilter").Rows.Count > 0 Then
            gvCustomer.DataSource = dsFilter.Tables("dtFilter")
            gvCustomer.DataBind()
        Else
            lblErr.Visible = True
            lblErr.Text = "Data not found"
        End If
        dsFilter = Nothing
        sqlConn.Close()
    End Sub
    Private Sub ClearData()
        Me.txtContact.Text = ""
        Me.txtCustMail.Text = ""
        Me.txtCustName.Text = ""
        lblErr.Visible = False
    End Sub
    Private Sub SendMail()
        Dim strSubject As String
        Dim strMailSentTo As String
        Dim strContact As String

        'Get StrMail From
        Dim mailFM As String
        mailFM = clsScriptData.ExecuteSchalar(sqlConn, "SELECT TVALUE FROM DataConfig WHERE ID=8")

        SmtpMail.SmtpServer = "mail.trrsugar.com"
        Dim strBody As String
        strBody = "ชื่อบริษัทลูกค้า :" + Trim(Me.txtCustName.Text) + _
        "<br>ชื่อติดต่อ :" + Trim(Me.txtContact.Text) + _
        "<br>E-mail ลูกค้า :" + Trim(Me.txtCustMail.Text) + _
        "<br>รหัสผ่าน :" + ViewState("Pass")

        'Send mail to K.Suwit
        Dim msgMail As New MailMessage
        msgMail.BodyEncoding = Encoding.UTF8
        msgMail.From = "panidab@trrsugar.com"
        'msgMail.From = "E-mail Send From" & " " & mailFM
        'msgMail.To = Me.txtCustMail.Text
        msgMail.To = "suwit@trrsugar.com"
        msgMail.Subject = "Sugar Quality, Log on Info"
        msgMail.BodyFormat = MailFormat.Html
        msgMail.Body = strBody
        SmtpMail.Send(msgMail)

        'Send mail to admin
        msgMail.BodyEncoding = Encoding.UTF8
        'msgMail.From = "E-mail Send From" & " " & mailFM
        msgMail.From = "panidab@trrsugar.com"
        msgMail.To = "panidab@trrsugar.com"
        msgMail.Subject = "Sugar Quality, Log on Info"
        msgMail.BodyFormat = MailFormat.Html
        msgMail.Body = strBody
        SmtpMail.Send(msgMail)

        'Send mail to K.Vallop
        msgMail.BodyEncoding = Encoding.UTF8
        'msgMail.From = "E-mail Send From" & " " & mailFM
        msgMail.From = "panidab@trrsugar.com"
        msgMail.To = mailFM
        msgMail.Subject = "Sugar Quality, Log on Info"
        msgMail.BodyFormat = MailFormat.Html
        msgMail.Body = strBody
        SmtpMail.Send(msgMail)

        'Send mail to K.Ying
        msgMail.BodyEncoding = Encoding.UTF8
        'msgMail.From = "E-mail Send From" & " " & mailFM
        msgMail.From = "panidab@trrsugar.com"
        msgMail.To = "tassinee@trrsugar.com"
        msgMail.Subject = "Sugar Quality, Log on Info"
        msgMail.BodyFormat = MailFormat.Html
        msgMail.Body = strBody
        SmtpMail.Send(msgMail)
    End Sub
    Private Sub SaveData(ByVal Mode As String)
        'Dim strfac As Integer
        'strFac = clsScriptData.GetIPFac(CInt(strIP))
        intIP = GetintFac()
        'If intFac <> 0 Then
        '    lblErr.Visible = True
        '    lblErr.Text = "Sorry, you don't have permission!!!"
        '    'Response.Write("'<script>alert('Sorry, you don't have permission!!!')</script>'")
        '    Exit Sub
        'End If
        If txtCustMail.Text = "" Or txtCustMail.Text Is DBNull.Value Then
            Response.Write("'<script>alert('Request E-mail Customer')</script>'")
            Exit Sub
        End If
        lblErr.Visible = False
        If Mode = "Save" Then
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdSave As New SqlCommand("spAdd_Customer", sqlConn)
            With cmdSave
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@Customer_Name", Trim(Me.txtCustName.Text))
                .Parameters.AddWithValue("@Customer_Mail", Trim(Me.txtCustMail.Text))
                .Parameters.AddWithValue("@Contact_Name", Trim(Me.txtContact.Text))
                .Parameters.AddWithValue("@Username", Me.Request.LogonUserIdentity.Name)
                .ExecuteNonQuery()
            End With
            Dim strPassWord As String
            strPassWord = clsScriptData.ExecuteSchalar(sqlConn, "Select Customer_Password from Customer where Customer_Name='" & Trim(Me.txtCustName.Text) & "' and customer_mail='" & Trim(Me.txtCustMail.Text) & "'")
            ViewState("Pass") = strPassWord
            SendMail()
            LoadGrid()
            ViewState.Remove("Pass")
            cmdSave = Nothing
            sqlConn.Close()
        ElseIf Mode = "Update" Then
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdUpdate As New SqlCommand("spUpdate_Customer", sqlConn)
            With cmdUpdate
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@Customer_ID", ViewState("strID"))
                .Parameters.AddWithValue("@Customer_Name", Trim(Me.txtCustName.Text))
                .Parameters.AddWithValue("@Customer_Mail", Trim(Me.txtCustMail.Text))
                .Parameters.AddWithValue("@Contact_Name", Trim(Me.txtContact.Text))
                .Parameters.AddWithValue("@Username", Me.Request.LogonUserIdentity.Name)
                .Parameters.AddWithValue("@Date_End", ViewState("DateEnd"))
                .ExecuteNonQuery()
            End With
            LoadGrid()
            ViewState.Remove("strID")
            ViewState.Remove("DateEnd")
            cmdUpdate = Nothing
            sqlConn.Close()
        End If
    End Sub
    Private Sub DelData(ByVal CustID As Integer)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim cmdDel As New SqlCommand("spDelete_Customer", sqlConn)
        With cmdDel
            .CommandType = CommandType.StoredProcedure
            .Parameters.AddWithValue("@Customer_ID", CustID)
            .ExecuteNonQuery()
        End With
        cmdDel.Dispose()
        sqlConn.Close()
    End Sub
#End Region
    Protected Sub imgbtnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnFilter.Click
        SearchData()
    End Sub

    Protected Sub imgbtnAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAdd.Click
        SaveData("Save")
    End Sub

    Protected Sub imgbtnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelete.Click
        Dim Count As Integer
        For Count = 0 To Me.gvCustomer.Rows.Count - 1
            If CType(Me.gvCustomer.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                DelData(CType(Me.gvCustomer.Rows(Count).FindControl("lnkID"), LinkButton).Text)
            End If
        Next
        LoadGrid()
        ClearData()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If IsPostBack Then
            'CheckControl("Load")
        End If
    End Sub

    Protected Sub gvCustomer_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gvCustomer.PageIndexChanging
        gvCustomer.PageIndex = e.NewPageIndex
        LoadGrid()
    End Sub

    Protected Sub gvCustomer_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvCustomer.RowCommand
        If e.CommandName = "Select" Then
            Dim gvCurrent As GridViewRow = e.CommandSource.Parent.Parent
            ViewState("strID") = CType(gvCurrent.Cells(0).FindControl("lnkID"), LinkButton).Text
            Me.txtCustName.Text = gvCurrent.Cells(1).Text.Replace("&amp;", "&")
            Me.txtCustMail.Text = gvCurrent.Cells(2).Text
            Me.txtContact.Text = gvCurrent.Cells(5).Text.Replace("&nbsp;", "")
            ViewState("DateEnd") = CDate(gvCurrent.Cells(4).Text)
        End If
        Mode = "Update"
    End Sub

    Protected Sub imgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSave.Click
        SaveData("Update")
    End Sub

    Protected Sub imgbtnClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClear.Click
        ClearData()
    End Sub
End Class
