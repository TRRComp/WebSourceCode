﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class frmShowRpt
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim strFac As String '= clsScriptData.GetIPFac
#Region "QueryRptSugar"
    Private Sub LoadMill()
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim strClientIP As String
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))
            Dim sqlMill As String
            Dim dsMill As New DataSet
            sqlMill = "SELECT Mill,Mill_Name,Mill_Name_Eng FROM Mill "
            If strFac <> "Head Office" Then
                sqlMill &= "WHERE Mill_Name='" & strFac & "' "
                'sqlMill &= "WHERE Mill_Name='BSI' "
            End If
            dsMill = clsScriptData.ExecuteData(sqlConn, sqlMill, "dtMill")
            If dsMill.Tables("dtMill").Rows.Count > 0 Then
                ddlMill.DataValueField = "Mill"
                ddlMill.DataTextField = "Mill_Name_Eng"
                ddlMill.DataSource = dsMill.Tables("dtMill")
                ddlMill.DataBind()
                lblErr.Visible = False
            Else
                lblErr.Visible = True
                lblErr.Text = "Data not found"
            End If
            dsMill = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadCustomer()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlCust As String
            Dim dsCust As New DataSet
            'sqlCust = "Select 0 as CUSTOMER_ID,'' as CUSTOMER_NAME union all "
            'sqlCust &= "SELECT CUSTOMER_ID,CUSTOMER_NAME From CUSTOMER "
            sqlCust = "Select Distinct Customer.* From (Select 0 as CUSTOMER_ID,'' as CUSTOMER_NAME union all "
            sqlCust &= "SELECT CUSTOMER_ID,CUSTOMER_NAME From CUSTOMER) as Customer right join "
            sqlCust &= "SetSpec ON Customer.CUSTOMER_ID=SetSpec.Customer_ID "
            sqlCust &= "Where SetSpec.Mill=" & ddlMill.SelectedValue & " "
            dsCust = clsScriptData.ExecuteData(sqlConn, sqlCust, "tbCust")
            If dsCust.Tables("tbCust").Rows.Count > 0 Then
                ddlCustomer.DataTextField = "CUSTOMER_NAME"
                ddlCustomer.DataValueField = "CUSTOMER_ID"
                ddlCustomer.DataSource = dsCust.Tables("tbCust")
                ddlCustomer.DataBind()
            End If
            dsCust = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ShowCust()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlCust As String
            Dim dsCust As New DataSet
            sqlCust = "SELECT CUSTOMER_NAME From CUSTOMER "
            dsCust = clsScriptData.ExecuteData(sqlConn, sqlCust, "tbCust")
            If dsCust.Tables("tbCust").Rows.Count > 0 Then
                ddlCustomer.DataTextField = "CUSTOMER_NAME"
                ddlCustomer.DataValueField = "CUSTOMER_ID"
                ddlCustomer.DataSource = dsCust.Tables("tbCust")
                ddlCustomer.DataBind()
            End If
            dsCust = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadLot()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmLot As New SqlCommand("spSelect_Lot", sqlConn)
            cmLot.CommandType = CommandType.StoredProcedure
            cmLot.Parameters.AddWithValue("@mill", ddlMill.SelectedValue)
            cmLot.ExecuteNonQuery()
            Dim dsLot As New DataSet
            dsLot = clsScriptData.ExecuteDS(sqlConn, cmLot, "tbFillLot")
            ddlLot.DataTextField = "Lot_no"
            ddlLot.DataValueField = "Lot_no"
            ddlLot.DataSource = dsLot.Tables("tbFillLot")
            ddlLot.DataBind()
            LoadCustomer()
            dsLot = Nothing
            cmLot.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadType()
        Try
            ddlSugar.Items.Clear()
            ddlTruck.Items.Clear()
            ddlCustomer.SelectedIndex = 0
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmType As New SqlCommand("spSelect_SugarType", sqlConn)
            cmType.CommandType = CommandType.StoredProcedure
            cmType.Parameters.AddWithValue("@mill", ddlMill.SelectedValue)
            cmType.Parameters.AddWithValue("@Lot_no", ddlLot.SelectedValue)
            cmType.ExecuteNonQuery()
            Dim dsType As New DataSet
            dsType = clsScriptData.ExecuteDS(sqlConn, cmType, "tbFillType")
            ddlSugar.DataTextField = "Sugar_Type"
            ddlSugar.DataValueField = "Type"
            ddlSugar.DataSource = dsType.Tables("tbFillType")
            ddlSugar.DataBind()

            dsType = Nothing
            cmType.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryLogo()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmQueryHead As New SqlCommand("spLot_Data1", sqlConn)
            With cmQueryHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@mill", ddlMill.SelectedValue)
                .Parameters.AddWithValue("@Lot_no", ddlLot.SelectedValue)
                .Parameters.AddWithValue("@Sugar_Type", ddlSugar.SelectedValue)
                .ExecuteNonQuery()
            End With

            Dim dtQueryHead As New DataTable
            dtQueryHead = clsScriptData.ExecuteDT(sqlConn, cmQueryHead)
            dvLogo.DataSource = dtQueryHead
            dvLogo.DataBind()

            cmQueryHead.Dispose()
            dtQueryHead.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryMillRpt()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmQueryMill As New SqlCommand("spLot_Data1", sqlConn)
            With cmQueryMill
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@mill", ddlMill.SelectedValue)
                .Parameters.AddWithValue("@Lot_No", ddlLot.SelectedValue)
                .Parameters.AddWithValue("@Sugar_Type", ddlSugar.SelectedValue)
                .ExecuteNonQuery()
            End With

            Dim dtQueryMill As New DataTable
            dtQueryMill = clsScriptData.ExecuteDT(sqlConn, cmQueryMill)
            dvFac.DataSource = dtQueryMill
            dvFac.DataBind()

            cmQueryMill.Dispose()
            dtQueryMill.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryHeader()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmRptHead As New SqlCommand("spLot_Data1", sqlConn)
            With cmRptHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@mill", ddlMill.SelectedValue)
                .Parameters.AddWithValue("@Lot_No", ddlLot.SelectedValue)
                .Parameters.AddWithValue("@Sugar_Type", ddlSugar.SelectedValue)
                .ExecuteNonQuery()
            End With

            Dim dtHead As New DataTable
            dtHead = clsScriptData.ExecuteDT(sqlConn, cmRptHead)
            dvHeadRpt.DataSource = dtHead
            dvHeadRpt.DataBind()

            dvRemarks.DataSource = dtHead
            dvRemarks.DataBind()

            DvAnalyst.DataSource = dtHead
            DvAnalyst.DataBind()

            DvAuthorize.DataSource = dtHead
            DvAuthorize.DataBind()

            cmRptHead.Dispose()
            dtHead.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryDetail()
        Try
            QueryLogo()
            QueryMillRpt()
            QueryHeader()
            Dim sqlGetHeadOff As String
            Dim sqlGetTelHead As String
            Dim strAddr As String
            Dim strTel As String
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            sqlGetHeadOff = "SELECT TValue FROM DataConfig WHERE NAME='lbAddressLeft'"
            strAddr = clsScriptData.ExecuteSchalar(sqlConn, sqlGetHeadOff)
            sqlGetTelHead = "SELECT TValue FROM DataConfig WHERE Name = 'lbTelLeft'"
            strTel = clsScriptData.ExecuteSchalar(sqlConn, sqlGetTelHead)
            lblAddressL.Text = strAddr & "<br>" & strTel
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadTruck(ByVal FacID As Integer, ByVal LotNo As String, ByVal Type As Integer, ByVal CustID As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlTruck As String
            Dim dsTruck As New DataSet
            'If CustID = 321 Then
            sqlTruck = "Select 0 As Trans_ID,'' as Car_License,'' as DisPlayCar,'' as Recieve_Sugar Union all "
            sqlTruck &= "Select Trans_ID,Car_License,Car_License + '  ' + ' : ' + Remark + '  ' + 'Recieved' + ' : ' + convert(varchar, Recieve_Sugar, 6) "
            sqlTruck &= "As DisPlayCar,Recieve_Sugar From Transport_Lot Where Fac_Id=" & FacID & " And Lot_No='" & LotNo & "' And Sugar_Type=" & Type & " "
            sqlTruck &= "and Customer_ID=" & CustID & " Order by Recieve_Sugar"
            dsTruck = clsScriptData.ExecuteData(sqlConn, sqlTruck, "dtTruck")
            If dsTruck.Tables("dtTruck").Rows.Count <> 0 Then
                ddlTruck.DataTextField = "DisPlayCar"
                ddlTruck.DataValueField = "Trans_ID"
                ddlTruck.DataSource = dsTruck.Tables("dtTruck")
                ddlTruck.DataBind()
            End If
            'Else
            '    sqlTruck = "Select '' as Car_License,'' as DisPlayCar,'' as Recieve_Sugar Union all "
            '    sqlTruck &= "Select Car_License,Car_License + '  ' + 'Recieved' + ' : ' + convert(varchar, Recieve_Sugar, 6) As DisPlayCar,Recieve_Sugar From Transport_Lot "
            '    sqlTruck &= "Where Fac_Id=" & FacID & " And Lot_No='" & LotNo & "' And Sugar_Type=" & Type & " And Customer_ID=" & CustID & " Order by Recieve_Sugar"
            '    dsTruck = clsScriptData.ExecuteData(sqlConn, sqlTruck, "dtTruck")
            '    If dsTruck.Tables("dtTruck").Rows.Count <> 0 Then
            '        ddlTruck.DataTextField = "DisPlayCar"
            '        ddlTruck.DataValueField = "Car_License"
            '        ddlTruck.DataSource = dsTruck.Tables("dtTruck")
            '        ddlTruck.DataBind()
            '    End If
            'End If

            sqlConn.Close()
            dsTruck = Nothing
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ShowRpt()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strCustName As String
            strCustName = clsScriptData.ExecuteSchalar(sqlConn, "SELECT Customer_Name FROM Customer WHERE Customer_ID=" & ddlCustomer.SelectedValue & "")
            lblHeadRpt.Text = strCustName
            sqlConn.Close()
            'Dim strCarLicense As String
            'strCarLicense = clsScriptData.ExecuteSchalar(sqlConn, "SELECT Car_License from Transport_Lot Where Customer_ID=" & ddlCustomer.SelectedValue & " and Fac_ID=" & CInt(ddlMill.SelectedValue) & " and Lot_No='" & ddlLot.SelectedValue & "'")
            'lblLicense.Text = strCarLicense
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlTran As String
            Dim dsShowTrans As New DataSet

            If ddlCustomer.SelectedValue = 321 Then
                sqlTran = "Select Car_License,Province,Remark,Recieve_Sugar from Transport_Lot Where Customer_ID=" & ddlCustomer.SelectedValue & " "
                sqlTran &= "and Fac_ID=" & CInt(ddlMill.SelectedValue) & " and Lot_No='" & ddlLot.SelectedValue & "' "
                If chkTransport.Checked = True Then
                    sqlTran &= "And Trans_ID=" & ViewState("intTrans") & ""
                Else
                    sqlTran &= "And Trans_ID=" & CInt(ddlTruck.SelectedValue) & ""
                End If
            Else
                sqlTran = "Select Car_License,Province,Remark,Recieve_Sugar from Transport_Lot Where Customer_ID=" & ddlCustomer.SelectedValue & " "
                sqlTran &= "and Fac_ID=" & CInt(ddlMill.SelectedValue) & " and Lot_No='" & ddlLot.SelectedValue & "' And Trans_ID='" & Trim(ddlTruck.SelectedValue) & "' "
            End If
            dsShowTrans = clsScriptData.ExecuteData(sqlConn, sqlTran, "dtTrans")
            If dsShowTrans.Tables("dtTrans").Rows.Count > 0 Then
                lblLicense.Text = clsScriptData.DbnullToString(dsShowTrans.Tables("dtTrans").Rows(0)("Car_License"))
                lblRecieve.Text = clsScriptData.DbnullToString(Format(dsShowTrans.Tables("dtTrans").Rows(0)("Recieve_Sugar"), "dd/MM/yyyy"))
                lblProv.Text = clsScriptData.DbnullToString(dsShowTrans.Tables("dtTrans").Rows(0)("Province"))
                lblRemarkH.Text = clsScriptData.DbnullToString(dsShowTrans.Tables("dtTrans").Rows(0)("Remark"))
                dsShowTrans = Nothing
                sqlConn.Close()
            Else
                If chkTransport.Checked = True Then
                    lblLicense.Text = txtCarLic.Text
                    lblRecieve.Text = txtRecieve.Text 'Format(CDate(txtRecieve.Text), "dd/MM/yyyy")
                    lblProv.Text = txtProvince.Text
                    lblRemarkH.Text = txtRemark.Text
                    sqlConn.Close()
                Else
                    lblLicense.Text = ""
                    lblRecieve.Text = ""
                    lblProv.Text = ""
                    lblRemarkH.Text = ""
                    sqlConn.Close()
                End If
            End If

            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmQeryRpt As New SqlCommand("spLot_Data_Table1", sqlConn)
            With cmQeryRpt
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@mill", CInt(ddlMill.SelectedValue))
                .Parameters.AddWithValue("@Lot_no", ddlLot.SelectedValue)
                '.Parameters.AddWithValue("@Sugar_Type", ddlSugar.SelectedValue)
                If ddlCustomer.SelectedValue > 0 Then
                    .Parameters.AddWithValue("@Customer_ID", ddlCustomer.SelectedValue)
                Else
                    .Parameters.AddWithValue("@Customer_ID", 0)
                End If
                If ddlSugar.SelectedValue = 1 Or ddlSugar.SelectedValue = 2 Then
                    .Parameters.AddWithValue("@Sugar_Type", "E")
                ElseIf ddlSugar.SelectedValue = 3 Or ddlSugar.SelectedValue = 4 Then
                    .Parameters.AddWithValue("@Sugar_Type", "D")
                Else
                    .Parameters.AddWithValue("@Sugar_Type", ddlSugar.SelectedValue)
                End If
                If ddlSugar.SelectedValue = 1 Or ddlSugar.SelectedValue = 3 Then
                    .Parameters.AddWithValue("@SugarName", "White")
                ElseIf ddlSugar.SelectedValue = 2 Or ddlSugar.SelectedValue = 4 Then
                    .Parameters.AddWithValue("@SugarName", "Refine")
                Else
                    .Parameters.AddWithValue("@SugarName", ddlSugar.SelectedItem.ToString)
                End If
                .ExecuteNonQuery()
            End With

            Dim dtQuert As New DataTable
            dtQuert = clsScriptData.ExecuteDT(sqlConn, cmQeryRpt)
            gvShowRpt.DataSource = dtQuert
            gvShowRpt.DataBind()

            cmQeryRpt.Dispose()
            dtQuert.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            Response.Write(ex.Message)
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetImage()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlGetImg1 As String
            Dim dtLogo1 As New DataTable
            sqlGetImg1 = "Select Logo1,Logo1_No From Mill Where Mill=" & ddlMill.SelectedValue & ""
            dtLogo1 = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg1)
            DvLogo1.DataSource = dtLogo1
            DvLogo1.DataBind()

            Dim sqlGetImg2 As String
            Dim dtLogo2 As New DataTable
            sqlGetImg2 = "Select Logo2,Logo2_No From Mill Where Mill=" & ddlMill.SelectedValue & ""
            dtLogo2 = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg2)
            DvLogo2.DataSource = dtLogo2
            DvLogo2.DataBind()

            Dim sqlGetImg3 As String
            Dim dtLogo3 As New DataTable
            sqlGetImg3 = "Select Logo3,Logo3_No From Mill Where Mill=" & ddlMill.SelectedValue & ""
            dtLogo3 = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg3)
            DvLogo3.DataSource = dtLogo3
            DvLogo3.DataBind()

            Dim sqlGetImg4 As String
            Dim dtLogo4 As New DataTable
            sqlGetImg4 = "Select Logo4,Logo4_No From Mill Where Mill=" & ddlMill.SelectedValue & ""
            dtLogo4 = clsScriptData.ExecuteDataTable(sqlConn, sqlGetImg4)
            DvLogo4.DataSource = dtLogo4
            DvLogo4.DataBind()

            dtLogo1 = Nothing
            dtLogo2 = Nothing
            dtLogo3 = Nothing
            dtLogo4 = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetRefNo()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strRefNo As String
            strRefNo = clsScriptData.ExecuteSchalar(sqlConn, "select Referance_no from lab where Mill=" & ddlMill.SelectedValue & " and Lot_No='" & ddlLot.SelectedValue & "' and sugar_type='" & ddlSugar.SelectedValue & "'")
            lblRef.Text = ""
            lblRef.Text = strRefNo
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
#End Region
#Region "Sub checkLot"
    Private Sub AddLot()
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Try
            Dim strRecSugar As Date
            Dim ddRec As String
            Dim MMRec As String
            Dim yyRec As String
            Dim strRec As String
            ddRec = txtRecieve.Text.Substring(0, 2)
            MMRec = txtRecieve.Text.Substring(3, 2)
            yyRec = txtRecieve.Text.Substring(6, 4)
            strRec = yyRec + "-" + MMRec + "-" + ddRec + " 00:00:00"
            strRecSugar = CDate(strRec)

            Dim cmdSave As New SqlCommand("spAdd_TransLot", sqlConn)
            With cmdSave
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@CustId", Me.ddlCustomer.SelectedValue)
                .Parameters.AddWithValue("@FacId", Me.ddlMill.SelectedValue)
                .Parameters.AddWithValue("@LotNo", Me.ddlLot.SelectedValue)
                .Parameters.AddWithValue("@CarLicense", Me.txtCarLic.Text)
                .Parameters.AddWithValue("@SugarType", Me.ddlSugar.SelectedValue)
                .Parameters.AddWithValue("@UserName", Me.Request.LogonUserIdentity.Name)
                .Parameters.AddWithValue("@Province", Me.txtProvince.Text.Trim)
                .Parameters.AddWithValue("@Remark", Me.txtRemark.Text.Trim)
                .Parameters.AddWithValue("@RecSugar", strRecSugar)
                .ExecuteNonQuery()
            End With
            cmdSave.Dispose()
            ViewState("intTrans") = LoadIntTrans()
            ''If ddlCustomer.SelectedValue = 321 Then
            'If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            'Dim intTrans As Integer
            'Dim sql As String
            'sql = "Select Trans_ID from Transport_Lot Where Fac_Id=" & ddlMill.SelectedValue & " And Lot_No='" & ddlLot.SelectedValue & "' "
            'sql &= "And Sugar_Type=" & ddlSugar.SelectedValue & " and Customer_ID=" & ddlCustomer.SelectedValue & " "
            'sql &= "And Remark='" & txtRemark.Text.Trim & "' And Recieve_Sugar='" & strRec & "'"
            'intTrans = clsScriptData.ExecuteSchalar(sqlConn, sql)
            'ViewState("intTrans") = intTrans
            sqlConn.Close()
            'End If
            'sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub UpdateCopy()
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim sqlUpCopy As String
            sqlUpCopy = "Update Transport_Lot Set "
            sqlUpCopy &= "CopyPage='" & txtcopy.Text.Trim & "',ReviseNo='" & txtReverse.Text.Trim & "' "
            sqlUpCopy &= "Where Fac_Id=" & Me.ddlMill.SelectedValue & " And Lot_No='" & Me.ddlLot.SelectedValue & "' "
            sqlUpCopy &= "And Sugar_Type=" & Me.ddlSugar.SelectedValue & ""
            Dim cmdUpCopy As New SqlCommand(sqlUpCopy, sqlConn)
            cmdUpCopy.ExecuteNonQuery()
            cmdUpCopy.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function LoadIntTrans() As Integer
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim strRecSugar As Date
            Dim ddRec As String
            Dim MMRec As String
            Dim yyRec As String
            Dim strRec As String
            ddRec = txtRecieve.Text.Substring(0, 2)
            MMRec = txtRecieve.Text.Substring(3, 2)
            yyRec = txtRecieve.Text.Substring(6, 4)
            If yyRec > 2500 Then
                yyRec = yyRec - 543
            End If
            strRec = yyRec + "-" + MMRec + "-" + ddRec + " 00:00:00"
            strRecSugar = CDate(strRec)

            Dim intTrans As Integer
            Dim sql As String
            sql = "Select Trans_ID from Transport_Lot Where Fac_Id=" & ddlMill.SelectedValue & " And Lot_No='" & ddlLot.SelectedValue & "' "
            sql &= "And Sugar_Type=" & ddlSugar.SelectedValue & " and Customer_ID=" & ddlCustomer.SelectedValue & " "
            sql &= "And Remark='" & txtRemark.Text.Trim & "' And Recieve_Sugar='" & strRec & "' And Car_License='" & txtCarLic.Text.Trim & "'"
            intTrans = clsScriptData.ExecuteSchalar(sqlConn, sql)
            sqlConn.Close()
            Return intTrans
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
#End Region
#Region "PrintSumLot"
    Private Sub LoadCustSum()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlCust As String
            Dim dsCust As New DataSet
            sqlCust = "Select Distinct Customer.* From (Select 0 as CUSTOMER_ID,'' as CUSTOMER_NAME union all "
            sqlCust &= "SELECT CUSTOMER_ID,CUSTOMER_NAME From CUSTOMER) as Customer right join "
            sqlCust &= "SetSpec ON Customer.CUSTOMER_ID=SetSpec.Customer_ID "
            sqlCust &= "Where SetSpec.Mill=" & ddlMill.SelectedValue & " "
            dsCust = clsScriptData.ExecuteData(sqlConn, sqlCust, "tbCust")
            If dsCust.Tables("tbCust").Rows.Count > 0 Then
                ddlCustPrint.DataTextField = "CUSTOMER_NAME"
                ddlCustPrint.DataValueField = "CUSTOMER_ID"
                ddlCustPrint.DataSource = dsCust.Tables("tbCust")
                ddlCustPrint.DataBind()
            End If
            'ddlCustGen.Items.Clear()
            'ddlRecDate.Items.Clear()
            'ddlCarPrint.Items.Clear()
            dsCust = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadTruckSum(ByVal FacID As Integer, ByVal CustID As Integer, ByVal Remark As String, ByVal RecDate As String)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlTruck As String
            Dim dsTruck As New DataSet
            Dim ddRec As String
            Dim MMRec As String
            Dim yyRec As String
            Dim strRec As String
            ddRec = ddlRecDate.SelectedValue.Substring(0, 2)
            MMRec = ddlRecDate.SelectedValue.Substring(3, 2)
            yyRec = ddlRecDate.SelectedValue.Substring(6, 4)
            If yyRec > 2500 Then
                yyRec = yyRec - 543
            End If
            strRec = yyRec + "-" + MMRec + "-" + ddRec + " 00:00:00"

            sqlTruck = "Select '' as Car_License,'' as Recieve_Sugar Union all "
            sqlTruck &= "Select Distinct Car_License, Recieve_Sugar From Transport_Lot "
            sqlTruck &= "Where Fac_Id=" & FacID & " And Customer_ID=" & CustID & " And Recieve_Sugar='" & strRec & "' "
            If ddlCustPrint.SelectedValue = 321 Then
                sqlTruck &= "And Remark='" & Remark & "' Order by Recieve_Sugar"
            End If
            dsTruck = clsScriptData.ExecuteData(sqlConn, sqlTruck, "dtTruck")
            If dsTruck.Tables("dtTruck").Rows.Count <> 0 Then
                ddlCarPrint.DataTextField = "Car_License"
                ddlCarPrint.DataValueField = "Car_License"
                ddlCarPrint.DataSource = dsTruck.Tables("dtTruck")
                ddlCarPrint.DataBind()
            End If
            'End If
            sqlConn.Close()
            dsTruck = Nothing
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadRecDate(ByVal FacID As Integer, ByVal CustID As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlRec As String
            Dim dsRec As New DataSet
            sqlRec = "Select '' As Recieve_Sugar Union All "
            sqlRec &= "Select Distinct convert(varchar, Recieve_Sugar, 103) As Recieve_Sugar From Transport_Lot "
            sqlRec &= "Where Fac_Id=" & FacID & " And Customer_ID=" & CustID & " Order By Recieve_Sugar"
            dsRec = clsScriptData.ExecuteData(sqlConn, sqlRec, "dtRec")
            ddlRecDate.DataTextField = "Recieve_Sugar"
            ddlRecDate.DataValueField = "Recieve_Sugar"
            ddlRecDate.DataSource = dsRec.Tables("dtRec")
            ddlRecDate.DataBind()
            dsRec = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadRemarkSum(ByVal FacID As Integer, ByVal CustID As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlRemark As String
            Dim dsRemark As New DataSet
            sqlRemark = "Select '' As Remark Union All "
            sqlRemark &= "Select Distinct Remark From Transport_Lot Where Customer_ID=" & CustID & " And Fac_Id=" & FacID & ""
            dsRemark = clsScriptData.ExecuteData(sqlConn, sqlRemark, "dtRemark")
            ddlCustGen.DataTextField = "Remark"
            ddlCustGen.DataValueField = "Remark"
            ddlCustGen.DataSource = dsRemark.Tables("dtRemark")
            ddlCustGen.DataBind()
            dsRemark = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
#End Region
    ''#Region "SubSendMail"
    ''    Private Sub LoadCustMail(ByVal custID As Integer)
    ''        Try
    ''            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
    ''            Dim sqlCustMail As String
    ''            Dim dsCustMail As New DataSet
    ''            sqlCustMail = "Select Customer_Mail,Province from Customer_Email "
    ''            sqlCustMail &= "Where Customer_ID=" & custID & ""
    ''            dsCustMail = clsScriptData.ExecuteData(sqlConn, sqlCustMail, "dtCustmail")
    ''            If dsCustMail.Tables("dtCustmail").Rows.Count <> 0 Then
    ''                gvListMail.DataSource = dsCustMail.Tables("dtCustmail")
    ''                gvListMail.DataBind()
    ''            End If
    ''            SumLot()
    ''            dsCustMail = Nothing
    ''            sqlConn.Close()
    ''        Catch ex As Exception
    ''            sqlConn.Close()
    ''            sqlConn.Dispose()
    ''        End Try
    ''    End Sub
    ''    Private Sub SendMail()
    ''        Try

    ''            SmtpMail.SmtpServer = "mail.trrsugar.com"

    ''            Dim msgMail As New MailMessage
    ''            msgMail.BodyEncoding = Encoding.UTF8

    ''            'msgMail.To = "vallop@trrsugar.com"  
    ''            'msgMail.To = "panidab@trrsugar.com"
    ''            Dim strMSGTo As String = ""
    ''            Dim Count As Integer
    ''            For Count = 0 To Me.gvListMail.Rows.Count - 1
    ''                If CType(Me.gvListMail.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
    ''                    strMSGTo = Me.gvListMail.Rows(Count).Cells(0).Text
    ''                End If
    ''            Next
    ''            msgMail.To = strMSGTo
    ''            Dim strMill As String = ""
    ''            If ddlMill.SelectedValue = 1 Then
    ''                msgMail.From = "labss@trrsugar.com"
    ''                strMill = "SARABURI SUGAR CO., LTD."
    ''            ElseIf ddlMill.SelectedValue = 2 Then
    ''                msgMail.From = "katika@trrsugar.com"
    ''                strMill = "PHITSANULOK SUGAR CO., LTD."
    ''            ElseIf ddlMill.SelectedValue = 3 Then
    ''                msgMail.From = "nattawan@trrsugar.com"
    ''                strMill = "THAI ROONG RUANG INDUSTRY CO., LTD."
    ''            ElseIf ddlMill.SelectedValue = 4 Then
    ''                msgMail.From = "neitchanok@trrsugar.com"
    ''                strMill = "THAI MULTI-SUGAR INDUSTRY CO., LTD."
    ''            ElseIf ddlMill.SelectedValue = 5 Then
    ''                msgMail.From = "jerapa@trrsugar.com"
    ''                strMill = "THAI SUGAR INDUSTRY CO., LTD."
    ''            ElseIf ddlMill.SelectedValue = 6 Then
    ''                msgMail.From = "mayura@trrsugar.com"
    ''                strMill = "BAANRAI SUGAR INDUSTRY CO., LTD."
    ''            End If
    ''            Dim strSub As String = "List of COA reports from" & " " & strMill
    ''            msgMail.Subject = strSub

    ''            msgMail.BodyFormat = MailFormat.Html
    ''            Dim strBody As String
    ''            strBody = "<html><meta http-equiv=Content-Type content='text/html; charset=windows-874'><body>" + _
    ''              " <table border=0><tr><td>" + strSub + "</td></tr>" + _
    ''              " <tr><td><br />Customer Name : " + ddlCustPrint.SelectedItem.Text + _
    ''                "<br />Truck License : " + ddlCarPrint.SelectedValue + _
    ''              "<br />Date of receive : " + ddlRecDate.SelectedValue + _
    ''               "<br />Lot No. on Truck : " + txtLot.Text + _
    ''             "</td></tr></body></html>"
    ''            msgMail.Body = strBody
    ''            SmtpMail.Send(msgMail)

    ''            'lblStatus.Visible = True
    ''            'lblStatus.Text = "Your contact info has been sent successfully. Thank you."
    ''        Catch ex As Exception
    ''            'lblStatus.Visible = True
    ''            'lblStatus.Text = "Message can not be sent."
    ''        End Try
    ''    End Sub
    ''    Private Sub SumLot()
    ''        Try
    ''            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
    ''            Dim sqlSum As String
    ''            Dim dsSum As New DataSet
    ''            Dim ddExp As String
    ''            Dim MMExp As String
    ''            Dim yyExp As String
    ''            Dim strExp As String

    ''            ddExp = ddlRecDate.SelectedValue.ToString.Substring(0, 2)
    ''            MMExp = ddlRecDate.SelectedValue.ToString.Substring(3, 2)
    ''            yyExp = ddlRecDate.SelectedValue.ToString.Substring(6, 4)
    ''            If yyExp > 2500 Then
    ''                yyExp = yyExp - 543
    ''            End If
    ''            strExp = yyExp + "-" + MMExp + "-" + ddExp + " 00:00:00"

    ''            sqlSum = "Select Lot_no from Transport_Lot Where Customer_ID=" & ddlCustPrint.SelectedValue & " "
    ''            sqlSum &= "and Fac_ID=" & ddlMill.SelectedValue & " And Recieve_Sugar='" & strExp & "' "
    ''            sqlSum &= "and Car_License='" & ddlCarPrint.SelectedValue & "'"
    ''            dsSum = clsScriptData.ExecuteData(sqlConn, sqlSum, "dtSum")
    ''            Dim strLot As String
    ''            For i As Integer = 0 To dsSum.Tables("dtSum").Rows.Count - 1
    ''                strLot += dsSum.Tables("dtSum").Rows(i)("Lot_no") & "   "
    ''            Next
    ''            txtLot.Text = strLot
    ''            dsSum = Nothing
    ''            sqlConn.Close()
    ''        Catch ex As Exception
    ''            sqlConn.Close()
    ''            sqlConn.Dispose()
    ''        End Try
    ''    End Sub
    ''#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadMill()
            LoadLot()
            LoadType()
        End If
    End Sub

    Protected Sub ddlLot_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlLot.SelectedIndexChanged
        LoadType()
    End Sub

    Protected Sub ddlMill_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMill.SelectedIndexChanged
        LoadLot()
        LoadCustomer()
    End Sub

    Protected Sub imgbtnShow_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnShow.Click
        pnRpt.Visible = True
        QueryDetail()
        ShowRpt()
        GetImage()
        GetRefNo()
        Session("Mill") = ddlMill.SelectedValue
        Session("Lot") = ddlLot.SelectedValue
        Session("Sugar") = ddlSugar.SelectedValue
        Session("Cust") = ddlCustomer.SelectedValue
        Session("Name") = ddlSugar.SelectedValue
        Session("strName") = ddlSugar.SelectedItem.ToString
        If chkTransport.Checked = True Then
            Session("intTrans") = ViewState("intTrans") 'LoadIntTrans()
        Else
            Session("intTrans") = ddlTruck.SelectedValue
        End If
        Session("Truck") = txtCarLic.Text
        Session("Recieve") = lblRecieve.Text
        Session("Province") = lblProvince.Text
        Session("RemarkH") = lblRemarkH.Text
        Session("Copy") = txtcopy.Text.Trim
        Session("Reverse") = txtReverse.Text.Trim
    End Sub

    Protected Sub imgbtnPreview_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnPreview.Click
        pnRpt.Visible = False
        Response.Write("<script>window.open('frmPreview.aspx','mywindow','width=auto,height=auto,toolbars=yes,scrollbars=yes,status=no,resizable=yes')</script>")
    End Sub

    Protected Sub chkTransport_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkTransport.CheckedChanged
        If ddlCustomer.SelectedValue = "" Then Exit Sub
        If chkTransport.Checked = True Then
            pnTransport.Visible = True
        Else
            'txtCarLic.Text = ""
            'txtProvince.Text = ""
            'txtRemark.Text = ""
            'txtRecieve.Text = ""
            pnTransport.Visible = False
        End If
    End Sub

    Protected Sub imgbtnOK_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnOK.Click
        AddLot()
    End Sub

    Protected Sub ddlCustomer_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustomer.SelectedIndexChanged
        LoadTruck(CInt(ddlMill.SelectedValue), ddlLot.SelectedValue, CInt(ddlSugar.SelectedValue), CInt(ddlCustomer.SelectedValue))
    End Sub

    Protected Sub imgbtnEdit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnEdit.Click
        UpdateCopy()
    End Sub

    Protected Sub btnSumPrint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSumPrint.Click
        pnRpt.Visible = False
        Session("RemarkH") = ddlCustGen.SelectedValue
        Session("Cust") = CInt(ddlCustPrint.SelectedValue)
        Session("strTruck") = ddlCarPrint.SelectedValue
        Session("Recieve") = ddlRecDate.SelectedValue
        Session("Mill") = CInt(ddlMill.SelectedValue)
        Response.Write("<script>window.open('frmPrintSum.aspx','mywindow','width=auto,height=auto,toolbars=yes,scrollbars=yes,status=no,resizable=yes')</script>")
    End Sub

    Protected Sub chkSumLot_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSumLot.CheckedChanged
        If chkSumLot.Checked = True Then
            pnSum.Visible = True
            LoadCustSum()
        Else
            pnSum.Visible = False
        End If
    End Sub

    Protected Sub ddlCustPrint_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustPrint.SelectedIndexChanged
        ddlCustGen.Items.Clear()
        ddlRecDate.Items.Clear()
        ddlCarPrint.Items.Clear()
        If ddlCustPrint.SelectedValue = 321 Then
            LoadRemarkSum(CInt(ddlMill.SelectedValue), CInt(ddlCustPrint.SelectedValue))
        Else
            LoadRecDate(CInt(ddlMill.SelectedValue), CInt(ddlCustPrint.SelectedValue))
        End If
    End Sub

    Protected Sub ddlCustGen_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCustGen.SelectedIndexChanged
        LoadRecDate(CInt(ddlMill.SelectedValue), CInt(ddlCustPrint.SelectedValue))
    End Sub

    Protected Sub ddlRecDate_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRecDate.SelectedIndexChanged
        LoadTruckSum(CInt(ddlMill.SelectedValue), CInt(ddlCustPrint.SelectedValue), CStr(ddlCustGen.SelectedValue), ddlRecDate.SelectedValue)
    End Sub
End Class
