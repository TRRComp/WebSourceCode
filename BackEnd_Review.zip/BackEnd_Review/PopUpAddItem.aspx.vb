﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class PopUpAddItem
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim strFac As String
    Dim Mode As String
#Region "Sub and Function"
    Private Sub QueryData(ByVal Mill As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlQuery As String
            Dim dsQuery As New DataSet
            sqlQuery = "Select * from TestItem Where Mill=" & Mill & " "
            dsQuery = clsScriptData.ExecuteData(sqlConn, sqlQuery, "dtQuery")
            If dsQuery.Tables("dtQuery").Rows.Count <> 0 Then
                gvFillData.DataSource = dsQuery.Tables("dtQuery")
                gvFillData.DataBind()
            End If
            dsQuery = Nothing
            sqlConn.Close()
        Catch ex As Exception
            Response.Write("<script>alert('Data not found.')</script>")
        End Try
    End Sub
    Function MillName(ByVal Mill As Integer) As String
        Dim Name As String = ""
        Select Case Mill
            Case 1
                Name = "SS"
            Case 2
                Name = "PS"
            Case 3
                Name = "TRR"
            Case 4
                Name = "TMI"
            Case 5
                Name = "TSI"
            Case 6
                Name = "BSI"
            Case Else
                Name = Nothing
        End Select
        Return Name
    End Function
    Private Sub LoadFac(ByVal Mill As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlFac As String
            Dim dsFac As New DataSet
            Dim strName As String
            strName = MillName(Mill)
            sqlFac = "Select * from Mill Where Mill_Name='" & strName & "' "
            dsFac = clsScriptData.ExecuteData(sqlConn, sqlFac, "dtFac")
            If dsFac.Tables("dtFac").Rows.Count <> 0 Then
                ddlFactory.DataSource = dsFac.Tables("dtFac")
                ddlFactory.DataTextField = "Mill_Name_Eng"
                ddlFactory.DataValueField = "Mill_Name"
                ddlFactory.DataBind()
            End If
            dsFac = Nothing
            sqlConn.Close()
        Catch ex As Exception
            Response.Write("<script>alert('Data not found.')</script>")
        End Try
    End Sub
    Private Sub SaveData(ByVal Mode As String)
        Try
            If txtItem.Text = "" Then
                Response.Write("'<script>alert('Empty Item Name.')</script>'")
                Exit Sub
            End If
            Dim strClientIP As String
            Dim intFac As Integer
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))
            intFac = CInt(strIP)

            Dim intSort As Integer
            intSort = clsScriptData.ExecuteSchalar(sqlConn, "Select Max(SortItem)+1 From TestItem Where Mill=" & intFac & "")

            If Mode = "Save" Then
                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdSave As New SqlCommand("spAdd_TestItem", sqlConn)
                With cmdSave
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@TestItem", Trim(Me.txtItem.Text))
                    .Parameters.AddWithValue("@Mill", intFac)
                    .Parameters.AddWithValue("@Sort", intSort)
                    .ExecuteNonQuery()
                End With
                cmdSave = Nothing
                sqlConn.Close()
            ElseIf Mode = "Update" Then
                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdUpdate As New SqlCommand("spUpdate_TestItem", sqlConn)
                With cmdUpdate
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@TestItem_ID", ViewState("TestItem_ID"))
                    .Parameters.AddWithValue("@TestItem", Trim(Me.txtItem.Text))
                    .Parameters.AddWithValue("@Mill", intFac)
                    .ExecuteNonQuery()
                End With
                ViewState.Remove("TestItem_ID")
                cmdUpdate = Nothing
                sqlConn.Close()
            End If
            Me.txtItem.Text = ""
            QueryData(intFac)
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub DeleteData(ByVal ItemID As Integer)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim cmdDel As New SqlCommand("spDelete_TestItem", sqlConn)
        With cmdDel
            .CommandType = CommandType.StoredProcedure
            .Parameters.AddWithValue("@TestItem_ID", ItemID)
            .ExecuteNonQuery()
        End With
        Me.txtItem.Text = ""
        QueryData(ViewState("Fac"))
        cmdDel.Dispose()
        sqlConn.Close()
    End Sub
    Private Sub ClearData()
        Me.txtItem.Text = ""
        ViewState.Remove("Fac")
        ViewState.Remove("TestItem_ID")
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim strClientIP As String
            Dim intFac As Integer
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))
            intFac = CInt(strIP)
            ViewState("Fac") = intFac

            QueryData(ViewState("Fac"))
            LoadFac(ViewState("Fac"))
        End If
    End Sub
    Protected Sub imgbtnAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAdd.Click
        SaveData("Save")
        'QueryData(ViewState("Fac"))
    End Sub

    Protected Sub imgbtnClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClear.Click
        ClearData()
    End Sub

    Protected Sub imgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSave.Click
        SaveData("Update")
        'QueryData(ViewState("Fac"))
    End Sub

    Protected Sub imgbtnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelete.Click
        Dim Count As Integer
        For Count = 0 To Me.gvFillData.Rows.Count - 1
            If CType(Me.gvFillData.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                DeleteData(CType(Me.gvFillData.Rows(Count).FindControl("lnkID"), LinkButton).Text)
            End If
        Next
    End Sub

    Protected Sub gvFillData_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvFillData.RowCommand
        If e.CommandName = "Select" Then
            Dim gvCurrent As GridViewRow = e.CommandSource.Parent.Parent
            ViewState("TestItem_ID") = CType(gvCurrent.Cells(0).FindControl("lnkID"), LinkButton).Text
            Me.txtItem.Text = gvCurrent.Cells(1).Text.Replace("&amp;", "&")
        End If
        Mode = "Update"
    End Sub
End Class
