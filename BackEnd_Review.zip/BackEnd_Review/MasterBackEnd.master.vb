﻿
Partial Class MasterBackEnd
    Inherits System.Web.UI.MasterPage
End Class

