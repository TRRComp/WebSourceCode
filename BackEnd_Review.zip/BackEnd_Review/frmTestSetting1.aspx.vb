﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class frmTestSetting
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim dsLoadItem As New DataSet
    Dim strFac As String
#Region "Sub QueryTest"
    Private Sub LoadCust()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlCust As String
        Dim dsCust As New DataSet
        sqlCust = "SELECT CUSTOMER_ID,CUSTOMER_NAME FROM CUSTOMER ORDER BY CUSTOMER_ID"
        dsCust = clsScriptData.ExecuteData(sqlConn, sqlCust, "tbCust")
        If dsCust.Tables("tbCust").Rows.Count > 0 Then
            ddlCust.DataTextField = "CUSTOMER_NAME"
            ddlCust.DataValueField = "CUSTOMER_ID"
            ddlCust.DataSource = dsCust.Tables("tbCust")
            ddlCust.DataBind()
        End If
        dsCust = Nothing
        sqlConn.Close()
    End Sub
    Private Sub LoadItem()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim strClientIP As String
        Dim intFac As Integer
        strClientIP = Request.UserHostAddress()
        Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
        strFac = clsScriptData.GetIPFac(CInt(strIP))
        intFac = CInt(strIP)

        Dim sqlLoadItem As String
        sqlLoadItem = "Select distinct TestItem ,'' As Benchmark_White,'' As Benchmark_Refine, "
        sqlLoadItem &= "'' As TestMethod_White,'' As TestMethod_Refine "
        sqlLoadItem &= "from TestItem "
        sqlLoadItem &= "Where Mill=" & intFac & ""
        dsLoadItem = clsScriptData.ExecuteData(sqlConn, sqlLoadItem, "tbItem")
        gvFillData.Visible = False
        gvQuery.Visible = True
        gvQuery.DataSource = dsLoadItem.Tables("tbItem")
        gvQuery.DataBind()
        pnEditData.Visible = False
        dsLoadItem = Nothing
        sqlConn.Close()
    End Sub
    Function CheckCust() As Boolean
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlCheck As String
        Dim strCust As Integer
        sqlCheck = "Select count(Customer_ID) from SetSpec Where Customer_ID=" & CInt(ddlCust.SelectedValue) & ""
        strCust = clsScriptData.ExecuteSchalar(sqlConn, sqlCheck)
        If strCust > 0 Then
            Return True
        Else
            Return False
        End If
        sqlConn.Close()
    End Function
    Private Sub QueryItem()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim strClientIP As String
        Dim intFac As Integer
        strClientIP = Request.UserHostAddress()
        Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
        'strFac = clsScriptData.GetIPFac(CInt(strIP))
        intFac = CInt(strIP)

        Dim sqlLoadItem As String
        Dim dsLoadItem As New DataSet
        sqlLoadItem = "Select SetSpec.ID,TestItem.TestItem,SetSpec.Benchmark_White,SetSpec.Benchmark_Refine, "
        sqlLoadItem &= "SetSpec.TestMethod_White, SetSpec.TestMethod_Refine, SetSpec.White, SetSpec.Refine "
        sqlLoadItem &= "from SetSpec left join TestItem on "
        sqlLoadItem &= "SetSpec.TestItem_ID=TestItem.TestItem_ID and SetSpec.mill = TestItem.mill "
        If CheckCust() = True Then
            sqlLoadItem &= "Where SetSpec.Customer_ID=" & CInt(ddlCust.SelectedValue) & " "
        Else
            sqlLoadItem &= "Where SetSpec.Customer_ID='0' "
        End If
        sqlLoadItem &= "And SetSpec.mill=" & intFac & ""
        dsLoadItem = clsScriptData.ExecuteData(sqlConn, sqlLoadItem, "tbFillItem")
        If dsLoadItem.Tables("tbFillItem").Rows.Count > 0 Then
            gvQuery.Visible = False
            gvFillData.Visible = True
            gvFillData.DataSource = dsLoadItem.Tables("tbFillItem")
            gvFillData.DataBind()
            For i As Integer = 0 To dsLoadItem.Tables("tbFillItem").Rows.Count - 1
                If dsLoadItem.Tables("tbFillItem").Rows(i)("White") = True And dsLoadItem.Tables("tbFillItem").Rows(i)("Refine") = True Then
                    CType(Me.gvFillData.Rows(i).FindControl("chkWhite"), CheckBox).Checked = True
                    CType(Me.gvFillData.Rows(i).FindControl("chkRefine"), CheckBox).Checked = True
                ElseIf dsLoadItem.Tables("tbFillItem").Rows(i)("Refine") = True Then
                    CType(Me.gvFillData.Rows(i).FindControl("chkRefine"), CheckBox).Checked = True
                    CType(Me.gvFillData.Rows(i).FindControl("chkWhite"), CheckBox).Checked = False
                ElseIf dsLoadItem.Tables("tbFillItem").Rows(i)("White") = True Then
                    CType(Me.gvFillData.Rows(i).FindControl("chkRefine"), CheckBox).Checked = False
                    CType(Me.gvFillData.Rows(i).FindControl("chkWhite"), CheckBox).Checked = True
                Else
                    CType(Me.gvFillData.Rows(i).FindControl("chkRefine"), CheckBox).Checked = False
                    CType(Me.gvFillData.Rows(i).FindControl("chkWhite"), CheckBox).Checked = False
                End If
            Next
        End If
    End Sub
    Private Sub QueryID(ByVal Mill As String, ByVal Cust_ID As String)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlID As String
        Dim dsID As New DataSet
        sqlID = "Select SetSpec.ID,TestItem.TestItem_ID from SetSpec inner join TestItem on "
        sqlID &= "SetSpec.TestItem_ID=TestItem.TestItem_ID and "
        sqlID &= "SetSpec.mill=TestItem.mill left join Customer on "
        sqlID &= "SetSpec.Customer_ID = Customer.Customer_ID "
        sqlID &= "Where setSpec.Customer_ID='" & Cust_ID & "' and SetSpec.mill='" & Mill & "'"
        dsID = clsScriptData.ExecuteData(sqlConn, sqlID, "dtID")
        If dsID.Tables("dtID").Rows.Count <> 0 Then
            ViewState("ID") = dsID.Tables("dtID").Rows(0)("ID")
        End If
        ViewState("Item_ID") = dsID.Tables("dtID").Rows(0)("TestItem_ID")
        dsID = Nothing
        sqlConn.Close()
    End Sub
    Private Sub QueryItemID(ByVal Item As String, ByVal Mill As Integer)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlItemID As String
        Dim dsItemID As New DataSet
        sqlItemID = "Select TestItem.TestItem_ID from TestItem "
        sqlItemID &= "Where TestItem.TestItem='" & Item & "' and TestItem.mill=" & Mill & ""
        dsItemID = clsScriptData.ExecuteData(sqlConn, sqlItemID, "dtItemID")
        ViewState("Item") = dsItemID.Tables("dtItemID").Rows(0)("TestItem_ID")
        dsItemID = Nothing
        sqlConn.Close()
    End Sub
    Private Sub SetSpec(ByVal ID As Integer, ByVal TestItem_ID As String, ByVal BenchW As String, ByVal TestW As String, ByVal BenchR As String, ByVal TestR As String, ByVal StrActW As Boolean, ByVal StrActR As Boolean, ByVal CustID As Integer)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim strClientIP As String
        Dim intFac As Integer
        strClientIP = Request.UserHostAddress()
        Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
        strFac = clsScriptData.GetIPFac(CInt(strIP))
        intFac = CInt(strIP)

        If chkW.Checked Then
            StrActW = True
        Else
            StrActW = False
        End If
        If chkR.Checked Then
            StrActR = True
        Else
            StrActR = False
        End If
        Dim cmdSave As New SqlCommand("spUpdate_Setting", sqlConn)
        With cmdSave
            .CommandType = CommandType.StoredProcedure
            .Parameters.AddWithValue("@Id", ID)
            .Parameters.AddWithValue("@TestItem_ID", TestItem_ID)
            .Parameters.AddWithValue("@Benchmark_White", BenchW)
            .Parameters.AddWithValue("@TestMethod_White", TestW)
            .Parameters.AddWithValue("@White", StrActW)
            .Parameters.AddWithValue("@Benchmark_Refine", BenchR)
            .Parameters.AddWithValue("@TestMethod_Refine", TestR)
            .Parameters.AddWithValue("@Refine", StrActR)
            .Parameters.AddWithValue("@Customer_ID", CustID)
            .Parameters.AddWithValue("@Mill", intFac)
            .ExecuteNonQuery()
        End With
        cmdSave.Dispose()
        QueryItem()
        ClearControl()
    End Sub
    Private Sub DelData(ByVal Id As String)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim cmdDel As New SqlCommand("spDelete_Setting", sqlConn)
        With cmdDel
            .CommandType = CommandType.StoredProcedure
            .Parameters.AddWithValue("@ID", Id)
            .ExecuteNonQuery()
        End With
        cmdDel.Dispose()
        sqlConn.Close()
    End Sub
    Private Sub ClearControl()
        Me.txtBmW.Text = ""
        Me.txtBmR.Text = ""
        Me.txtTestW.Text = ""
        txtTestW.Text = ""
        chkW.Checked = False
        chkR.Checked = False
        pnEditData.Visible = False
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadCust()
            LoadItem()
        End If
    End Sub

    Protected Sub imgbtnAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAdd.Click
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim strClientIP As String
        Dim intFac As Integer
        strClientIP = Request.UserHostAddress()
        Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
        strFac = clsScriptData.GetIPFac(CInt(strIP))
        intFac = CInt(strIP)

        Dim dt As DataTable = New DataTable()
        Dim gvr As GridViewRow
        Dim dr As DataRow

        dt.Columns.Add(New DataColumn("TestItem"))
        dt.Columns.Add(New DataColumn("Benchmark_White"))
        dt.Columns.Add(New DataColumn("TestMethod_White"))
        dt.Columns.Add(New DataColumn("Benchmark_Refine"))
        dt.Columns.Add(New DataColumn("TestMethod_Refine"))
        dt.Columns.Add(New DataColumn("White"))
        dt.Columns.Add(New DataColumn("Refine"))
        dt.Columns.Add(New DataColumn("Customer_ID"))
        dt.Columns.Add(New DataColumn("Mill"))

        For Each gvr In gvQuery.Rows
            dr = dt.NewRow()
            QueryItemID(gvr.Cells(0).Text.Trim, CInt(intFac))
            dr("TestItem") = ViewState("Item")
            dr("Benchmark_White") = IIf(True, (CType(gvr.Cells(1).FindControl("txtBmW"), TextBox)).Text, "-")
            dr("TestMethod_White") = IIf(True, (CType(gvr.Cells(2).FindControl("txtTestW"), TextBox)).Text, "-")
            dr("Benchmark_Refine") = IIf(True, (CType(gvr.Cells(3).FindControl("txtBmR"), TextBox)).Text, "-")
            dr("TestMethod_Refine") = IIf(True, (CType(gvr.Cells(4).FindControl("txtTestR"), TextBox)).Text, "-")
            dr("White") = IIf(True, (CType(gvr.Cells(5).FindControl("chkW"), CheckBox)).Checked, "")
            dr("Refine") = IIf(True, (CType(gvr.Cells(6).FindControl("chkR"), CheckBox)).Checked, "")
            dr("Customer_ID") = IIf(True, Me.ddlCust.SelectedValue, "-")
            dr("Mill") = intFac
            dt.Rows.Add(dr)
        Next
        gvQuery.DataSource = dt
        gvQuery.DataBind()

        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        For Each dr In dt.Rows
            Dim cmdSave As New SqlCommand("spAdd_Setting", sqlConn)
            cmdSave.CommandType = CommandType.StoredProcedure
            With cmdSave
                .Parameters.AddWithValue("@TestItem_ID", dr("TestItem"))
                .Parameters.AddWithValue("@Benchmark_White", dr("Benchmark_White"))
                .Parameters.AddWithValue("@TestMethod_White", dr("TestMethod_White"))
                .Parameters.AddWithValue("@White", dr("White"))
                .Parameters.AddWithValue("@Benchmark_Refine", dr("Benchmark_Refine"))
                .Parameters.AddWithValue("@TestMethod_Refine", dr("TestMethod_Refine"))
                .Parameters.AddWithValue("@Refine", dr("Refine"))
                .Parameters.AddWithValue("@Customer_ID", CInt(dr("Customer_ID")))
                .Parameters.AddWithValue("@Mill", CInt(dr("Mill")))
                .ExecuteNonQuery()
            End With
            cmdSave.Dispose()
        Next
        sqlConn.Close()
    End Sub

    Protected Sub imgbtnClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClear.Click
        LoadItem()
    End Sub

    Protected Sub imgbtnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelete.Click
        If CheckCust() = False Then
            lblErr.Visible = True
            lblErr.Text = "Can not delete data."
            Exit Sub
        End If

        Dim Count As Integer
        For Count = 0 To Me.gvFillData.Rows.Count - 1
            If CType(Me.gvFillData.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                DelData(CType(Me.gvFillData.Rows(Count).FindControl("lnkID"), LinkButton).Text)
            End If
        Next
        QueryItem()
    End Sub

    Protected Sub imgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSave.Click
        'If CheckCust() = False Then
        '    lblErr.Visible = True
        '    lblErr.Text = "Please click button New for add record."
        '    Exit Sub
        'End If

        'Dim Count As Integer
        'For Count = 0 To Me.gvFillData.Rows.Count - 1
        '    If CType(Me.gvFillData.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
        If chkW.Checked = True Then
            ViewState("chkW") = True
        Else
            ViewState("chkW") = False
        End If
        If chkR.Checked = True Then
            ViewState("chkR") = True
        Else
            ViewState("chkR") = False
        End If
        SetSpec(ViewState("ID"), ViewState("Item"), Me.txtBmW.Text, Me.txtTestW.Text, Me.txtBmR.Text, Me.txtTestR.Text, ViewState("chkW"), ViewState("chkR"), ViewState("CustID"))
        '    Else
        '    End If
        'Next
        QueryItem()
        ViewState.Remove("ID")
        ViewState.Remove("Item")
        ViewState.Remove("chkW")
        ViewState.Remove("chkR")
        ViewState.Remove("CustID")
        ViewState.Remove("Mill")
        ClearControl()
    End Sub

    Protected Sub imgbtnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnFilter.Click
        lblErr.Visible = False
        QueryItem()
        ClearControl()
    End Sub

    Protected Sub gvFillData_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvFillData.RowCommand
        If e.CommandName = "Select" Then
            Dim gvFillData As GridViewRow = e.CommandSource.Parent.Parent
            pnEditData.Visible = True
            Dim strClientIP As String
            Dim intFac As Integer
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))
            intFac = CInt(strIP)
            ViewState("Mill") = intFac
            ViewState("ID") = CType(gvFillData.Cells(0).FindControl("lnkID"), LinkButton).Text
            ViewState("Item") = clsScriptData.DbnullToString(gvFillData.Cells(1).Text)
            txtBmW.Text = clsScriptData.DbnullToString(gvFillData.Cells(2).Text).Replace("&nbsp;", "")
            txtBmR.Text = clsScriptData.DbnullToString(gvFillData.Cells(3).Text).Replace("&nbsp;", "")
            txtTestW.Text = clsScriptData.DbnullToString(gvFillData.Cells(4).Text).Replace("&nbsp;", "")
            txtTestR.Text = clsScriptData.DbnullToString(gvFillData.Cells(5).Text).Replace("&nbsp;", "")
            ViewState("CustID") = ddlCust.SelectedValue
            If CType(gvFillData.Cells(6).FindControl("chkWhite"), CheckBox).Checked Then
                chkW.Checked = True
                ViewState("chkW") = True
            Else
                chkW.Checked = False
                ViewState("chkW") = False
            End If
            If CType(gvFillData.Cells(7).FindControl("chkRefine"), CheckBox).Checked Then
                chkR.Checked = True
                ViewState("chkR") = True
            Else
                chkR.Checked = False
                ViewState("chkR") = False
            End If
            QueryItemID(gvFillData.Cells(1).Text.Trim, CInt(intFac))
            CType(gvFillData.Cells(8).FindControl("chkConfirm"), CheckBox).Checked = True
        End If
    End Sub

    Protected Sub imgbtnNew_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnNew.Click
        If CheckCust() = True Then
            Response.Write("<script>alert('This customer set spect already.')</script>")
            Exit Sub
        End If
        lblErr.Visible = False
        gvQuery.Visible = True
        gvFillData.Visible = False
    End Sub

    Protected Sub lnkBtnLink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkBtnLink.Click
        Response.Write("<script>window.open('PopUpAddItem.aspx','mywindow','width=600,height=600,toolbars=no,scrollbars=yes,status=no,resizable=yes')</script>")
    End Sub
End Class
