﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class frmLab
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim strFac As String
    Dim Mode As String
    Dim strType As String
    Dim strDateProduce As Date
    Dim strDateAnalyst As Date
    Dim strDateExp As Date
#Region "Sub And Function"
    Private Sub LoadMill()
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim strClientIP As String
        strClientIP = Request.UserHostAddress()
        Dim strIP As String = mid(strClientIP.ToString, 9, 1)
        strFac = clsScriptData.GetIPFac(CInt(strIP))
        Dim sqlMill As String
        Dim dsMill As New DataSet
        sqlMill = "SELECT Mill,Mill_Name,Mill_Name_Eng FROM Mill "
        If strFac <> "Head Office" Then
            sqlMill &= "WHERE Mill_Name='" & strFac & "' "
        End If
        dsMill = clsScriptData.ExecuteData(sqlConn, sqlMill, "dtMill")
        If dsMill.Tables("dtMill").Rows.Count > 0 Then
            ddlMill.DataValueField = "Mill"
            ddlMill.DataTextField = "Mill_Name_Eng"
            ddlMill.DataSource = dsMill.Tables("dtMill")
            ddlMill.DataBind()
            lblErr.Visible = False
        Else
            lblErr.Visible = True
            lblErr.Text = "Data not found"
        End If
        LoadItem()
        dsMill = Nothing
        sqlConn.Close()
    End Sub
    Private Sub LoadItem()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlItemLab As String
        Dim dsItemLab As New DataSet
        sqlItemLab = "Select '' as Value,TestItem.TestItem,TestItem.TestItem_ID from TestItem "
        sqlItemLab &= "Where TestItem.Mill=" & CInt(ddlMill.SelectedValue) & " "
        dsItemLab = clsScriptData.ExecuteData(sqlConn, sqlItemLab, "dtItem")
        gvKeyIn.Visible = True
        gvKeyIn.DataSource = dsItemLab.Tables("dtItem")
        gvKeyIn.DataBind()
        gvLab.Visible = False
        dsItemLab = Nothing
        sqlConn.Close()
    End Sub
    Private Sub LoadHead()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim LabID As Integer
        LabID = retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim)
        Dim sqlQueryLab As String
        Dim dsQueryLab As New DataSet
        sqlQueryLab = "SELECT lab.mill,LAB.Lab_ID,MILL.MILL_NAME_ENG,LAB.SUGAR_TYPE,LAB.LOT_NO,Lab.Production_Date, "
        sqlQueryLab &= "Lab.Referance_no, Lab.Sample_Size, Lab.Analyst_Date,Lab.Remarks,Exp_Date "
        sqlQueryLab &= "FROM LAB LEFT JOIN MILL ON MILL.MILL=LAB.MILL "
        sqlQueryLab &= "WHERE LAB.MILL = '" & CInt(ddlMill.SelectedValue) & "' "
        sqlQueryLab &= "And LAB.LOT_NO = '" & Me.txtLot.Text.Trim & "' "
        sqlQueryLab &= "And LAB.Lab_ID = " & LabID & " "
        'If rbtnRefine.Checked = True Then
        '    sqlQueryLab &= "and Lab.Sugar_Type='Refine' "
        'ElseIf rbtnWhite.Checked = True Then
        '    sqlQueryLab &= "and Lab.Sugar_Type='White' "
        'End If
        sqlQueryLab &= "ORDER BY LAB.lab_ID"
        dsQueryLab = clsScriptData.ExecuteData(sqlConn, sqlQueryLab, "dtQuery")
        If dsQueryLab.Tables("dtQuery").Rows.Count > 0 Then
            'Dim ddProduce As String
            'Dim MMProduce As String
            'Dim yyProduce As String
            'Dim strProduce As String
            Dim str1 As String
            str1 = Format(dsQueryLab.Tables("dtQuery").Rows(0)("Production_Date"), "dd/MM/yyyy")
            'If str1.Length = 10 Then
            '    ddProduce = str1.Substring(3, 2)
            '    MMProduce = str1.Substring(0, 2)
            '    yyProduce = str1.Substring(6, 4)
            '    strProduce = ddProduce + "/" + MMProduce + "/" + yyProduce
            'ElseIf str1.Length = 9 Then
            '    ddProduce = str1.Substring(2, 2)
            '    MMProduce = str1.Substring(0, 1)
            '    yyProduce = str1.Substring(5, 4)
            '    strProduce = ddProduce + "/" + MMProduce + "/" + yyProduce
            'ElseIf str1.Length = 8 Then
            '    ddProduce = str1.Substring(2, 1)
            '    MMProduce = str1.Substring(0, 1)
            '    yyProduce = str1.Substring(4, 4)
            '    strProduce = ddProduce + "/" + MMProduce + "/" + yyProduce
            'End If

            'Dim ddAnalyst As String
            'Dim MMAnalyst As String
            'Dim yyAnalyst As String
            'Dim strAnalyst As String
            Dim str2 As String
            str2 = Format(dsQueryLab.Tables("dtQuery").Rows(0)("Analyst_Date"), "dd/MM/yyyy")

            Dim str3 As String
            If dsQueryLab.Tables("dtQuery").Rows(0)("Exp_Date") IsNot DBNull.Value Then
                str3 = Format(dsQueryLab.Tables("dtQuery").Rows(0)("Exp_Date"), "dd/MM/yyyy")
            Else
                str3 = ""
            End If
            Me.txtDateExp.Text = str3
            Me.txtDate.Text = str1 'strProduce
            Me.txtDateAnalyst.Text = str2 'strAnalyst
            Me.txtExQty.Text = dsQueryLab.Tables("dtQuery").Rows(0)("Sample_Size")
            Me.txtRef.Text = dsQueryLab.Tables("dtQuery").Rows(0)("Referance_no")
            Me.txtRemark.Text = dsQueryLab.Tables("dtQuery").Rows(0)("Remarks")
            ViewState.Remove("Type")
            If dsQueryLab.Tables("dtQuery").Rows(0)("SUGAR_TYPE") = "Refine" Then
                rbtnRefine.Checked = True
                rbtnWhite.Checked = False
                ViewState("Type") = "Refine"
            ElseIf dsQueryLab.Tables("dtQuery").Rows(0)("SUGAR_TYPE") = "White" Then
                rbtnWhite.Checked = True
                rbtnRefine.Checked = False
                ViewState("Type") = "White"
            End If
            lblErr.Visible = False
        Else
            lblErr.Visible = True
            lblErr.Text = "Data Not Found"
        End If
        dsQueryLab = Nothing
        sqlConn.Close()
    End Sub
    Private Sub QueryLab(ByVal LabID As Integer)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlQueryLab As String
        Dim dsQueryLab As New DataSet
        sqlQueryLab = "Select Lab_Data.Value,TestItem.TestItem,Lab_Data.TestItem_ID from Lab_Data inner join Lab "
        sqlQueryLab &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
        sqlQueryLab &= "left join TestItem on "
        sqlQueryLab &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID and Lab_Data.Mill=TestItem.Mill "
        sqlQueryLab &= "where Lab_Data.Mill=" & CInt(ddlMill.SelectedValue) & " "
        sqlQueryLab &= "and Lab.Lot_No='" & Me.txtLot.Text.Trim & "' and Lab.Lab_id=" & LabID & " "
        sqlQueryLab &= "and Lab.Sugar_Type='" & ViewState("Type") & "' "
        dsQueryLab = clsScriptData.ExecuteData(sqlConn, sqlQueryLab, "dtQuery")
        If dsQueryLab.Tables("dtQuery").Rows.Count > 0 Then
            ViewState.Remove("Lab_ID")
            gvLab.Visible = True
            gvLab.DataSource = dsQueryLab.Tables("dtQuery")
            gvLab.DataBind()
            ViewState("Lab_ID") = LabID
            gvKeyIn.Visible = False
            lblErr.Visible = False
        Else
            lblErr.Visible = True
            lblErr.Text = "Data Not Found"
        End If
        dsQueryLab = Nothing
        sqlConn.Close()
    End Sub
    Private Sub QueryLabEdit(ByVal LabID As Integer)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlQueryLab As String
        Dim dsQueryLab As New DataSet
        sqlQueryLab = "Select Lab_Data.Value,TestItem.TestItem,Lab_Data.TestItem_ID from Lab_Data inner join Lab "
        sqlQueryLab &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
        sqlQueryLab &= "left join TestItem on "
        sqlQueryLab &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID and Lab_Data.Mill=TestItem.Mill "
        sqlQueryLab &= "where Lab_Data.Mill=" & CInt(ddlMill.SelectedValue) & " "
        sqlQueryLab &= "and Lab.Lot_No='" & Me.txtLot.Text.Trim & "' and Lab.Lab_id=" & LabID & ""
        dsQueryLab = clsScriptData.ExecuteData(sqlConn, sqlQueryLab, "dtQuery")
        If dsQueryLab.Tables("dtQuery").Rows.Count > 0 Then
            ViewState.Remove("Lab_ID")
            gvLab.Visible = True
            gvLab.DataSource = dsQueryLab.Tables("dtQuery")
            gvLab.DataBind()
            gvKeyIn.Visible = False
            lblErr.Visible = False
        Else
            lblErr.Visible = True
            lblErr.Text = "Data Not Found"
        End If
        dsQueryLab = Nothing
        sqlConn.Close()
    End Sub
    Private Sub EditResult()
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim cmdUpdate As New SqlCommand("spUpdate_Lab_Data", sqlConn)
        With cmdUpdate
            .CommandType = CommandType.StoredProcedure
            .Parameters.AddWithValue("@ID", ViewState("ID"))
            .Parameters.AddWithValue("@Mill", CInt(Me.ddlMill.SelectedValue))
            .Parameters.AddWithValue("@TestItem_ID", ViewState("Item_ID"))
            .Parameters.AddWithValue("@Lab_ID", ViewState("Lab_ID"))
            .Parameters.AddWithValue("@Value", Me.txtResult.Text.Trim)
            .ExecuteNonQuery()
        End With
        cmdUpdate = Nothing
        sqlConn.Close()
        QueryLab(retID(CInt(Me.ddlMill.SelectedValue), Me.txtLot.Text))
        ViewState.Remove("ID")
        ViewState.Remove("Item_ID")
        ViewState.Remove("Lab_ID")
        'Response.Write("<script>alert('Update Already.')</script>")
        lblErr.Visible = True
        lblErr.Text = "Update Data Already."
        'LoadItem()
        'ClearData()
        'QueryLab()
    End Sub
    Private Sub SaveData(ByVal Mode As String)
        If rbtnRefine.Checked Then
            strType = rbtnRefine.Text
        ElseIf rbtnWhite.Checked Then
            strType = rbtnWhite.Text
        End If

     
        Dim ddProduce As String
        Dim MMProduce As String
        Dim yyProduce As String
        Dim strProduce As String
        ddProduce = txtDate.Text.Substring(0, 2)
        MMProduce = txtDate.Text.Substring(3, 2)
        yyProduce = txtDate.Text.Substring(6, 4)
        strProduce = yyProduce + "-" + MMProduce + "-" + ddProduce + " 00:00:00"
        strDateProduce = CDate(strProduce)

        Dim ddAnalyst As String
        Dim MMAnalyst As String
        Dim yyAnalyst As String
        Dim strAnalyst As String
        ddAnalyst = txtDateAnalyst.Text.Substring(0, 2)
        MMAnalyst = txtDateAnalyst.Text.Substring(3, 2)
        yyAnalyst = txtDateAnalyst.Text.Substring(6, 4)
        strAnalyst = yyAnalyst + "-" + MMAnalyst + "-" + ddAnalyst + " 00:00:00"
        strDateAnalyst = CDate(strAnalyst)

        Dim ddExp As String
        Dim MMExp As String
        Dim yyExp As String
        Dim strExp As String
        If txtDateExp.Text IsNot DBNull.Value AndAlso txtDateExp.Text <> "" Then
            ddExp = txtDateExp.Text.Substring(0, 2)
            MMExp = txtDateExp.Text.Substring(3, 2)
            yyExp = txtDateExp.Text.Substring(6, 4)
            strExp = yyExp + "-" + MMExp + "-" + ddExp + " 00:00:00"
            strDateExp = CDate(strExp)
        End If


        Dim sqlQueryMill As String
        Dim strAnalystName As String
        Dim strAnalystLogo As String
        Dim strAuthorizeName As String
        Dim strAuthorizeLogo As String
        Dim dsQuery As New DataSet
        sqlQueryMill = "Select Analyst_Name,Analyst_Logo,Authorize_Name,Authorize_Logo From Mill Where Mill=" & Me.ddlMill.SelectedValue & " "
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        dsQuery = clsScriptData.ExecuteData(sqlConn, sqlQueryMill, "dtQueryMill")
        strAnalystName = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Analyst_Name"))
        strAnalystLogo = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Analyst_Logo"))
        strAuthorizeName = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Authorize_Name"))
        strAuthorizeLogo = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Authorize_Logo"))

        If Mode = "Save" Then
            If CheckLotNo(Me.txtLot.Text.Trim, strType, ddlMill.SelectedValue) = False Then
                lblErr.Visible = True
                lblErr.Text = "Have data already!!!"
                ClearData()
                Exit Sub
            End If

            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdSaveHead As New SqlCommand("spAdd_Lab", sqlConn)
            With cmdSaveHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@Mill", Me.ddlMill.SelectedValue)
                .Parameters.AddWithValue("@Type", strType)
                .Parameters.AddWithValue("@Lot_no", Trim(Me.txtLot.Text))
                .Parameters.AddWithValue("@Production_date", strDateProduce)
                .Parameters.AddWithValue("@Analyst_Date", strDateAnalyst)
                .Parameters.AddWithValue("@Referance_no", Me.txtRef.Text.Trim)
                .Parameters.AddWithValue("@Sample", CDec(Me.txtExQty.Text.Trim))
                .Parameters.AddWithValue("@Username", Me.Request.LogonUserIdentity.Name)
                .Parameters.AddWithValue("@Remarks", Trim(Me.txtRemark.Text))
                .Parameters.AddWithValue("@Analyst_Name", strAnalystName)
                .Parameters.AddWithValue("@Analyst_Logo", strAnalystLogo)
                .Parameters.AddWithValue("@Authorize_Name", strAuthorizeName)
                .Parameters.AddWithValue("@Authorize_Logo", strAuthorizeLogo)
                If txtDateExp.Text IsNot DBNull.Value AndAlso txtDateExp.Text <> "" Then
                    .Parameters.AddWithValue("@Exp_Date", strDateExp)
                Else
                    .Parameters.AddWithValue("@Exp_Date", System.DBNull.Value)
                End If
                .ExecuteNonQuery()
            End With
            cmdSaveHead = Nothing

            Dim strID As Integer
            strID = clsScriptData.ExecuteSchalar(sqlConn, "select max(Lab_ID) as Lab_ID from Lab WHERE Mill=" & ddlMill.SelectedValue & "")

            Dim dt As DataTable = New DataTable()
            Dim gvr As GridViewRow
            Dim dr As DataRow

            dt.Columns.Add(New DataColumn("TestItem_ID"))
            dt.Columns.Add(New DataColumn("TestItem"))
            dt.Columns.Add(New DataColumn("Lab_ID"))
            dt.Columns.Add(New DataColumn("Value"))
            dt.Columns.Add(New DataColumn("Mill"))

            For Each gvr In gvKeyIn.Rows
                dr = dt.NewRow()
                dr("TestItem_ID") = gvr.Cells(0).Text
                dr("TestItem") = gvr.Cells(1).Text
                dr("Lab_ID") = strID
                dr("Value") = IIf(True, (CType(gvr.Cells(2).FindControl("txtValue"), TextBox)).Text, "-")
                dr("Mill") = Me.ddlMill.SelectedValue
                dt.Rows.Add(dr)
            Next
            gvKeyIn.DataSource = dt
            gvKeyIn.DataBind()

            For Each dr In dt.Rows
                Dim cmdSave As New SqlCommand("spAdd_Lab_Data", sqlConn)
                With cmdSave
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@TestItem_ID", dr("TestItem_ID"))
                    .Parameters.AddWithValue("@Lab_ID", CInt(dr("Lab_ID")))
                    .Parameters.AddWithValue("@Value", dr("Value"))
                    .Parameters.AddWithValue("@Mill", CInt(dr("Mill")))
                    .ExecuteNonQuery()
                End With
                cmdSave.Dispose()
            Next
            ClearData()
            QueryLab(retID(CInt(Me.ddlMill.SelectedValue), Me.txtLot.Text.Trim))
            sqlConn.Close()

        ElseIf Mode = "Update" Then
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdUpdateHead As New SqlCommand("spUpdate_Lab", sqlConn)
            With cmdUpdateHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@ID", ViewState("Lab_ID"))
                .Parameters.AddWithValue("@Mill", CInt(Me.ddlMill.SelectedValue))
                .Parameters.AddWithValue("@Type", strType)
                .Parameters.AddWithValue("@Lot_no", Trim(Me.txtLot.Text))
                .Parameters.AddWithValue("@Production_date", strDateProduce)
                .Parameters.AddWithValue("@Analyst_Date", strDateAnalyst)
                .Parameters.AddWithValue("@Referance_no", Me.txtRef.Text.Trim)
                .Parameters.AddWithValue("@Sample", CDec(Me.txtExQty.Text.Trim))
                .Parameters.AddWithValue("@Username", Me.Request.LogonUserIdentity.Name)
                .Parameters.AddWithValue("@Remarks", Trim(Me.txtRemark.Text))
                .Parameters.AddWithValue("@Analyst_Name", strAnalystName)
                .Parameters.AddWithValue("@Analyst_Logo", strAnalystLogo)
                .Parameters.AddWithValue("@Authorize_Name", strAuthorizeName)
                .Parameters.AddWithValue("@Authorize_Logo", strAuthorizeLogo)
                If txtDateExp.Text IsNot DBNull.Value AndAlso txtDateExp.Text <> "" Then
                    .Parameters.AddWithValue("@Exp_Date", strDateExp)
                Else
                    .Parameters.AddWithValue("@Exp_Date", System.DBNull.Value)
                End If
                .ExecuteNonQuery()
            End With
            'ClearData()
            'QueryLab(retID(CInt(Me.ddlMill.SelectedValue), Me.txtLot.Text.Trim))
            cmdUpdateHead = Nothing
            sqlConn.Close()
        End If
    End Sub
    Private Sub QueryID(ByVal Mill As Integer, ByVal Item As String, ByVal Lab_ID As Integer)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlID As String
        Dim dsID As New DataSet
        sqlID = "Select Lab_Data.ID,Lab_Data.TestItem_ID,Lab_Data.Lab_ID from Lab_Data inner join Lab "
        sqlID &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
        sqlID &= "left join TestItem on "
        sqlID &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID And Lab_Data.Mill = TestItem.Mill "
        sqlID &= "where Lab_Data.Mill=" & Mill & " and TestItem.TestItem='" & Item & "' and Lab_Data.Lab_ID=" & Lab_ID & ""
        dsID = clsScriptData.ExecuteData(sqlConn, sqlID, "dtID")
        ViewState("ID") = dsID.Tables("dtID").Rows(0)("ID")
        ViewState("Item_ID") = dsID.Tables("dtID").Rows(0)("TestItem_ID")
        ViewState("Lab_ID") = dsID.Tables("dtID").Rows(0)("Lab_ID")
        dsID = Nothing
        sqlConn.Close()
    End Sub
    Function retID(ByVal Mill As Integer, ByVal LotNO As String) As Integer
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim intID As Integer
            Dim sqlRet As String
            sqlRet = "Select distinct Lab.Lab_ID from Lab_Data inner join Lab "
            sqlRet &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlRet &= "where Lab_Data.Mill=" & Mill & " and Lab.Lot_No='" & LotNO & "' and Lab.Sugar_Type='" & ViewState("Type") & "' "
            intID = clsScriptData.ExecuteSchalar(sqlConn, sqlRet)
            Return intID
        Catch ex As Exception
            Return 0
        End Try
    End Function
    Function CheckLotNo(ByVal LotNo As String, ByVal SugarType As String, ByVal Mill As Integer) As Boolean
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlCheck As String
        Dim intCount As Integer
        sqlCheck = "select COUNT(*) from Lab where lot_no='" & LotNo & "' and sugar_type='" & SugarType & "' and Mill=" & Mill & ""
        intCount = clsScriptData.ExecuteSchalar(sqlConn, sqlCheck)
        sqlConn.Close()
        If intCount = 0 Then
            Return True
        Else
            Return False
        End If
    End Function
    Function retIDDetail(ByVal Mill As Integer, ByVal LotNO As String, ByVal Item As String) As Integer
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim intID As Integer
            Dim sqlRet As String
            sqlRet = "Select Lab_Data.ID from Lab_Data inner join Lab "
            sqlRet &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlRet &= "left join TestItem on "
            sqlRet &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID And Lab_Data.Mill = TestItem.Mill "
            sqlRet &= "where Lab_Data.Mill=" & Mill & " and TestItem.TestItem='" & Item & "' and Lab.Lot_No='" & LotNO & "'"
            intID = clsScriptData.ExecuteSchalar(sqlConn, sqlRet)
            sqlConn.Close()
            Return intID
        Catch ex As Exception
            Return 0
        End Try
    End Function
    Private Sub DelData(ByVal LabID As Integer)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim cmdDel As New SqlCommand("spDelete_Lab", sqlConn)
        With cmdDel
            .CommandType = CommandType.StoredProcedure
            .Parameters.AddWithValue("@ID", LabID)
            .ExecuteNonQuery()
        End With
    End Sub
    Private Sub DelDataRec(ByVal ID As Integer)
        'Dim Count As Integer
        'For Count = 0 To Me.gvLab.Rows.Count - 1
        '    If CType(Me.gvLab.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
        '        DelData(retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim))
        '    End If
        'Next
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Dim cmdDel As New SqlCommand("spDelete_Lab_Data", sqlConn)
        With cmdDel
            .CommandType = CommandType.StoredProcedure
            .Parameters.AddWithValue("@ID", ID)
            .ExecuteNonQuery()
        End With
    End Sub
    Private Sub ClearData()
        Me.txtDate.Text = ""
        Me.txtDateAnalyst.Text = ""
        Me.txtDateExp.Text = ""
        Me.txtExQty.Text = ""
        Me.txtRemark.Text = ""
        Me.txtResult.Text = ""
        Me.txtRemark.Text = ""
        Me.txtRef.Text = ""
        Me.rbtnRefine.Checked = False
        Me.rbtnWhite.Checked = False
        Me.lblItem.Visible = False
        Me.txtResult.Visible = False
        gvLab.Visible = False
        gvKeyIn.Visible = True
        'ViewState.Remove("Type")
    End Sub
    Private Sub ClearText()
        Me.txtDate.Text = ""
        Me.txtDateAnalyst.Text = ""
        Me.txtDateExp.Text = ""
        Me.txtExQty.Text = ""
        Me.txtLot.Text = ""
        Me.txtRemark.Text = ""
        Me.txtResult.Text = ""
        Me.txtRemark.Text = ""
        Me.txtRef.Text = ""
        Me.rbtnRefine.Checked = False
        Me.rbtnWhite.Checked = False
        Me.lblItem.Visible = False
        Me.txtResult.Visible = False
        gvLab.Visible = False
        gvKeyIn.Visible = True
        'ViewState.Remove("Type")
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadMill()
        End If
    End Sub

    Protected Sub imgbtnAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAdd.Click
        SaveData("Save")
    End Sub

    Protected Sub imgbtnClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClear.Click
        ClearText()
    End Sub

    Protected Sub imgbtnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelete.Click
        Dim Count As Integer
        For Count = 0 To Me.gvLab.Rows.Count - 1
            If CType(Me.gvLab.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                DelDataRec(retIDDetail(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim, CType(gvLab.Rows(Count).FindControl("lnkID"), LinkButton).Text))
            End If
        Next
    End Sub

    Protected Sub imgbtnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnFilter.Click
        ClearData()
        LoadHead()
        QueryLab(retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim))
    End Sub

    Protected Sub imgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSave.Click
        SaveData("Update")
        Dim Count As Integer
        For Count = 0 To Me.gvLab.Rows.Count - 1
            If CType(Me.gvLab.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                EditResult()
            End If
        Next
        ClearData()
    End Sub

    Protected Sub gvLab_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvLab.RowCommand
        If e.CommandName = "Select" Then
            Dim gvCurrent As GridViewRow = e.CommandSource.Parent.Parent
            Dim intLabID As Integer
            intLabID = retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim)
            lblItem.Visible = True
            txtResult.Visible = True
            lblItem.Text = CType(gvCurrent.Cells(0).FindControl("lnkID"), LinkButton).Text
            txtResult.Text = gvCurrent.Cells(1).Text
            QueryID(CInt(ddlMill.SelectedValue), lblItem.Text, intLabID)
            CType(gvCurrent.Cells(2).FindControl("chkConfirm"), CheckBox).Checked = True
        End If
    End Sub

    Protected Sub ddlMill_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMill.SelectedIndexChanged
        ClearText()
        LoadItem()
    End Sub

    Protected Sub imgbtnDelAll_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelAll.Click
        DelData(retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim))
        'Response.Write("<script>alert('Delete data complate.')</script>")
        lblErr.Visible = True
        lblErr.Text = "Delete data complate."
        ClearText()
    End Sub

    Protected Sub rbtnRefine_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtnRefine.CheckedChanged
        ViewState.Remove("Type")
        rbtnWhite.Checked = False
        rbtnRefine.Checked = True
        ViewState("Type") = "Refine"
    End Sub

    Protected Sub rbtnWhite_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtnWhite.CheckedChanged
        ViewState.Remove("Type")
        rbtnRefine.Checked = False
        rbtnWhite.Checked = True
        ViewState("Type") = "White"
    End Sub
End Class
