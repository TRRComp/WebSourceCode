﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class frmLab
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim strFac As String
    Dim Mode As String
    Dim strType As String
    Dim strDateProduce As Date
    Dim strDateAnalyst As Date
    Dim strDateExp As Date
#Region "Sub And Function"
    Private Sub LoadType()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlSugar As String
            Dim dsSugar As New DataSet
            sqlSugar = "Select 0 as Type_ID, '' as Type_Name union all Select Type_ID,Type_Name From Sugar_Type order by type_id"
            dsSugar = clsScriptData.ExecuteData(sqlConn, sqlSugar, "dtSugar")
            If dsSugar.Tables("dtSugar").Rows.Count > 0 Then
                ddlSugarType.DataValueField = "Type_ID"
                ddlSugarType.DataTextField = "Type_Name"
                ddlSugarType.DataSource = dsSugar.Tables("dtSugar")
                ddlSugarType.DataBind()
            End If
            dsSugar = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadMill()
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim strClientIP As String
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))
            Dim sqlMill As String
            Dim dsMill As New DataSet
            sqlMill = "SELECT Mill,Mill_Name,Mill_Name_Eng FROM Mill "
            If strFac <> "Head Office" Then
                sqlMill &= "WHERE Mill_Name='" & strFac & "' "
            End If
            dsMill = clsScriptData.ExecuteData(sqlConn, sqlMill, "dtMill")
            If dsMill.Tables("dtMill").Rows.Count > 0 Then
                ddlMill.DataValueField = "Mill"
                ddlMill.DataTextField = "Mill_Name_Eng"
                ddlMill.DataSource = dsMill.Tables("dtMill")
                ddlMill.DataBind()
                lblErr.Visible = False
            Else
                lblErr.Visible = True
                lblErr.Text = "Data not found"
            End If
            LoadItem()
            dsMill = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadItem()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlItemLab As String
            Dim dsItemLab As New DataSet
            sqlItemLab = "Select '' as Value,TestItem.TestItem,TestItem.TestItem_ID from TestItem "
            sqlItemLab &= "Where TestItem.Mill=" & CInt(ddlMill.SelectedValue) & " "
            dsItemLab = clsScriptData.ExecuteData(sqlConn, sqlItemLab, "dtItem")
            gvKeyIn.Visible = True
            gvKeyIn.DataSource = dsItemLab.Tables("dtItem")
            gvKeyIn.DataBind()
            gvLab.Visible = False
            dsItemLab = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadHead()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim LabID As Integer
            LabID = retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim, CStr(ddlSugarType.SelectedValue))
            Dim sqlQueryLab As String
            Dim dsQueryLab As New DataSet
            sqlQueryLab = "SELECT lab.mill,LAB.Lab_ID,MILL.MILL_NAME_ENG,LAB.SUGAR_TYPE,LAB.LOT_NO,Lab.Production_Date, "
            sqlQueryLab &= "Lab.Referance_no, Lab.Sample_Size, Lab.Analyst_Date,Lab.Remarks,Exp_Date,Production_Year "
            sqlQueryLab &= "FROM LAB LEFT JOIN MILL ON MILL.MILL=LAB.MILL "
            sqlQueryLab &= "WHERE LAB.MILL = '" & CInt(ddlMill.SelectedValue) & "' "
            sqlQueryLab &= "And LAB.LOT_NO = '" & Me.txtLot.Text.Trim & "' "
            sqlQueryLab &= "And LAB.Lab_ID = " & LabID & " "
            sqlQueryLab &= "and Lab.Sugar_Type='" & ddlSugarType.SelectedValue & "' "
            sqlQueryLab &= "ORDER BY LAB.lab_ID"
            dsQueryLab = clsScriptData.ExecuteData(sqlConn, sqlQueryLab, "dtQuery")
            If dsQueryLab.Tables("dtQuery").Rows.Count > 0 Then
                Dim str1 As String
                str1 = Format(dsQueryLab.Tables("dtQuery").Rows(0)("Production_Date"), "dd/MM/yyyy")
                Dim str2 As String
                str2 = Format(dsQueryLab.Tables("dtQuery").Rows(0)("Analyst_Date"), "dd/MM/yyyy")

                Dim str3 As String
                If dsQueryLab.Tables("dtQuery").Rows(0)("Exp_Date") IsNot DBNull.Value Then
                    str3 = Format(dsQueryLab.Tables("dtQuery").Rows(0)("Exp_Date"), "dd/MM/yyyy")
                Else
                    str3 = ""
                End If
                Me.txtYear.Text = dsQueryLab.Tables("dtQuery").Rows(0)("Production_Year")
                Me.txtDateExp.Text = str3
                Me.txtDate.Text = str1 'strProduce
                Me.txtDateAnalyst.Text = str2 'strAnalyst
                Me.txtExQty.Text = dsQueryLab.Tables("dtQuery").Rows(0)("Sample_Size")
                Me.txtRef.Text = dsQueryLab.Tables("dtQuery").Rows(0)("Referance_no")
                Me.txtRemark.Text = dsQueryLab.Tables("dtQuery").Rows(0)("Remarks")
                Me.ddlSugarType.SelectedValue = dsQueryLab.Tables("dtQuery").Rows(0)("Sugar_Type")
                lblErr.Visible = False
            Else
                lblErr.Visible = True
                lblErr.Text = "Data Not Found"
            End If
            dsQueryLab = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryLab(ByVal LabID As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlQueryLab As String
            Dim dsQueryLab As New DataSet
            Dim strTable1 As String
            Dim strTable2 As String
            strTable1 = "Lab_Data"
            strTable2 = "Lab"

            sqlQueryLab = "Select Lab_Data.Value,TestItem.TestItem,Lab_Data.TestItem_ID "
            sqlQueryLab &= "from " & strTable1 & " Lab_Data inner join " & strTable2 & " Lab "
            sqlQueryLab &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlQueryLab &= "left join TestItem on "
            sqlQueryLab &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID and Lab_Data.Mill=TestItem.Mill "
            sqlQueryLab &= "where Lab_Data.Mill=" & CInt(ddlMill.SelectedValue) & " "
            sqlQueryLab &= "and Lab.Lot_No='" & Me.txtLot.Text.Trim & "' and Lab.Lab_id=" & LabID & " "
            sqlQueryLab &= "and Lab.Sugar_Type='" & ddlSugarType.SelectedValue & "' "
            sqlQueryLab &= "and Lab.Production_Year='" & txtYear.Text.Trim & "' "
            dsQueryLab = clsScriptData.ExecuteData(sqlConn, sqlQueryLab, "dtQuery")
            If dsQueryLab.Tables("dtQuery").Rows.Count > 0 Then
                ViewState.Remove("Lab_ID")
                gvLab.Visible = True
                gvLab.DataSource = dsQueryLab.Tables("dtQuery")
                gvLab.DataBind()
                ViewState("Lab_ID") = LabID
                gvKeyIn.Visible = False
                lblErr.Visible = False
            Else
                lblErr.Visible = True
                lblErr.Text = "Data Not Found"
            End If
            dsQueryLab = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryLabEdit(ByVal LabID As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlQueryLab As String
            Dim dsQueryLab As New DataSet
            sqlQueryLab = "Select Lab_Data.Value,TestItem.TestItem,Lab_Data.TestItem_ID from Lab_Data inner join Lab "
            sqlQueryLab &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlQueryLab &= "left join TestItem on "
            sqlQueryLab &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID and Lab_Data.Mill=TestItem.Mill "
            sqlQueryLab &= "where Lab_Data.Mill=" & CInt(ddlMill.SelectedValue) & " "
            sqlQueryLab &= "and Lab.Lot_No='" & Me.txtLot.Text.Trim & "' and Lab.Lab_id=" & LabID & ""
            dsQueryLab = clsScriptData.ExecuteData(sqlConn, sqlQueryLab, "dtQuery")
            If dsQueryLab.Tables("dtQuery").Rows.Count > 0 Then
                ViewState.Remove("Lab_ID")
                gvLab.Visible = True
                gvLab.DataSource = dsQueryLab.Tables("dtQuery")
                gvLab.DataBind()
                gvKeyIn.Visible = False
                lblErr.Visible = False
            Else
                lblErr.Visible = True
                lblErr.Text = "Data Not Found"
            End If
            dsQueryLab = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub EditResult()
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdUpdate As New SqlCommand("spUpdate_Lab_Data", sqlConn)
            With cmdUpdate
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@ID", ViewState("ID"))
                .Parameters.AddWithValue("@Mill", CInt(Me.ddlMill.SelectedValue))
                .Parameters.AddWithValue("@TestItem_ID", ViewState("Item_ID"))
                .Parameters.AddWithValue("@Lab_ID", ViewState("Lab_ID"))
                .Parameters.AddWithValue("@Value", Me.txtResult.Text.Trim)
                .ExecuteNonQuery()
            End With
            cmdUpdate = Nothing
            sqlConn.Close()
            QueryLab(retID(CInt(Me.ddlMill.SelectedValue), Me.txtLot.Text, Me.ddlSugarType.SelectedValue))
            ViewState.Remove("ID")
            ViewState.Remove("Item_ID")
            ViewState.Remove("Lab_ID")
            lblErr.Visible = True
            lblErr.Text = "Update Data Already."
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function CheckResult(ByVal TestItem As String, ByVal Result As String, ByVal Type As String) As Boolean
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strClientIP As String
            strClientIP = Request.UserHostAddress()
            Dim strIP As String = Mid(strClientIP.ToString, 9, 1)
            strFac = clsScriptData.GetIPFac(CInt(strIP))
            Dim sqlResult As String = ""
            Dim dsResult As New DataSet
            Dim strMin As String
            Dim strMax As String
            Dim decMin As Decimal
            Dim decMax As Decimal
            Dim decResult As Decimal
            If TestItem = "Sediment" Then
                If Type = "Domestic White" Then
                    sqlResult = "Select TestItem,Substring(Domestic_Min_White,1,6) As Min_Result,Substring(Domestic_Max_White,1,6) As Max_Result "
                ElseIf Type = "Domestic Refine" Then
                    sqlResult = "Select TestItem,Substring(Domestic_Min_Refine,1,6) As Min_Result,Substring(Domestic_Max_Refine,1,6) As Max_Result "
                ElseIf Type = "Export White" Then
                    sqlResult = "Select TestItem,Substring(Export_Min_White,1,6) As Min_Result,Substring(Export_Max_White,1,6) As Max_Result "
                ElseIf Type = "Export Refine" Then
                    sqlResult = "Select TestItem,Substring(Export_Min_Refine,1,6) As Min_Result,Substring(Export_Max_Refine,1,6) As Max_Result "
                Else
                    sqlResult = "Select TestItem,'' As Min_Result,'' As Max_Result "
                End If
            Else
                If Type = "Domestic White" Then
                    sqlResult = "Select TestItem,Domestic_Min_White As Min_Result,Domestic_Max_White As Max_Result "
                ElseIf Type = "Domestic Refine" Then
                    sqlResult = "Select TestItem,Domestic_Min_Refine As Min_Result,Domestic_Max_Refine As Max_Result "
                ElseIf Type = "Export White" Then
                    sqlResult = "Select TestItem,Export_Min_White As Min_Result,Export_Max_White As Max_Result "
                ElseIf Type = "Export Refine" Then
                    sqlResult = "Select TestItem,Export_Min_Refine As Min_Result,Export_Max_Refine As Max_Result "
                Else
                    sqlResult = "Select TestItem,'' As Min_Result,'' As Max_Result "
                End If
            End If
            sqlResult &= "from TestItem Where TestItem='" & TestItem & "' And Mill=" & strIP & ""
            dsResult = clsScriptData.ExecuteData(sqlConn, sqlResult, "dtResult")
            If dsResult.Tables("dtResult").Rows.Count <> 0 Then
                strMin = clsScriptData.DbnullToString(dsResult.Tables("dtResult").Rows(0)("Min_Result"))
                strMax = clsScriptData.DbnullToString(dsResult.Tables("dtResult").Rows(0)("Max_Result"))
            End If
            If strIP = 2 Or strIP = 1 Or strIP = 5 Or strIP = 4 Or strIP = 6 Or strIP = 3 Then
                If dsResult.Tables("dtResult").Rows(0)("TestItem") = "Sediment" Then
                    strMin = ""
                    strMax = ""
                End If
            End If

            If strMin = "" And strMax = "" Then
                Return True
            Else
                decMin = CDec(strMin)
                decMax = CDec(strMax)
                If dsResult.Tables("dtResult").Rows(0)("TestItem") = "Sediment" Then
                    decResult = Mid(Result, 0, 5)
                Else
                    decResult = CDec(Result)
                End If
                If decResult >= decMin And decResult <= decMax Then
                    Return True
                Else
                    Return False
                End If
            End If
            dsResult = Nothing
            sqlConn.Close()
        Catch ex As Exception
            Response.Write(ex.Message)
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Private Sub SaveData(ByVal Mode As String)
        Try
            Dim ddProduce As String
            Dim MMProduce As String
            Dim yyProduce As String
            Dim strProduce As String
            ddProduce = txtDate.Text.Substring(0, 2)
            MMProduce = txtDate.Text.Substring(3, 2)
            yyProduce = txtDate.Text.Substring(6, 4)
            strProduce = yyProduce + "-" + MMProduce + "-" + ddProduce + " 00:00:00"
            strDateProduce = CDate(strProduce)

            Dim ddAnalyst As String
            Dim MMAnalyst As String
            Dim yyAnalyst As String
            Dim strAnalyst As String
            ddAnalyst = txtDateAnalyst.Text.Substring(0, 2)
            MMAnalyst = txtDateAnalyst.Text.Substring(3, 2)
            yyAnalyst = txtDateAnalyst.Text.Substring(6, 4)
            strAnalyst = yyAnalyst + "-" + MMAnalyst + "-" + ddAnalyst + " 00:00:00"
            strDateAnalyst = CDate(strAnalyst)

            Dim ddExp As String
            Dim MMExp As String
            Dim yyExp As String
            Dim strExp As String
            If txtDateExp.Text IsNot DBNull.Value AndAlso txtDateExp.Text <> "" Then
                ddExp = txtDateExp.Text.Substring(0, 2)
                MMExp = txtDateExp.Text.Substring(3, 2)
                yyExp = txtDateExp.Text.Substring(6, 4)
                strExp = yyExp + "-" + MMExp + "-" + ddExp + " 00:00:00"
                strDateExp = CDate(strExp)
            End If

            Dim sqlQueryMill As String
            Dim strAnalystName As String
            Dim strAnalystLogo As String
            Dim strAuthorizeName As String
            Dim strAuthorizeLogo As String
            Dim strISON As String
            Dim strISOD As String
            Dim strISO As String
            Dim dsQuery As New DataSet
            sqlQueryMill = "Select Analyst_Name,Analyst_Logo,Authorize_Name,Authorize_Logo,ISO_No,ISO_Date From Mill Where Mill=" & Me.ddlMill.SelectedValue & " "
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            dsQuery = clsScriptData.ExecuteData(sqlConn, sqlQueryMill, "dtQueryMill")
            strAnalystName = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Analyst_Name"))
            strAnalystLogo = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Analyst_Logo"))
            strAuthorizeName = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Authorize_Name"))
            strAuthorizeLogo = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("Authorize_Logo"))
            strISON = clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("ISO_No"))
            If clsScriptData.DbnullToString(dsQuery.Tables("dtQueryMill").Rows(0)("ISO_Date")) <> "" Then
                'strISOD = 'CStr(dsQuery.Tables("dtQueryMill").Rows(0)("ISO_Date"))
                strISOD = CStr(Format(dsQuery.Tables("dtQueryMill").Rows(0)("ISO_Date"), "dd/MM/yyyy"))
            Else
                strISOD = ""
            End If

            strISO = strISON & ":" & strISOD
            If Mode = "Save" Then
                If CheckLotNo(Me.txtLot.Text.Trim, Me.ddlSugarType.SelectedValue, Me.ddlMill.SelectedValue) = False Then
                    lblErr.Visible = True
                    lblErr.Text = "Have data already!!!"
                    ClearData()
                    Exit Sub
                End If

                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdSaveHead As New SqlCommand("spAdd_Lab", sqlConn)
                With cmdSaveHead
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@Mill", CInt(Me.ddlMill.SelectedValue))
                    .Parameters.AddWithValue("@Type", CInt(Me.ddlSugarType.SelectedValue))
                    .Parameters.AddWithValue("@Lot_no", Trim(Me.txtLot.Text))
                    .Parameters.AddWithValue("@Production_date", strDateProduce)
                    .Parameters.AddWithValue("@Analyst_Date", strDateAnalyst)
                    .Parameters.AddWithValue("@Referance_no", Me.txtRef.Text.Trim)
                    .Parameters.AddWithValue("@Sample", CDec(Me.txtExQty.Text.Trim))
                    .Parameters.AddWithValue("@Username", Me.Request.LogonUserIdentity.Name)
                    .Parameters.AddWithValue("@Remarks", Trim(Me.txtRemark.Text))
                    .Parameters.AddWithValue("@Analyst_Name", strAnalystName)
                    .Parameters.AddWithValue("@Analyst_Logo", strAnalystLogo)
                    .Parameters.AddWithValue("@Authorize_Name", strAuthorizeName)
                    .Parameters.AddWithValue("@Authorize_Logo", strAuthorizeLogo)
                    If txtDateExp.Text IsNot DBNull.Value AndAlso txtDateExp.Text <> "" Then
                        .Parameters.AddWithValue("@Exp_Date", strDateExp)
                    Else
                        .Parameters.AddWithValue("@Exp_Date", System.DBNull.Value)
                    End If
                    .Parameters.AddWithValue("@Production_Year", Me.txtYear.Text.Trim)
                    .Parameters.AddWithValue("@FM_No", strISO)
                    .ExecuteNonQuery()
                End With
                cmdSaveHead = Nothing

                Dim strID As Integer
                strID = clsScriptData.ExecuteSchalar(sqlConn, "select max(Lab_ID) as Lab_ID from Lab WHERE Mill=" & ddlMill.SelectedValue & "")

                Dim dt As DataTable = New DataTable()
                Dim gvr As GridViewRow
                Dim dr As DataRow

                dt.Columns.Add(New DataColumn("TestItem_ID"))
                dt.Columns.Add(New DataColumn("TestItem"))
                dt.Columns.Add(New DataColumn("Lab_ID"))
                dt.Columns.Add(New DataColumn("Value"))
                dt.Columns.Add(New DataColumn("Mill"))

                For Each gvr In gvKeyIn.Rows
                    dr = dt.NewRow()
                    dr("TestItem_ID") = gvr.Cells(0).Text
                    dr("TestItem") = gvr.Cells(1).Text
                    dr("Lab_ID") = strID
                    dr("Value") = IIf(True, (CType(gvr.Cells(2).FindControl("txtValue"), TextBox)).Text, "-")
                    dr("Mill") = Me.ddlMill.SelectedValue
                    dt.Rows.Add(dr)
                Next
                gvKeyIn.DataSource = dt
                gvKeyIn.DataBind()

                For Each dr In dt.Rows
                    Dim cmdSave As New SqlCommand("spAdd_Lab_Data", sqlConn)
                    With cmdSave
                        .CommandType = CommandType.StoredProcedure
                        .Parameters.AddWithValue("@TestItem_ID", dr("TestItem_ID"))
                        .Parameters.AddWithValue("@Lab_ID", CInt(dr("Lab_ID")))
                        .Parameters.AddWithValue("@Value", dr("Value"))
                        .Parameters.AddWithValue("@Mill", CInt(dr("Mill")))
                        .ExecuteNonQuery()
                    End With
                    cmdSave.Dispose()
                Next
                ClearData()
                QueryLab(retID(CInt(Me.ddlMill.SelectedValue), Me.txtLot.Text.Trim, Me.ddlSugarType.SelectedValue))
                sqlConn.Close()

            ElseIf Mode = "Update" Then
                If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
                Dim cmdUpdateHead As New SqlCommand("spUpdate_Lab", sqlConn)
                With cmdUpdateHead
                    .CommandType = CommandType.StoredProcedure
                    .Parameters.AddWithValue("@ID", ViewState("Lab_ID"))
                    .Parameters.AddWithValue("@Mill", CInt(Me.ddlMill.SelectedValue))
                    .Parameters.AddWithValue("@Type", CInt(Me.ddlSugarType.SelectedValue))
                    .Parameters.AddWithValue("@Lot_no", Trim(Me.txtLot.Text))
                    .Parameters.AddWithValue("@Production_date", strDateProduce)
                    .Parameters.AddWithValue("@Analyst_Date", strDateAnalyst)
                    .Parameters.AddWithValue("@Referance_no", Me.txtRef.Text.Trim)
                    .Parameters.AddWithValue("@Sample", CDec(Me.txtExQty.Text.Trim))
                    .Parameters.AddWithValue("@Username", Me.Request.LogonUserIdentity.Name)
                    .Parameters.AddWithValue("@Remarks", Trim(Me.txtRemark.Text))
                    '.Parameters.AddWithValue("@Analyst_Name", strAnalystName)
                    '.Parameters.AddWithValue("@Analyst_Logo", strAnalystLogo)
                    '.Parameters.AddWithValue("@Authorize_Name", strAuthorizeName)
                    '.Parameters.AddWithValue("@Authorize_Logo", strAuthorizeLogo)
                    If txtDateExp.Text IsNot DBNull.Value AndAlso txtDateExp.Text <> "" Then
                        .Parameters.AddWithValue("@Exp_Date", strDateExp)
                    Else
                        .Parameters.AddWithValue("@Exp_Date", System.DBNull.Value)
                    End If
                    .Parameters.AddWithValue("@Production_Year", Me.txtYear.Text.Trim)
                    .ExecuteNonQuery()
                End With
                'ClearData()
                'QueryLab(retID(CInt(Me.ddlMill.SelectedValue), Me.txtLot.Text.Trim))
                cmdUpdateHead = Nothing
                sqlConn.Close()
            End If
        Catch ex As Exception
            Response.Write(ex.Message)
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryID(ByVal Mill As Integer, ByVal Item As String, ByVal Lab_ID As Integer)
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlID As String
            Dim dsID As New DataSet
            sqlID = "Select Lab_Data.ID,Lab_Data.TestItem_ID,Lab_Data.Lab_ID from Lab_Data inner join Lab "
            sqlID &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlID &= "left join TestItem on "
            sqlID &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID And Lab_Data.Mill = TestItem.Mill "
            sqlID &= "where Lab_Data.Mill=" & Mill & " and TestItem.TestItem='" & Item & "' and Lab_Data.Lab_ID=" & Lab_ID & ""
            dsID = clsScriptData.ExecuteData(sqlConn, sqlID, "dtID")
            ViewState("ID") = dsID.Tables("dtID").Rows(0)("ID")
            ViewState("Item_ID") = dsID.Tables("dtID").Rows(0)("TestItem_ID")
            ViewState("Lab_ID") = dsID.Tables("dtID").Rows(0)("Lab_ID")
            dsID = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function retID(ByVal Mill As Integer, ByVal LotNO As String, ByVal strSugar As String) As Integer
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim intID As Integer
            Dim sqlRet As String
            sqlRet = "Select distinct Lab.Lab_ID from Lab_Data inner join Lab "
            sqlRet &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlRet &= "where Lab_Data.Mill=" & Mill & " and Lab.Lot_No='" & LotNO & "' "
            sqlRet &= "and Lab.Sugar_Type='" & strSugar & "' "
            If clsScriptData.DbnullToString(txtYear.Text) <> "" Then
                sqlRet &= "and Lab.Production_Year='" & txtYear.Text.Trim & "' "
            End If
            intID = clsScriptData.ExecuteSchalar(sqlConn, sqlRet)
            sqlConn.Close()
            Return intID
        Catch ex As Exception
            Return 0
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Function CheckLotNo(ByVal LotNo As String, ByVal SugarType As Integer, ByVal Mill As Integer) As Boolean
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlCheck As String
            Dim intCount As Integer
            sqlCheck = "select COUNT(*) from Lab where lot_no='" & LotNo & "' and sugar_type=" & SugarType & " and Mill=" & Mill & " And production_Year='" & txtYear.Text & "'"
            intCount = clsScriptData.ExecuteSchalar(sqlConn, sqlCheck)
            sqlConn.Close()
            If intCount = 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Function retIDDetail(ByVal Mill As Integer, ByVal LotNO As String, ByVal Item As String) As Integer
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim intID As Integer
            Dim sqlRet As String
            sqlRet = "Select Lab_Data.ID from Lab_Data inner join Lab "
            sqlRet &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlRet &= "left join TestItem on "
            sqlRet &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID And Lab_Data.Mill = TestItem.Mill "
            sqlRet &= "where Lab_Data.Mill=" & Mill & " and TestItem.TestItem='" & Item & "' and Lab.Lot_No='" & LotNO & "'"
            intID = clsScriptData.ExecuteSchalar(sqlConn, sqlRet)
            sqlConn.Close()
            Return intID
        Catch ex As Exception
            Return 0
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Private Sub DelData(ByVal LabID As Integer)
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdDel As New SqlCommand("spDelete_Lab", sqlConn)
            With cmdDel
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@ID", LabID)
                .ExecuteNonQuery()
            End With
            cmdDel = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub DelDataRec(ByVal ID As Integer)
        'Dim Count As Integer
        'For Count = 0 To Me.gvLab.Rows.Count - 1
        '    If CType(Me.gvLab.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
        '        DelData(retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim))
        '    End If
        'Next
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            Dim cmdDel As New SqlCommand("spDelete_Lab_Data", sqlConn)
            With cmdDel
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@ID", ID)
                .ExecuteNonQuery()
            End With
            cmdDel = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ClearData()
        Me.txtDate.Text = ""
        Me.txtDateAnalyst.Text = ""
        Me.txtDateExp.Text = ""
        Me.txtExQty.Text = ""
        Me.txtRemark.Text = ""
        Me.txtResult.Text = ""
        Me.txtRemark.Text = ""
        Me.txtRef.Text = ""
        'Me.ddlSugarType.SelectedIndex = 0
        Me.lblItem.Visible = False
        Me.txtResult.Visible = False
        'Me.txtYear.Text = ""
        gvLab.Visible = False
        gvKeyIn.Visible = True
        'ViewState.Remove("Type")
    End Sub
    Private Sub ClearText()
        Me.txtDate.Text = ""
        Me.txtDateAnalyst.Text = ""
        Me.txtDateExp.Text = ""
        Me.txtExQty.Text = ""
        Me.txtLot.Text = ""
        Me.txtRemark.Text = ""
        Me.txtResult.Text = ""
        Me.txtRemark.Text = ""
        Me.txtRef.Text = ""
        'Me.txtYear.Text = ""
        Me.ddlSugarType.SelectedIndex = 0
        'Me.rbtnRefine.Checked = False
        'Me.rbtnWhite.Checked = False
        Me.lblItem.Visible = False
        Me.txtResult.Visible = False
        gvLab.Visible = False
        gvKeyIn.Visible = True
        pnAccuResult.Visible = False
        'ViewState.Remove("Type")
    End Sub
#End Region
#Region "Sub Accumurate Result"
    Private Sub LoadItemAccu()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlItemAccu As String
            Dim dsAccu As New DataSet
            sqlItemAccu = "Select '' as TestItem, 0 as TestItem_ID Union All Select TestItem.TestItem,TestItem.TestItem_ID from TestItem "
            sqlItemAccu &= "Where TestItem.Mill=" & CInt(ddlMill.SelectedValue) & " "
            dsAccu = clsScriptData.ExecuteData(sqlConn, sqlItemAccu, "dtItemAccu")
            If dsAccu.Tables("dtItemAccu").Rows.Count > 0 Then
                ddlItemName.DataValueField = "TestItem_ID"
                ddlItemName.DataTextField = "TestItem"
                ddlItemName.DataSource = dsAccu.Tables("dtItemAccu")
                ddlItemName.DataBind()
            End If
            dsAccu = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadLotByDate()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            If ddlSugarType.SelectedIndex = 0 Then
                Response.Write("Please select sugar type before update result!!!")
                Exit Sub
            End If

            Dim FMDate As Date
            Dim ddProduceFM As String
            Dim MMProduceFM As String
            Dim yyProduceFM As String
            Dim strProduceFM As String
            ddProduceFM = txtDateFM.Text.Substring(0, 2)
            MMProduceFM = txtDateFM.Text.Substring(3, 2)
            yyProduceFM = txtDateFM.Text.Substring(6, 4)
            If yyProduceFM > 2500 Then
                yyProduceFM = yyProduceFM - 543
            End If
            strProduceFM = yyProduceFM + "-" + MMProduceFM + "-" + ddProduceFM + " 00:00:00"
            FMDate = CDate(strProduceFM)

            Dim TODate As Date
            Dim ddProduceTO As String
            Dim MMProduceTO As String
            Dim yyProduceTO As String
            Dim strProduceTO As String
            ddProduceTO = txtDateTo.Text.Substring(0, 2)
            MMProduceTO = txtDateTo.Text.Substring(3, 2)
            yyProduceTO = txtDateTo.Text.Substring(6, 4)
            If yyProduceTO > 2500 Then
                yyProduceTO = yyProduceTO - 543
            End If
            strProduceTO = yyProduceTO + "-" + MMProduceTO + "-" + ddProduceTO + " 00:00:00"
            TODate = CDate(strProduceTO)

            Dim sqlLot As String
            Dim dsLot As New DataSet
            Dim intID As Integer
            sqlLot = "select Lot_No,Lab_ID from Lab where Production_Date Between '" & Format(FMDate, "yyyy/MM/dd") & "' and  '" & Format(TODate, "yyyy/MM/dd") & "' "
            sqlLot &= "And Sugar_Type=" & ddlSugarType.SelectedValue & " And Mill= " & CInt(Me.ddlMill.SelectedValue) & " "

            dsLot = clsScriptData.ExecuteData(sqlConn, sqlLot, "dtLot")
            For i As Integer = 0 To dsLot.Tables("dtLot").Rows.Count - 1
                intID = CInt(dsLot.Tables("dtLot").Rows(i)("Lab_ID"))
                UpdateResult(CInt(ddlItemName.SelectedValue), txtValue.Text.Trim, intID)
            Next
            dsLot = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub UpdateResult(ByVal Item_ID As Integer, ByVal Result As String, ByVal Lab_ID As Integer)
        Dim sqlTran As SqlTransaction
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim sqlUpResult As String
            sqlUpResult = "Update Lab_Data Set Value='" & Result & "' "
            sqlUpResult &= "Where TestItem_ID=" & Item_ID & " And Lab_ID=" & Lab_ID & ""
            sqlTran = sqlConn.BeginTransaction
            Dim cmUpResult As New SqlCommand
            With cmUpResult
                .CommandType = CommandType.Text
                .CommandText = sqlUpResult
                .Transaction = sqlTran
                .Connection = sqlConn
                .ExecuteNonQuery()
            End With
            sqlTran.Commit()
            cmUpResult = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlTran.Rollback()
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadMill()
            LoadType()
            pnAccuResult.Visible = False
        End If
    End Sub

    Protected Sub imgbtnAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAdd.Click
        Dim Count As Integer
        If ddlSugarType.SelectedValue = 1 Or ddlSugarType.SelectedValue = 2 Or ddlSugarType.SelectedValue = 3 Or ddlSugarType.SelectedValue = 4 Then
            For Count = 0 To Me.gvKeyIn.Rows.Count - 1
                If CheckResult(gvKeyIn.Rows(Count).Cells(1).Text, IIf(True, CType(gvKeyIn.Rows(Count).Cells(2).FindControl("txtValue"), TextBox).Text, ""), ddlSugarType.SelectedItem.Text) = False Then
                    lblErr.Visible = True
                    lblErr.Text = "กรุณาตรวจสอบผลการทดสอบ Item " & " " & gvKeyIn.Rows(Count).Cells(1).Text & " " & "อีกครั้งหนึ่ง"
                    Exit Sub
                End If
                lblErr.Visible = False
            Next
        End If
        SaveData("Save")
    End Sub

    Protected Sub imgbtnClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClear.Click
        ClearText()
    End Sub

    Protected Sub imgbtnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelete.Click
        Dim Count As Integer
        For Count = 0 To Me.gvLab.Rows.Count - 1
            If CType(Me.gvLab.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                DelDataRec(retIDDetail(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim, CType(gvLab.Rows(Count).FindControl("lnkID"), LinkButton).Text))
            End If
        Next
    End Sub

    Protected Sub imgbtnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnFilter.Click
        ClearData()
        LoadHead()
        QueryLab(retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim, CStr(ddlSugarType.SelectedValue)))
    End Sub

    Protected Sub imgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSave.Click
        SaveData("Update")
        Dim Count As Integer
        For Count = 0 To Me.gvLab.Rows.Count - 1
            If CType(Me.gvLab.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                EditResult()
            End If
        Next
        ClearData()
    End Sub

    Protected Sub gvLab_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvLab.RowCommand
        If e.CommandName = "Select" Then
            Dim gvCurrent As GridViewRow = e.CommandSource.Parent.Parent
            Dim intLabID As Integer
            intLabID = retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim, Me.ddlSugarType.SelectedValue)
            lblItem.Visible = True
            txtResult.Visible = True
            lblItem.Text = CType(gvCurrent.Cells(0).FindControl("lnkID"), LinkButton).Text
            txtResult.Text = gvCurrent.Cells(1).Text
            QueryID(CInt(ddlMill.SelectedValue), lblItem.Text, intLabID)
            CType(gvCurrent.Cells(2).FindControl("chkConfirm"), CheckBox).Checked = True
        End If
    End Sub

    Protected Sub ddlMill_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMill.SelectedIndexChanged
        ClearText()
        LoadItem()
    End Sub

    Protected Sub imgbtnDelAll_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelAll.Click
        DelData(retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim, Me.ddlSugarType.SelectedValue))
        'Response.Write("<script>alert('Delete data complate.')</script>")
        lblErr.Visible = True
        lblErr.Text = "Delete data complate."
        ClearText()
    End Sub

    Protected Sub btnUpResult_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpResult.Click
        pnAccuResult.Visible = True
        LoadItemAccu()
    End Sub

    Protected Sub imgbtnEditResult_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnEditResult.Click
        LoadLotByDate()
    End Sub

    Protected Sub imgbtnClearResult_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClearResult.Click
        Me.txtValue.Text = ""
        Me.txtDateFM.Text = ""
        Me.txtDateTo.Text = ""
        ddlItemName.SelectedIndex = 0
    End Sub

    Protected Sub imgbtnPrint_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnPrint.Click
        Session("Mill") = ddlMill.SelectedValue
        Session("Lot") = txtLot.Text
        Session("Sugar") = ddlSugarType.SelectedValue
        Session("PYear") = txtYear.Text
        Session("LabID") = retID(CInt(ddlMill.SelectedValue), Me.txtLot.Text.Trim, CStr(ddlSugarType.SelectedValue))
        Response.Write("<script>window.open('frmLabPreview.aspx','mywindow','width=auto,height=auto,toolbars=yes,scrollbars=yes,status=no,resizable=yes')</script>")
    End Sub

    Protected Sub ibtnEditName_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnEditName.Click

    End Sub

    Protected Sub ibtnClearName_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnClearName.Click

    End Sub
End Class
