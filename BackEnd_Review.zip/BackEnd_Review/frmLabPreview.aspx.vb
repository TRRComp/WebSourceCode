﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class frmPreview
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)

#Region "PreviewRpt"
    Private Sub QueryLogo()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmQueryHead As New SqlCommand("spLot_Data1", sqlConn)
            With cmQueryHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@mill", Session("Mill"))
                .Parameters.AddWithValue("@Lot_no", Session("Lot"))
                .Parameters.AddWithValue("@Sugar_Type", Session("Sugar"))
                .Parameters.AddWithValue("@PYears", Session("PYear"))
                .ExecuteNonQuery()
            End With

            Dim dtQueryHead As New DataTable
            dtQueryHead = clsScriptData.ExecuteDT(sqlConn, cmQueryHead)
            dvLogo.DataSource = dtQueryHead
            dvLogo.DataBind()

            cmQueryHead.Dispose()
            dtQueryHead.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryHeader()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmRptHead As New SqlCommand("spLot_Data1", sqlConn)
            With cmRptHead
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@mill", Session("Mill"))
                .Parameters.AddWithValue("@Lot_no", Session("Lot"))
                .Parameters.AddWithValue("@Sugar_Type", Session("Sugar"))
                .Parameters.AddWithValue("@PYears", Session("PYear"))
                .ExecuteNonQuery()
            End With

            Dim dtHead As New DataTable
            dtHead = clsScriptData.ExecuteDT(sqlConn, cmRptHead)
            dvHeadRpt.DataSource = dtHead
            dvHeadRpt.DataBind()

            dvRemarks.DataSource = dtHead
            dvRemarks.DataBind()

            DvAnalyst.DataSource = dtHead
            DvAnalyst.DataBind()

            DvAuthorize.DataSource = dtHead
            DvAuthorize.DataBind()

            cmRptHead.Dispose()
            dtHead.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryDetail()
        Try
            QueryLogo()
            QueryHeader()

        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ShowRpt()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()

            Dim sqlQueryLab As String
            Dim dsQueryLab As New DataSet
            sqlQueryLab = "Select Lab_Data.Value,TestItem.TestItem,Lab_Data.TestItem_ID from Lab_Data inner join Lab "
            sqlQueryLab &= "on Lab.Lab_ID=Lab_Data.lab_id and Lab.Mill=Lab_Data.Mill "
            sqlQueryLab &= "left join TestItem on "
            sqlQueryLab &= "Lab_Data.TestItem_ID = TestItem.TestItem_ID and Lab_Data.Mill=TestItem.Mill "
            sqlQueryLab &= "where Lab_Data.Mill=" & CInt(Session("Mill")) & " "
            sqlQueryLab &= "and Lab.Lot_No='" & Session("Lot") & "' and Lab.Lab_id=" & Session("LabID") & " "
            sqlQueryLab &= "and Lab.Sugar_Type='" & Session("Sugar") & "' and Production_Year='" & Session("PYear") & "' "
            dsQueryLab = clsScriptData.ExecuteData(sqlConn, sqlQueryLab, "dtQuery")
            If dsQueryLab.Tables("dtQuery").Rows.Count > 0 Then
                gvShowRpt.Visible = True
                gvShowRpt.DataSource = dsQueryLab.Tables("dtQuery")
                gvShowRpt.DataBind()
            Else

            End If
            dsQueryLab = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetRefNo()
        Try
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim strRefNo As String
            strRefNo = clsScriptData.ExecuteSchalar(sqlConn, "select Referance_no from lab where Mill=" & Session("Mill") & " and Lot_No='" & Session("Lot") & "' and sugar_type='" & Session("Sugar") & "' and Production_Year='" & Session("PYear") & "' ")
            lblRef.Text = ""
            lblRef.Text = strRefNo
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function MillName(ByVal Mill As Integer) As String
        Dim Name As String = ""
        Select Case Mill
            Case 1
                Name = "SS"
            Case 2
                Name = "PS"
            Case 3
                Name = "TRR"
            Case 4
                Name = "TMI"
            Case 5
                Name = "TSI"
            Case 6
                Name = "BSI"
            Case Else
                Name = Nothing
        End Select
        Return Name
    End Function
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pnRpt.Visible = True
        QueryDetail()
        ShowRpt()
        GetRefNo()
        Response.Write("<script>window.print();</script>")
        Session.Remove("Mill")
        Session.Remove("Lot")
        Session.Remove("Sugar")
        Session.Remove("LabID")
        Session.Remove("PYear")
    End Sub
End Class
