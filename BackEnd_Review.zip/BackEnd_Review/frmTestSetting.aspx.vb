﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class frmTestSetting
    Inherits System.Web.UI.Page
    Dim sqlConn As New SqlConnection(clsScriptData.GetIPAddress)
    Dim dsLoadItem As New DataSet
    Dim strFac As String
    Dim intIP As Integer
    Dim intFac As Integer
#Region "Sub QueryTest"
    Function GetintFac() As Integer

        Dim strclientIP() As String
        strclientIP = Split(Request.UserHostAddress, ".")
        Dim strIPGet As String = ""
        Dim strIp As String = ""
        strIPGet = strclientIP(2)
        strFac = clsScriptData.GetIPFac(CInt(strIPGet))
        strIp = clsScriptData.RetIPFac(CInt(strIPGet))
        intFac = CInt(strIp)
        'If intFac = 0 Then intFac = 2
        Return intFac
    End Function
    Private Sub LoadSugarType()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlType As String
            Dim dsType As New DataSet
            sqlType = "Select 0 as [Type_ID],'' as [Type_Name] union all Select [Type_ID],[Type_Name] "
            sqlType &= "from Sugar_Type Where [Type_ID] not in (1,2,3,4)"
            dsType = clsScriptData.ExecuteData(sqlConn, sqlType, "dtType")
            ddlSugarType.DataTextField = "Type_Name"
            ddlSugarType.DataValueField = "Type_ID"
            ddlSugarType.DataSource = dsType.Tables("dtType")
            ddlSugarType.DataBind()
            dsType = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub LoadCust()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Dim sqlCust As String
        Dim dsCust As New DataSet
        sqlCust = "Select 0 as CUSTOMER_ID,'' as CUSTOMER_NAME union all SELECT CUSTOMER_ID,CUSTOMER_NAME FROM CUSTOMER ORDER BY CUSTOMER_ID"
        dsCust = clsScriptData.ExecuteData(sqlConn, sqlCust, "tbCust")
        If dsCust.Tables("tbCust").Rows.Count > 0 Then
            ddlCust.DataTextField = "CUSTOMER_NAME"
            ddlCust.DataValueField = "CUSTOMER_ID"
            ddlCust.DataSource = dsCust.Tables("tbCust")
            ddlCust.DataBind()
        End If
        dsCust = Nothing
        sqlConn.Close()
    End Sub
    Private Sub LoadItem()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            intFac = GetintFac()
            'intFac = 2
            Dim sqlLoadItem As String
            If rdbtnOthers.Checked = True Then
                sqlLoadItem = "Select TestItem ,'' As Benchmark,'' As Benchmark "
                sqlLoadItem &= "from TestItem "
                sqlLoadItem &= "Where Mill=" & intFac & " Order By SortItem"
                dsLoadItem = clsScriptData.ExecuteData(sqlConn, sqlLoadItem, "tbItem")
                gvFillDataDomestic.Visible = False
                gvQueryDomestic.Visible = False
                gvOthers.Visible = True
                gvFillOthers.Visible = False
                gvOthers.DataSource = dsLoadItem.Tables("tbItem")
                gvOthers.DataBind()
                pnEditData.Visible = False
                pnOthers.Visible = False
            Else
                sqlLoadItem = "Select TestItem ,'' As Benchmark_White,'' As Benchmark_Refine, "
                sqlLoadItem &= "'' As TestMethod_White,'' As TestMethod_Refine "
                sqlLoadItem &= "from TestItem "
                sqlLoadItem &= "Where Mill=" & intFac & " Order By SortItem"
                dsLoadItem = clsScriptData.ExecuteData(sqlConn, sqlLoadItem, "tbItem")
                gvFillDataDomestic.Visible = False
                gvQueryDomestic.Visible = True
                gvOthers.Visible = False
                gvFillOthers.Visible = False
                gvQueryDomestic.DataSource = dsLoadItem.Tables("tbItem")
                gvQueryDomestic.DataBind()
                pnEditData.Visible = False
                pnOthers.Visible = False
            End If
            dsLoadItem = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function CheckCust() As Boolean
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlCheck As String
            Dim strCust As Integer
            sqlCheck = "Select count(Customer_ID) from SetSpec Where Customer_ID=" & CInt(ddlCust.SelectedValue) & " "
            If rdbtnDomestic.Checked = True Then
                sqlCheck &= "And SugarType='D' "
            ElseIf rdbtnExport.Checked = True Then
                sqlCheck &= "And SugarType='E' "
            Else
                sqlCheck &= "And SugarType='" & ddlSugarType.SelectedValue & "' "
            End If
            strCust = clsScriptData.ExecuteSchalar(sqlConn, sqlCheck)
            If strCust > 0 Then
                Return True
            Else
                Return False
            End If
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Private Sub QueryItem()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            'Dim strclientIP() As String
            'strclientIP = Split(Request.UserHostAddress, ".")
            'Dim strIPGet As String = ""
            'Dim strIp As String = ""
            'strIPGet = strclientIP(2)
            'strFac = clsScriptData.GetIPFac(CInt(strIPGet))
            'strIp = clsScriptData.RetIPFac(CInt(strIPGet))
            intFac = GetintFac() 'CInt(strIP)

            Dim sqlLoadItem As String
            Dim dsLoadItem As New DataSet
            If rdbtnOthers.Checked = True Then
                sqlLoadItem = "Select SetSpec.ID,TestItem.TestItem,SetSpec.Benchmark,SetSpec.TestMethod,SetSpec.Others "
                sqlLoadItem &= "from SetSpec left join TestItem on "
                sqlLoadItem &= "SetSpec.TestItem_ID=TestItem.TestItem_ID and SetSpec.mill = TestItem.mill "
                If CheckCust() = True Then
                    sqlLoadItem &= "Where SetSpec.Customer_ID=" & CInt(ddlCust.SelectedValue) & " "
                Else
                    sqlLoadItem &= "Where SetSpec.Customer_ID='0' "
                End If
                sqlLoadItem &= "And SetSpec.mill=" & intFac & " "
                sqlLoadItem &= "And SugarType='" & ddlSugarType.SelectedValue & "' Order By SortItem"
                dsLoadItem = clsScriptData.ExecuteData(sqlConn, sqlLoadItem, "tbFillItem")
                If dsLoadItem.Tables("tbFillItem").Rows.Count > 0 Then
                    gvQueryDomestic.Visible = False
                    gvOthers.Visible = False
                    gvFillDataDomestic.Visible = False
                    gvFillOthers.Visible = True
                    gvFillOthers.DataSource = dsLoadItem.Tables("tbFillItem")
                    gvFillOthers.DataBind()
                    For i As Integer = 0 To dsLoadItem.Tables("tbFillItem").Rows.Count - 1
                        If dsLoadItem.Tables("tbFillItem").Rows(i)("Others") = True Then
                            CType(Me.gvFillOthers.Rows(i).FindControl("chkOthers"), CheckBox).Checked = True
                        Else
                            CType(Me.gvFillOthers.Rows(i).FindControl("chkOthers"), CheckBox).Checked = False
                        End If
                    Next
                End If
            Else
                sqlLoadItem = "Select SetSpec.ID,TestItem.TestItem,SetSpec.Benchmark_White,SetSpec.Benchmark_Refine, "
                sqlLoadItem &= "SetSpec.TestMethod_White, SetSpec.TestMethod_Refine, SetSpec.White, SetSpec.Refine "
                sqlLoadItem &= "from SetSpec left join TestItem on "
                sqlLoadItem &= "SetSpec.TestItem_ID=TestItem.TestItem_ID and SetSpec.mill = TestItem.mill "
                If CheckCust() = True Then
                    sqlLoadItem &= "Where SetSpec.Customer_ID=" & CInt(ddlCust.SelectedValue) & " "
                Else
                    sqlLoadItem &= "Where SetSpec.Customer_ID='0' "
                End If
                sqlLoadItem &= "And SetSpec.mill=" & intFac & " "
                If rdbtnDomestic.Checked = True Then
                    sqlLoadItem &= "And SugarType='D' "
                ElseIf rdbtnExport.Checked = True Then
                    sqlLoadItem &= "And SugarType='E' "
                End If
                sqlLoadItem &= "Order By SortItem"
                dsLoadItem = clsScriptData.ExecuteData(sqlConn, sqlLoadItem, "tbFillItem")
                If dsLoadItem.Tables("tbFillItem").Rows.Count > 0 Then
                    gvQueryDomestic.Visible = False
                    gvOthers.Visible = False
                    gvFillDataDomestic.Visible = True
                    gvFillOthers.Visible = False
                    gvFillDataDomestic.DataSource = dsLoadItem.Tables("tbFillItem")
                    gvFillDataDomestic.DataBind()
                    For i As Integer = 0 To dsLoadItem.Tables("tbFillItem").Rows.Count - 1
                        If dsLoadItem.Tables("tbFillItem").Rows(i)("White") = True And dsLoadItem.Tables("tbFillItem").Rows(i)("Refine") = True Then
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkWhite"), CheckBox).Checked = True
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkRefine"), CheckBox).Checked = True
                        ElseIf dsLoadItem.Tables("tbFillItem").Rows(i)("Refine") = True Then
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkRefine"), CheckBox).Checked = True
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkWhite"), CheckBox).Checked = False
                        ElseIf dsLoadItem.Tables("tbFillItem").Rows(i)("White") = True Then
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkRefine"), CheckBox).Checked = False
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkWhite"), CheckBox).Checked = True
                        Else
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkRefine"), CheckBox).Checked = False
                            CType(Me.gvFillDataDomestic.Rows(i).FindControl("chkWhite"), CheckBox).Checked = False
                        End If
                    Next
                End If
            End If
            dsLoadItem = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryID(ByVal Mill As String, ByVal Cust_ID As String, ByVal SugarType As String)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlID As String
            Dim dsID As New DataSet
            sqlID = "Select SetSpec.ID,TestItem.TestItem_ID from SetSpec inner join TestItem on "
            sqlID &= "SetSpec.TestItem_ID=TestItem.TestItem_ID and "
            sqlID &= "SetSpec.mill=TestItem.mill left join Customer on "
            sqlID &= "SetSpec.Customer_ID = Customer.Customer_ID "
            sqlID &= "Where setSpec.Customer_ID='" & Cust_ID & "' and SetSpec.mill='" & Mill & "' "
            sqlID &= "And SetSpec.SugarType='" & SugarType & "' Order By SortItem"
            dsID = clsScriptData.ExecuteData(sqlConn, sqlID, "dtID")
            If dsID.Tables("dtID").Rows.Count <> 0 Then
                ViewState("ID") = dsID.Tables("dtID").Rows(0)("ID")
            End If
            ViewState("Item_ID") = dsID.Tables("dtID").Rows(0)("TestItem_ID")
            dsID = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub QueryItemID(ByVal Item As String, ByVal Mill As Integer)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlItemID As String
            Dim dsItemID As New DataSet
            sqlItemID = "Select TestItem.TestItem_ID from TestItem "
            sqlItemID &= "Where TestItem.TestItem='" & Item & "' and TestItem.mill=" & Mill & " Order By SortItem"
            dsItemID = clsScriptData.ExecuteData(sqlConn, sqlItemID, "dtItemID")
            ViewState("Item") = dsItemID.Tables("dtItemID").Rows(0)("TestItem_ID")
            dsItemID = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub SetSpec(ByVal ID As Integer, ByVal TestItem_ID As Integer, ByVal BenchW As String, ByVal TestW As String, ByVal BenchR As String, ByVal TestR As String, ByVal StrActW As Boolean, ByVal StrActR As Boolean, ByVal CustID As Integer, ByVal Others As Boolean, ByVal TestMethod As String, ByVal BenchMark As String)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Try
            'Dim strclientIP() As String
            'strclientIP = Split(Request.UserHostAddress, ".")
            'Dim strIPGet As String = ""
            'Dim strIp As String = ""
            'strIPGet = strclientIP(2)
            'strFac = clsScriptData.GetIPFac(CInt(strIPGet))
            'strIp = clsScriptData.RetIPFac(CInt(strIPGet))
            intFac = GetintFac() 'CInt(strIP)

            Dim strType As String = ""
            If rdbtnDomestic.Checked = True Then
                strType = "D"
            ElseIf rdbtnExport.Checked = True Then
                strType = "E"
            Else
                strType = ddlSugarType.SelectedValue
            End If

            Dim cmdSave As New SqlCommand("spUpdate_Setting", sqlConn)
            With cmdSave
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@Id", ID)
                .Parameters.AddWithValue("@TestItem_ID", TestItem_ID)
                .Parameters.AddWithValue("@Benchmark_White", BenchW)
                .Parameters.AddWithValue("@TestMethod_White", TestW)
                .Parameters.AddWithValue("@White", StrActW)
                .Parameters.AddWithValue("@Benchmark_Refine", BenchR)
                .Parameters.AddWithValue("@TestMethod_Refine", TestR)
                .Parameters.AddWithValue("@Refine", StrActR)
                .Parameters.AddWithValue("@Customer_ID", CustID)
                .Parameters.AddWithValue("@Mill", intFac)
                .Parameters.AddWithValue("@Type", CStr(strType))
                .Parameters.AddWithValue("@Benchmark", BenchMark)
                .Parameters.AddWithValue("@TestMethod", TestMethod)
                .Parameters.AddWithValue("@Others", Others)
                .ExecuteNonQuery()
            End With
            cmdSave.Dispose()
            sqlConn.Close()
            QueryItem()
            ClearControl()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub DelData(ByVal Id As String)
        If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
        Try
            Dim cmdDel As New SqlCommand("spDelete_Setting", sqlConn)
            With cmdDel
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@ID", Id)
                .ExecuteNonQuery()
            End With
            cmdDel.Dispose()
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub ClearControl()
        Me.txtBmW.Text = ""
        Me.txtBmR.Text = ""
        Me.txtTestW.Text = ""
        Me.txtTestW.Text = ""
        'Me.ddlSugarType.SelectedIndex = 0
        chkW.Checked = False
        chkR.Checked = False
        pnEditData.Visible = False
    End Sub
#End Region
#Region "Sub UpdateItem"
    Private Sub getCustUp()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            intIP = GetintFac()
            'intIP = 2
            Dim sqlCustUp As String
            Dim dsCustUp As New DataSet
            sqlCustUp = "Select SP.Customer_ID,Cus.Customer_Name From SetSpec SP Left Join Customer Cus "
            sqlCustUp &= "On SP.Customer_ID=Cus.Customer_ID Where SP.Mill=" & intIP & " "
            sqlCustUp &= "Group By SP.Customer_ID,Cus.Customer_Name"
            dsCustUp = clsScriptData.ExecuteData(sqlConn, sqlCustUp, "dtCustUp")
            ddlCustUp.DataSource = dsCustUp.Tables("dtCustUp")
            ddlCustUp.DataTextField = "Customer_Name"
            ddlCustUp.DataValueField = "Customer_ID"
            ddlCustUp.DataBind()
            dsCustUp = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub getItem()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            intIP = GetintFac()
            'intIP = 2
            Dim sqlGetItem As String
            Dim dsGetItem As New DataSet
            'sqlGetItem = "Select 0 As TestItem_ID,'' As TestItem Union "
            sqlGetItem = "Select TestItem_ID,TestItem From TestItem "
            sqlGetItem &= "Where Mill=" & intIP & " Order By SortItem"
            dsGetItem = clsScriptData.ExecuteData(sqlConn, sqlGetItem, "dtGetItem")
            'Response.Write(intIP & ":" & sqlGetItem)
            ddlItem.DataTextField = "TestItem"
            ddlItem.DataValueField = "TestItem_ID"
            ddlItem.DataSource = dsGetItem.Tables("dtGetItem")
            ddlItem.DataBind()
            dsGetItem = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub setSugarMill()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlSugarMill As String
            Dim dsSugarMill As New DataSet
            sqlSugarMill = "Select [Type_ID],[Type_Name] From Sugar_Type"
            dsSugarMill = clsScriptData.ExecuteData(sqlConn, sqlSugarMill, "dtSugarMill")
            ddlType.DataSource = dsSugarMill.Tables("dtSugarMill")
            ddlType.DataTextField = "Type_Name"
            ddlType.DataValueField = "Type_ID"
            ddlType.DataBind()
            dsSugarMill = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Function getYear() As String
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim strPYear As String
            Dim sqlPYear As String
            sqlPYear = "Select PName From Production_Year Where Status=1"
            strPYear = clsScriptData.ExecuteSchalar(sqlConn, sqlPYear)
            sqlConn.Close()
            Return strPYear
        Catch ex As Exception
            Return Nothing
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Function
    Private Sub LoadMill()
        Try
            If sqlConn.State <> ConnectionState.Open Then sqlConn.Open()
            intIP = GetintFac()
            'intIP = 2
            Dim sqlMill As String
            Dim dsMill As New DataSet
            sqlMill = "SELECT Mill,Mill_Name,Mill_Name_Eng FROM Mill "
            If intIP <> 0 Then
                sqlMill &= "WHERE Mill='" & intIP & "' "
            End If
            dsMill = clsScriptData.ExecuteData(sqlConn, sqlMill, "dtMill")
            If dsMill.Tables("dtMill").Rows.Count > 0 Then
                ddlFac.DataValueField = "Mill"
                ddlFac.DataTextField = "Mill_Name_Eng"
                ddlFac.DataSource = dsMill.Tables("dtMill")
                ddlFac.DataBind()
                lblErr.Visible = False
            Else
                lblErr.Visible = True
                lblErr.Text = "Data not found"
            End If
            LoadItem()
            dsMill = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub showDetail(ByVal intItem As Integer)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlDetail As String
            Dim dsDetail As New DataSet
            'sqlDetail = "Select "

        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub EditMethod()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim strYear As String
            strYear = getYear()
            intIP = GetintFac()
            'intIP = 2
            Dim ddEff As String
            Dim MMEff As String
            Dim yyEff As String
            Dim strEff As String
            Dim strDate As Date
            If txtDate.Text IsNot DBNull.Value AndAlso txtDate.Text <> "" Then
                ddEff = txtDate.Text.Substring(0, 2)
                MMEff = txtDate.Text.Substring(3, 2)
                yyEff = txtDate.Text.Substring(6, 4)
                strEff = yyEff + "-" + MMEff + "-" + ddEff + " 00:00:00"
                strDate = CDate(strEff)
            End If
            Dim strCustUp As Integer
            If ddlCustUp.SelectedIndex <> 0 Then
                strCustUp = ddlCustUp.SelectedValue
            Else
                strCustUp = 0
            End If
            'strDateUp = Date.Now().ToString("dd/MM/yyyy")
            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            Dim cmdEdit As New SqlCommand("spAdd_UpSpec", sqlConn)
            With cmdEdit
                .CommandType = CommandType.StoredProcedure
                .Parameters.AddWithValue("@PYear", strYear)
                .Parameters.AddWithValue("@mill", intIP)
                .Parameters.AddWithValue("@ItemID", Me.ddlItem.SelectedValue)
                .Parameters.AddWithValue("@TMW", txtMW.Text.Trim)
                .Parameters.AddWithValue("@TMR", txtTR.Text.Trim)
                .Parameters.AddWithValue("@BMW", txtBW.Text.Trim)
                .Parameters.AddWithValue("@BMR", txtBR.Text.Trim)
                .Parameters.AddWithValue("@CustID", strCustUp)
                .Parameters.AddWithValue("@BM", txtBenc.Text.Trim)
                .Parameters.AddWithValue("@TM", txtTest.Text.Trim)
                .Parameters.AddWithValue("@SugarType", ddlType.SelectedValue)
                .Parameters.AddWithValue("@EffectDate", strDate)
                .ExecuteNonQuery()
            End With
            cmdEdit = Nothing
            lblUpStatus.Text = "Update data already."
            sqlConn.Close()
        Catch ex As Exception
            Response.Write(ex.Message)
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub DeleteUpSpec(ByVal intMill As Integer, ByVal intItem As Integer, ByVal strPyear As String)
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try

            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetPYear()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlGetYear As String
            Dim dsGetYear As New DataSet
            sqlGetYear = "Select PName,PValue From Production_Year"
            dsGetYear = clsScriptData.ExecuteData(sqlConn, sqlGetYear, "dtGetYear")
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub
    Private Sub GetSugarType()
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            Dim sqlGetSugar As String
            Dim dsGetSugar As New DataSet
            sqlGetSugar = "Select Type_ID,Type_Name From Sugar_Type"
            dsGetSugar = clsScriptData.ExecuteData(sqlConn, sqlGetSugar, "dtGetSugar")
            ddlType.DataValueField = "Type_ID"
            ddlType.DataTextField = "Type_Name"
            ddlType.DataSource = dsGetSugar.Tables("dtGetSugar")
            ddlType.DataBind()
            dsGetSugar = Nothing
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub

#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadCust()
            LoadItem()
        End If
    End Sub

    Protected Sub imgbtnAdd_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnAdd.Click
        If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
        Try
            'Dim strclientIP() As String
            'strclientIP = Split(Request.UserHostAddress, ".")
            'Dim strIPGet As String = ""
            'Dim strIp As String = ""
            'strIPGet = strclientIP(2)
            'strFac = clsScriptData.GetIPFac(CInt(strIPGet))
            'strIp = clsScriptData.RetIPFac(CInt(strIPGet))
            intFac = GetintFac() 'CInt(strIp)

            Dim dt As DataTable = New DataTable()
            Dim gvr As GridViewRow
            Dim dr As DataRow
            Dim strType As String = ""

            If rdbtnOthers.Checked = False Then
                If rdbtnDomestic.Checked = True Then
                    strType = "D"
                ElseIf rdbtnExport.Checked = True Then
                    strType = "E"
                End If
                dt.Columns.Add(New DataColumn("TestItem"))
                dt.Columns.Add(New DataColumn("Benchmark_White"))
                dt.Columns.Add(New DataColumn("TestMethod_White"))
                dt.Columns.Add(New DataColumn("Benchmark_Refine"))
                dt.Columns.Add(New DataColumn("TestMethod_Refine"))
                dt.Columns.Add(New DataColumn("White"))
                dt.Columns.Add(New DataColumn("Refine"))
                dt.Columns.Add(New DataColumn("Customer_ID"))
                dt.Columns.Add(New DataColumn("Mill"))
                dt.Columns.Add(New DataColumn("SugarType"))

                For Each gvr In gvQueryDomestic.Rows
                    dr = dt.NewRow()
                    QueryItemID(gvr.Cells(0).Text.Trim, CInt(intFac))
                    dr("TestItem") = ViewState("Item")
                    dr("Benchmark_White") = IIf(True, (CType(gvr.Cells(1).FindControl("txtBmW"), TextBox)).Text, "-")
                    dr("TestMethod_White") = IIf(True, (CType(gvr.Cells(2).FindControl("txtTestW"), TextBox)).Text, "-")
                    dr("Benchmark_Refine") = IIf(True, (CType(gvr.Cells(3).FindControl("txtBmR"), TextBox)).Text, "-")
                    dr("TestMethod_Refine") = IIf(True, (CType(gvr.Cells(4).FindControl("txtTestR"), TextBox)).Text, "-")
                    dr("White") = IIf(True, (CType(gvr.Cells(5).FindControl("chkW"), CheckBox)).Checked, "")
                    dr("Refine") = IIf(True, (CType(gvr.Cells(6).FindControl("chkR"), CheckBox)).Checked, "")
                    dr("Customer_ID") = IIf(True, Me.ddlCust.SelectedValue, "-")
                    dr("Mill") = intFac
                    dr("SugarType") = strType
                    dt.Rows.Add(dr)
                Next
                gvQueryDomestic.DataSource = dt
                gvQueryDomestic.DataBind()
            Else
                dt.Columns.Add(New DataColumn("TestItem"))
                dt.Columns.Add(New DataColumn("Benchmark"))
                dt.Columns.Add(New DataColumn("TestMethod"))
                dt.Columns.Add(New DataColumn("Others"))
                dt.Columns.Add(New DataColumn("Customer_ID"))
                dt.Columns.Add(New DataColumn("Mill"))
                dt.Columns.Add(New DataColumn("SugarType"))

                For Each gvr In gvOthers.Rows
                    dr = dt.NewRow()
                    QueryItemID(gvr.Cells(0).Text.Trim, CInt(intFac))
                    dr("TestItem") = ViewState("Item")
                    dr("Benchmark") = IIf(True, (CType(gvr.Cells(1).FindControl("txtBmO"), TextBox)).Text, "-")
                    dr("TestMethod") = IIf(True, (CType(gvr.Cells(2).FindControl("txtTestO"), TextBox)).Text, "-")
                    dr("Others") = IIf(True, (CType(gvr.Cells(3).FindControl("chkO"), CheckBox)).Checked, "")
                    dr("Customer_ID") = IIf(True, Me.ddlCust.SelectedValue, "-")
                    dr("Mill") = intFac
                    dr("SugarType") = ddlSugarType.SelectedValue
                    dt.Rows.Add(dr)
                Next
                gvOthers.DataSource = dt
                gvOthers.DataBind()
            End If

            If sqlConn.State = ConnectionState.Closed Then sqlConn.Open()
            For Each dr In dt.Rows
                Dim cmdSave As New SqlCommand("spAdd_Setting", sqlConn)
                cmdSave.CommandType = CommandType.StoredProcedure
                With cmdSave
                    .Parameters.AddWithValue("@TestItem_ID", dr("TestItem"))
                    If rdbtnOthers.Checked = True Then
                        .Parameters.AddWithValue("@Benchmark_White", "-")
                        .Parameters.AddWithValue("@TestMethod_White", "-")
                        .Parameters.AddWithValue("@White", "")
                        .Parameters.AddWithValue("@Benchmark_Refine", "-")
                        .Parameters.AddWithValue("@TestMethod_Refine", "-")
                        .Parameters.AddWithValue("@Refine", "")
                        .Parameters.AddWithValue("@Benchmark", dr("Benchmark"))
                        .Parameters.AddWithValue("@TestMethod", dr("TestMethod"))
                        .Parameters.AddWithValue("@Others", CStr(dr("Others")))
                    Else
                        .Parameters.AddWithValue("@Benchmark_White", dr("Benchmark_White"))
                        .Parameters.AddWithValue("@TestMethod_White", dr("TestMethod_White"))
                        .Parameters.AddWithValue("@White", dr("White"))
                        .Parameters.AddWithValue("@Benchmark_Refine", dr("Benchmark_Refine"))
                        .Parameters.AddWithValue("@TestMethod_Refine", dr("TestMethod_Refine"))
                        .Parameters.AddWithValue("@Refine", dr("Refine"))
                        .Parameters.AddWithValue("@Benchmark", "-")
                        .Parameters.AddWithValue("@TestMethod", "-")
                        .Parameters.AddWithValue("@Others", "")
                    End If
                    .Parameters.AddWithValue("@Customer_ID", CInt(dr("Customer_ID")))
                    .Parameters.AddWithValue("@Mill", CInt(dr("Mill")))
                    .Parameters.AddWithValue("@Type", CStr(dr("SugarType")))
                    .ExecuteNonQuery()
                End With
                cmdSave.Dispose()
            Next
            sqlConn.Close()
        Catch ex As Exception
            sqlConn.Close()
            sqlConn.Dispose()
        End Try
    End Sub

    Protected Sub imgbtnClear_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnClear.Click
        LoadItem()
    End Sub

    Protected Sub imgbtnDelete_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnDelete.Click
        If CheckCust() = False Then
            lblErr.Visible = True
            lblErr.Text = "Can not delete data."
            Exit Sub
        End If

        Dim Count As Integer
        If rdbtnOthers.Checked = True Then
            For Count = 0 To Me.gvFillOthers.Rows.Count - 1
                If CType(Me.gvFillOthers.Rows(Count).FindControl("chkConfirmO"), CheckBox).Checked = True Then
                    DelData(CType(Me.gvFillOthers.Rows(Count).FindControl("lnkID"), LinkButton).Text)
                End If
            Next
        Else
            For Count = 0 To Me.gvFillDataDomestic.Rows.Count - 1
                If CType(Me.gvFillDataDomestic.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
                    DelData(CType(Me.gvFillDataDomestic.Rows(Count).FindControl("lnkID"), LinkButton).Text)
                End If
            Next
        End If
        QueryItem()
    End Sub

    Protected Sub imgbtnSave_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnSave.Click
        Dim Count As Integer

        If rdbtnOthers.Checked = True Then
            If chkOthers.Checked = True Then
                ViewState("chkOthers") = True
            Else
                ViewState("chkOthers") = False
            End If
            SetSpec(ViewState("ID"), ViewState("Item"), "", "", "", "", False, False, ViewState("CustID"), ViewState("chkOthers"), Me.txtMethod.Text, Me.txtBench.Text)
        Else
            If chkW.Checked = True Then
                ViewState("chkW") = True
            Else
                ViewState("chkW") = False
            End If
            If chkR.Checked = True Then
                ViewState("chkR") = True
            Else
                ViewState("chkR") = False
            End If
            'For Count = 0 To Me.gvFillDataDomestic.Rows.Count - 1
            'If CType(Me.gvFillDataDomestic.Rows(Count).FindControl("chkConfirm"), CheckBox).Checked = True Then
            SetSpec(ViewState("ID"), ViewState("Item"), Me.txtBmW.Text, Me.txtTestW.Text, Me.txtBmR.Text, Me.txtTestR.Text, ViewState("chkW"), ViewState("chkR"), ViewState("CustID"), False, "", "")
            'End If
            ' Next
        End If
        QueryItem()
        ViewState.Remove("ID")
        ViewState.Remove("Item")
        ViewState.Remove("chkW")
        ViewState.Remove("chkR")
        ViewState.Remove("CustID")
        ViewState.Remove("Mill")
        ViewState.Remove("chkOthers")
        ClearControl()
    End Sub

    Protected Sub imgbtnFilter_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnFilter.Click
        lblErr.Visible = False
        QueryItem()
        ClearControl()
    End Sub

    Protected Sub gvFillData_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvFillDataDomestic.RowCommand
        If e.CommandName = "Select" Then
            Dim gvFillData As GridViewRow = e.CommandSource.Parent.Parent
            pnEditData.Visible = True
            pnOthers.Visible = False
            'Dim strclientIP() As String
            'strclientIP = Split(Request.UserHostAddress, ".")
            'Dim strIPGet As String = ""
            'Dim strIp As String = ""
            'strIPGet = strclientIP(2)
            'strFac = clsScriptData.GetIPFac(CInt(strIPGet))
            'strIp = clsScriptData.RetIPFac(CInt(strIPGet))
            intFac = GetintFac() 'CInt(strIp)

            ViewState("Mill") = intFac
            ViewState("ID") = CType(gvFillData.Cells(0).FindControl("lnkID"), LinkButton).Text
            ViewState("Item") = clsScriptData.DbnullToString(gvFillData.Cells(1).Text)
            txtBmW.Text = clsScriptData.DbnullToString(gvFillData.Cells(2).Text).Replace("&nbsp;", "")
            txtBmR.Text = clsScriptData.DbnullToString(gvFillData.Cells(3).Text).Replace("&nbsp;", "")
            txtTestW.Text = clsScriptData.DbnullToString(gvFillData.Cells(4).Text).Replace("&nbsp;", "")
            txtTestR.Text = clsScriptData.DbnullToString(gvFillData.Cells(5).Text).Replace("&nbsp;", "")
            ViewState("CustID") = ddlCust.SelectedValue
            If CType(gvFillData.Cells(6).FindControl("chkWhite"), CheckBox).Checked Then
                chkW.Checked = True
                ViewState("chkW") = True
            Else
                chkW.Checked = False
                ViewState("chkW") = False
            End If
            If CType(gvFillData.Cells(7).FindControl("chkRefine"), CheckBox).Checked Then
                chkR.Checked = True
                ViewState("chkR") = True
            Else
                chkR.Checked = False
                ViewState("chkR") = False
            End If
            QueryItemID(gvFillData.Cells(1).Text.Trim, CInt(intFac))
            CType(gvFillData.Cells(8).FindControl("chkConfirm"), CheckBox).Checked = True
        End If
    End Sub

    Protected Sub imgbtnNew_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnNew.Click
        If CheckCust() = True Then
            Response.Write("<script>alert('This customer set spect already.')</script>")
            Exit Sub
        End If
        lblErr.Visible = False
        If rdbtnOthers.Checked = True Then
            gvOthers.Visible = True
            gvQueryDomestic.Visible = False
        Else
            gvQueryDomestic.Visible = True
            gvOthers.Visible = False
        End If
        gvFillDataDomestic.Visible = False
        gvFillOthers.Visible = False
    End Sub

    Protected Sub rdbtnDomestic_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbtnDomestic.CheckedChanged
        rdbtnOthers.Checked = False
        ddlSugarType.Visible = False
        rdbtnExport.Checked = False
        gvFillDataDomestic.Visible = False
        gvQueryDomestic.Visible = True
        gvOthers.Visible = False
        gvFillOthers.Visible = False
        pnEditData.Visible = False
        pnOthers.Visible = False
    End Sub

    Protected Sub rdbtnExport_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbtnExport.CheckedChanged
        rdbtnDomestic.Checked = False
        rdbtnOthers.Checked = False
        ddlSugarType.Visible = False
        gvFillDataDomestic.Visible = False
        gvQueryDomestic.Visible = True
        gvOthers.Visible = False
        gvFillOthers.Visible = False
        pnEditData.Visible = False
        pnOthers.Visible = False
    End Sub

    Protected Sub rdbtnOthers_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbtnOthers.CheckedChanged
        rdbtnDomestic.Checked = False
        rdbtnExport.Checked = False
        ddlSugarType.Visible = True
        gvFillDataDomestic.Visible = False
        gvQueryDomestic.Visible = False
        gvOthers.Visible = True
        gvFillOthers.Visible = False
        pnEditData.Visible = False
        pnOthers.Visible = False
        LoadSugarType()
        LoadItem()
    End Sub

    Protected Sub gvFillOthers_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gvFillOthers.RowCommand
        If e.CommandName = "Select" Then
            Dim gvFillData As GridViewRow = e.CommandSource.Parent.Parent
            pnEditData.Visible = False
            pnOthers.Visible = True
            'Dim strclientIP() As String
            'strclientIP = Split(Request.UserHostAddress, ".")
            'Dim strIPGet As String = ""
            'Dim strIp As String = ""
            'strIPGet = strclientIP(2)
            'strFac = clsScriptData.GetIPFac(CInt(strIPGet))
            'strIp = clsScriptData.RetIPFac(CInt(strIPGet))
            intFac = GetintFac() 'CInt(strIp)

            ViewState("Mill") = intFac
            ViewState("ID") = CType(gvFillData.Cells(0).FindControl("lnkID"), LinkButton).Text
            ViewState("Item") = clsScriptData.DbnullToString(gvFillData.Cells(1).Text)
            txtBench.Text = clsScriptData.DbnullToString(gvFillData.Cells(2).Text).Replace("&nbsp;", "")
            txtMethod.Text = clsScriptData.DbnullToString(gvFillData.Cells(3).Text).Replace("&nbsp;", "")
            ViewState("CustID") = ddlCust.SelectedValue
            If CType(gvFillData.Cells(4).FindControl("chkOthers"), CheckBox).Checked Then
                chkOthers.Checked = True
                ViewState("Others") = True
            Else
                chkOthers.Checked = False
                ViewState("Others") = False
            End If
            QueryItemID(gvFillData.Cells(1).Text.Trim, CInt(intFac))
            CType(gvFillData.Cells(5).FindControl("chkConfirmO"), CheckBox).Checked = True
        End If
    End Sub

    Protected Sub ibtnNew_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnNew.Click
        pnUpdateConfig.Visible = False
        pnNewConfig.Visible = True
    End Sub

    Protected Sub ibtnEdit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnEdit.Click
        pnUpdateConfig.Visible = True
        pnNewConfig.Visible = False
        getCustUp()
        getItem()
        LoadMill()
        setSugarMill()
        txtPY.Text = getYear()
    End Sub

    Protected Sub ibtnAddNew_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnAddNew.Click
        EditMethod()
    End Sub

    Protected Sub ibtnClearNew_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ibtnClearNew.Click

    End Sub

    Protected Sub ddlFac_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFac.SelectedIndexChanged
        getItem()
    End Sub
End Class
