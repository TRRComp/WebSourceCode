﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data
Imports System.Web

Public Class clsScriptData
    Public Shared strConnection As String '= ConfigurationSettings.AppSettings("Sugar_QualityConnectionString")
    Public Shared strFac As String = ""
    Public Shared intFac As Integer = 0
    Public Shared Function GetIPAddress() As String
        'Dim strHostName As String = System.Net.Dns.GetHostName()
        'Dim ipHost As System.Net.IPHostEntry = System.Net.Dns.Resolve(strHostName)
        'Dim ipAddress As System.Net.IPAddress = ipHost.AddressList(0)
        'Dim strCheckIp As String = Mid(ipAddress.ToString, 9, 1)
        'If strCheckIp = 0 Then
        strConnection = ConfigurationSettings.AppSettings("Sugar_QualityConnectionString")
        'Else

        'End If
        Return strConnection
    End Function
    Public Shared Function GetIPFac(ByVal Id As Integer) As String
        'Dim strHostName As String = System.Net.Dns.GetHostName()
        'Dim ipHost As System.Net.IPHostEntry = System.Net.Dns.Resolve(strHostName)
        'Dim ipAddress As System.Net.IPAddress = ipHost.AddressList(0)
        'Dim strCheckIp As String = Mid(ipAddress.ToString, 9, 1)
        'Dim strClientIP As String
        'strClientIP = Request.UserHostAddress()
        'Dim strCheckIp As Integer '= Mid(strClientIP.ToString, 9, 1)
        If Id = 0 Or Id = 1 Then
            strFac = "Head Office"
        ElseIf Id = 8 Or Id = 10111 Then
            strFac = "SS"
        ElseIf Id = 16 Or Id = 10112 Then
            strFac = "PS"
        ElseIf Id = 24 Or Id = 10113 Then
            strFac = "TRR"
        ElseIf Id = 32 Or Id = 10114 Then
            strFac = "TMI"
        ElseIf Id = 40 Or Id = 10115 Then
            strFac = "TSI"
        ElseIf Id = 48 Or Id = 10116 Then
            strFac = "BSI"
        ElseIf Id = 64 Or Id = 10119 Then
            strFac = "SB"
        End If
        Return strFac
    End Function

    Public Shared Function RetIPFac(ByVal Id As Integer) As String
        If Id = 0 Or Id = 1 Then
            strFac = "Head Office"
        ElseIf Id = 8 Or Id = 10111 Then
            intFac = 1
        ElseIf Id = 16 Or Id = 10112 Then
            intFac = 2
        ElseIf Id = 24 Or Id = 10113 Then
            intFac = 3
        ElseIf Id = 32 Or Id = 10114 Then
            intFac = 4
        ElseIf Id = 40 Or Id = 10115 Then
            intFac = 5
        ElseIf Id = 48 Or Id = 10116 Then
            intFac = 6
        ElseIf Id = 64 Or Id = 10119 Then
            intFac = 7
        End If
        Return intFac
    End Function
    Public Shared Function DbnullToString(ByVal Din As Object) As String
        If IsDBNull(Din) Then
            Return ""
        Else
            Return Din.ToString
        End If
    End Function

    Public Shared Function ExecuteData(ByVal strConn As SqlConnection, ByVal strSQL As String, ByVal tbName As String) As DataSet
        Try
            Dim _ds As New DataSet
            Dim _da As New SqlDataAdapter(strSQL, strConn)
            _da.Fill(_ds, tbName)
            Return _ds
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function ExecuteDataTable(ByVal strConn As SqlConnection, ByVal strSQL As String) As DataTable
        Try
            Dim _dt As New DataTable
            If strConn.State = ConnectionState.Closed Then strConn.Open()
            Dim _da As New SqlDataAdapter(strSQL, strConn)
            _da.Fill(_dt)
            Return _dt
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function ExecuteDT(ByVal strConn As SqlConnection, ByVal cmd As SqlCommand) As DataTable
        Try
            Dim _dt As New DataTable
            If strConn.State = ConnectionState.Closed Then strConn.Open()
            Dim _da As New SqlDataAdapter(cmd)
            _da.Fill(_dt)
            Return _dt
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Shared Function ExecuteDS(ByVal strConn As SqlConnection, ByVal cmd As SqlCommand, ByVal tbName As String) As DataSet
        Try
            Dim _dS As New DataSet
            If strConn.State = ConnectionState.Closed Then strConn.Open()
            Dim _da As New SqlDataAdapter(cmd)
            _da.Fill(_dS, tbName)
            Return _dS
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
  
    Public Shared Function ExecutNonquery(ByVal strConn As SqlConnection, ByVal strSQL As String) As Boolean
        Dim _sqlTran As SqlTransaction
        Try
            If strConn.State = ConnectionState.Closed Then strConn.Open()
            _sqlTran = strConn.BeginTransaction
            Dim _cm As New SqlCommand
            With _cm
                .CommandType = CommandType.Text
                .CommandText = strSQL
                .Transaction = _sqlTran
                .Connection = strConn
                .ExecuteNonQuery()
            End With
            _sqlTran.Commit()
            Return True
        Catch ex As Exception
            _sqlTran.Rollback()
            Return False
        End Try
    End Function
    Public Shared Function ExecuteSchalar(ByVal strConn As SqlConnection, ByVal strSql As String) As Object
        Try
            Dim _strReturn As Object
            Dim _cmd As New SqlCommand
            With _cmd
                .CommandType = CommandType.Text
                .CommandText = strSql
                .Connection = strConn
            End With
            _strReturn = _cmd.ExecuteScalar
            Return _strReturn
        Catch ex As Exception
            Return Nothing
        End Try
    End Function
End Class
